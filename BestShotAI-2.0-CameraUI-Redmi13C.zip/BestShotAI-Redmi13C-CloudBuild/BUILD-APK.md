# Build APK for BestShot AI (cloud build)

This project includes a GitHub Actions workflow so the APK can be compiled in GitHub's hosted Android/Java environment.

## One-time setup
1. Sign in to GitHub and create a new repository, e.g. `BestShotAI-Redmi13C`.
2. Upload the contents of this folder to the repository's `main` branch. The `.github/workflows/build-apk.yml` file must be included.
3. Open the repository's **Actions** tab.
4. Select **Build BestShot AI APK** and choose **Run workflow** (if it did not start automatically after upload).
5. Wait for the workflow to finish. A green check means the build job succeeded.
6. Open the completed workflow run. Under **Artifacts**, download `BestShotAI-debug-apk`.
7. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Copy it to the Redmi 13C and install it. Android may ask you to allow installation from that file manager/browser.

## Notes
- This produces a debug APK for testing, not a Play Store release.
- The first build downloads Android Gradle Plugin, Kotlin, CameraX, and Android SDK components, so GitHub needs internet access.
- The APK has not been built or tested on a physical Redmi 13C yet.
- The app's current photo ranking is a basic on-device sharpness/exposure heuristic, not a trained generative AI model.
