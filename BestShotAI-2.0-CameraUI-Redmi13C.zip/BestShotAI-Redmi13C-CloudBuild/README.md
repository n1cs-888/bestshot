# BestShot AI 2.0 - Feature Expansion

Android Kotlin + CameraX application intended for Redmi 13C testing.

## Implemented in this source
- Rear CameraX preview and max-quality JPEG capture configuration.
- Three-shot burst and heuristic sharpness/exposure ranking.
- Byte-for-byte copy of the selected original JPEG to MediaStore; analysis decodes only a downsampled copy.
- ML Kit face detection, stream-mode object detection/classification, and on-device image labeling.
- Rule-based scene hints for common labels, framing hints, and approximate subject continuity using nearest-box tracking.
- Thirds grid, accelerometer roll indicator, exposure compensation controls.
- Live preview tone tint overlays and post-capture tone editor that saves a separate JPEG copy.
- Auto/manual framing toggle and tracking toggle.

## Known limits (important)
- ML Kit's default image-labeling model and object detector do not guarantee recognition of every animal, building, object, or landscape. A dedicated custom-trained model and model evaluation dataset are required for comprehensive recognition.
- Angle, distance, and composition recommendations are heuristics, not a trained photography expert model or calibrated metric distance measurement.
- Subject continuity is approximate bounding-box matching, not robust multi-object identity tracking.
- Preview tone is an overlay; it does not change the camera sensor output. Post-edit applies a color matrix and creates a separate JPEG copy.
- Overlay box alignment is approximate due to CameraX crop/rotation/aspect-ratio transforms and must be calibrated on the target device.
- Build and on-device performance must be verified using GitHub Actions and a Redmi 13C.


## Camera UI refresh
The camera screen now follows the supplied visual direction: black full-screen camera canvas, compact top toolbar, floating subject-recognition chip, thirds grid and level guide, bottom shooting hint, zoom presets, gallery thumbnail, central shutter, and yellow AI-assist button. Some toolbar glyphs are text-based placeholders and should be replaced with polished vector icons during UI refinement.
