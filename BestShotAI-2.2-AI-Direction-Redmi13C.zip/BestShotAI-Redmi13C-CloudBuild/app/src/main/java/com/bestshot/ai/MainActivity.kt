package com.bestshot.ai

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.*
import android.net.Uri
import android.util.Size
import android.widget.ImageView
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.core.Camera as CameraXCamera
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.label.ImageLabel
import com.google.mlkit.vision.label.ImageLabeler
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.ObjectDetector
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity(), SensorEventListener {
    private lateinit var previewView: PreviewView
    private lateinit var overlay: GuideOverlay
    private lateinit var statusText: TextView
    private lateinit var shutterButton: Button
    private lateinit var galleryThumbnail: ImageView
    private var latestPhotoUri: Uri? = null
    private var selectedPhotoUri: Uri? = null
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var sensorManager: SensorManager
    private var imageCapture: ImageCapture? = null
    private var isCapturing = false
    private var analysisBusy = false
    private var lastAnalysisAt = 0L
    private var boundCamera: CameraXCamera? = null
    private var manualFraming = false
    private var trackingEnabled = true
    private var lastTrackedBox: RectF? = null
    private var latestLabels: List<String> = emptyList()
    private var latestSubject = "Mencari subjek…"
    private lateinit var subjectChip: TextView
    private var analysisWidth = 640
    private var analysisHeight = 480

    private var currentTone = Tone.NATURAL
    private var exposureSteps = 0
    private var zoomRatio = 1f
    private var aiGuideEnabled = false
    private var rollDegrees = 0f
    private var horizonAdvice = "Horizon stabil"
    private var guideDx = 0f
    private var guideDy = 0f
    private var guideMessage = "Arahkan kamera ke subjek utama"
    private var aiScanRequested = false
    private var subjectCenterX = .5f
    private var subjectCenterY = .5f
    private var targetCenterX = .62f
    private var targetCenterY = .46f
    private val burstSize = 3

    private val objectDetector: ObjectDetector by lazy {
        ObjectDetection.getClient(
            ObjectDetectorOptions.Builder()
                .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
                .enableClassification()
                .enableMultipleObjects()
                .build()
        )
    }
    private val faceDetector: FaceDetector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .build()
        )
    }
    // ML Kit's on-device base image-labeling model expands scene labels beyond object detector categories.
    private val imageLabeler: ImageLabeler by lazy {
        ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
    }

    private enum class Tone(val title: String, val tint: Int, val matrix: FloatArray) {
        NATURAL("Natural", Color.TRANSPARENT, floatArrayOf(
            1f,0f,0f,0f,0f, 0f,1f,0f,0f,0f, 0f,0f,1f,0f,0f, 0f,0f,0f,1f,0f
        )),
        WARM("Warm", Color.argb(22,255,155,70), floatArrayOf(
            1.08f,0f,0f,0f,5f, 0f,1.01f,0f,0f,1f, 0f,0f,0.91f,0f,-3f, 0f,0f,0f,1f,0f
        )),
        COOL("Cool", Color.argb(20,70,145,255), floatArrayOf(
            0.94f,0f,0f,0f,-2f, 0f,1.01f,0f,0f,1f, 0f,0f,1.10f,0f,4f, 0f,0f,0f,1f,0f
        )),
        FILM("Film", Color.argb(18,180,145,95), floatArrayOf(
            1.04f,0f,0f,0f,3f, 0f,1.00f,0f,0f,0f, 0f,0f,0.91f,0f,2f, 0f,0f,0f,1f,0f
        )),
        VIVID("Vivid", Color.argb(12,255,220,80), floatArrayOf(
            1.18f,0f,0f,0f,-8f, 0f,1.12f,0f,0f,-5f, 0f,0f,1.16f,0f,-7f, 0f,0f,0f,1f,0f
        )),
        MONO("Mono", Color.TRANSPARENT, floatArrayOf(
            0.30f,0.59f,0.11f,0f,0f, 0.30f,0.59f,0.11f,0f,0f, 0.30f,0.59f,0.11f,0f,0f, 0f,0f,0f,1f,0f
        ))
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera() else {
            statusText.text = "Izin kamera diperlukan."
            shutterButton.isEnabled = false
        }
    }

    private val photoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@registerForActivityResult
        selectedPhotoUri = uri
        showPhotoPreview(uri, allowEdit = true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        buildInterface()
        loadLatestPhoto()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildInterface() {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)

        // Top camera toolbar inspired by the supplied reference.
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val ratio = cameraLabel("▢   3:4  ⌄", 17f)
        top.addView(ratio, LinearLayout.LayoutParams(0, dp(48), 1f))
        top.addView(cameraButton("ϟ̸") { statusText.text = "Flash tidak tersedia pada semua kamera." })
        top.addView(cameraButton("◉") { openColorStudio() })
        top.addView(cameraButton("•••") { showCameraOptions() })
        root.addView(top, LinearLayout.LayoutParams(-1, dp(60)))

        val previewFrame = FrameLayout(this)
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        overlay = GuideOverlay().apply { aiGuidesEnabled = aiGuideEnabled }
        previewFrame.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        previewFrame.addView(overlay, FrameLayout.LayoutParams(-1, -1))

        subjectChip = TextView(this).apply {
            text = "MENCARI SUBJEK…"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.argb(220, 22, 22, 22))
                cornerRadius = dp(28).toFloat()
            }
        }
        val chipParams = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(20)
        }
        previewFrame.addView(subjectChip, chipParams)
        root.addView(previewFrame, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(Color.BLACK)
        }
        statusText = TextView(this).apply {
            text = "Point your camera and tap the ✦ button"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            maxLines = 2
            setPadding(dp(4), dp(3), dp(4), dp(12))
        }
        bottom.addView(statusText, LinearLayout.LayoutParams(-1, dp(42)))

        val zoomRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
        }
        listOf(.5f, 1f, 2f, 5f).forEach { zoom ->
            val b = cameraButton(if (zoom == .5f) ".5x" else "${zoom.toInt()}x") {
                setZoom(zoom)
            }
            b.textSize = 15f
            b.background = roundBackground(if (zoom == 1f) Color.rgb(40, 40, 40) else Color.rgb(25, 25, 25))
            zoomRow.addView(b, LinearLayout.LayoutParams(dp(62), dp(62)).apply {
                marginStart = dp(7); marginEnd = dp(7)
            })
        }
        bottom.addView(zoomRow, LinearLayout.LayoutParams(-1, dp(68)))

        val actionRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(8), dp(12), dp(2))
        }
        galleryThumbnail = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackground(roundBackground(Color.rgb(45, 45, 45)))
            setImageResource(android.R.drawable.ic_menu_gallery)
            contentDescription = "Preview foto terakhir. Ketuk untuk membuka foto"
            setOnClickListener {
                val uri = latestPhotoUri
                if (uri != null) showPhotoPreview(uri, allowEdit = true)
                else photoPicker.launch("image/*")
            }
        }
        actionRow.addView(galleryThumbnail, LinearLayout.LayoutParams(dp(68), dp(68)))
        val shutterWrap = FrameLayout(this)
        shutterButton = Button(this).apply {
            text = "●"
            textSize = 36f
            setTextColor(Color.BLACK)
            isAllCaps = false
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.WHITE)
                setStroke(dp(5), Color.WHITE)
            }
            setOnClickListener { captureBurst() }
        }
        shutterWrap.addView(shutterButton, FrameLayout.LayoutParams(dp(84), dp(84), Gravity.CENTER))
        actionRow.addView(shutterWrap, LinearLayout.LayoutParams(0, dp(92), 1f))
        val aiButton = cameraButton("✦") {
            aiGuideEnabled = true
            overlay.aiGuidesEnabled = true
            overlay.invalidate()
            triggerAiRecommendation()
        }.apply {
            textSize = 30f
            setTextColor(Color.rgb(255, 220, 0))
            background = roundBackground(Color.rgb(48, 40, 0))
        }
        actionRow.addView(aiButton, LinearLayout.LayoutParams(dp(68), dp(68)))
        bottom.addView(actionRow, LinearLayout.LayoutParams(-1, dp(96)))
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(246)))
        setContentView(root)

        toneButton = cameraButton("Tone") { cycleTone(toneButton) }
        statusText.text = "Point your camera and tap the ✦ button"
    }

    private lateinit var toneButton: Button

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun cameraLabel(textValue: String, size: Float) = TextView(this).apply {
        text = textValue
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun cameraButton(label: String, action: (View) -> Unit) =
        Button(this).apply {
            text = label
            textSize = 18f
            isAllCaps = false
            minWidth = 0
            minHeight = 0
            setPadding(dp(5), 0, dp(5), 0)
            setTextColor(Color.WHITE)
            background = roundBackground(Color.TRANSPARENT)
            setOnClickListener(action)
        }

    private fun roundBackground(color: Int) =
        android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            setColor(color)
            cornerRadius = dp(40).toFloat()
        }

    private fun setZoom(requested: Float) {
        val camera = boundCamera ?: return
        val state = camera.cameraInfo.zoomState.value ?: return
        zoomRatio = requested.coerceIn(state.minZoomRatio, state.maxZoomRatio)
        camera.cameraControl.setZoomRatio(zoomRatio)
        statusText.text = "Zoom ${"%.1f".format(zoomRatio)}x • $horizonAdvice"
    }

    private fun showCameraOptions() {
        val options = arrayOf("Grid ON/OFF", "Auto / Manual framing", "Subject tracking ON/OFF", "Color tone")
        android.app.AlertDialog.Builder(this)
            .setTitle("BestShot controls")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> { overlay.gridEnabled = !overlay.gridEnabled; overlay.invalidate(); statusText.text = "Grid ${if (overlay.gridEnabled) "ON" else "OFF"}" }
                    1 -> { manualFraming = !manualFraming; updateAdvice() }
                    2 -> { trackingEnabled = !trackingEnabled; if (!trackingEnabled) lastTrackedBox = null; updateAdvice() }
                    3 -> openColorStudio()
                }
            }.show()
    }

    private fun controlButton(label: String, action: (View) -> Unit) =
        Button(this).apply {
            text = label
            textSize = 10f
            isAllCaps = false
            minWidth = 0
            setPadding(2, 0, 2, 0)
            setOnClickListener(action)
        }

    private fun cycleTone(button: Button) {
        currentTone = Tone.values()[(currentTone.ordinal + 1) % Tone.values().size]
        overlay.toneTint = currentTone.tint
        overlay.invalidate()
        button.text = "Tone ${currentTone.title}"
        updateAdvice()
    }

    private fun adjustExposure(direction: Int) {
        val camera = boundCamera ?: return
        val state = camera.cameraInfo.exposureState
        exposureSteps = (state.exposureCompensationIndex + direction).coerceIn(
            state.exposureCompensationRange.lower, state.exposureCompensationRange.upper
        )
        camera.cameraControl.setExposureCompensationIndex(exposureSteps)
        updateAdvice("Exposure index $exposureSteps")
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setJpegQuality(100)
                    .build()
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setTargetResolution(android.util.Size(640, 480))
                    .build()
                analysis.setAnalyzer(cameraExecutor, ::analyzeFrame)
                provider.unbindAll()
                boundCamera = provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture, analysis
                )
                statusText.text = "Kamera aktif • deteksi lokal • ${horizonAdvice}"
            } catch (e: Exception) {
                statusText.text = "Kamera gagal dibuka: ${e.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    private fun analyzeFrame(proxy: ImageProxy) {
        val now = System.currentTimeMillis()
        if (analysisBusy || now - lastAnalysisAt < 450L) {
            proxy.close()
            return
        }
        val media = proxy.image
        if (media == null) {
            proxy.close()
            return
        }
        analysisBusy = true
        lastAnalysisAt = now
        val input = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)

        // All three tasks read the same frame. Close ImageProxy only after all complete.
        val objectTask = objectDetector.process(input)
        val faceTask = faceDetector.process(input)
        val labelTask = imageLabeler.process(input)
        var completed = 0
        fun taskFinished() {
            completed++
            if (completed == 3) {
                proxy.close()
                analysisBusy = false
            }
        }

        var objectRects = emptyList<Rect>()
        var faceRects = emptyList<Rect>()
        var labels = emptyList<ImageLabel>()
        objectTask.addOnSuccessListener { objectRects = it.map { item -> Rect(item.boundingBox) } }
            .addOnCompleteListener { taskFinished() }
        faceTask.addOnSuccessListener { faceRects = it.map { item -> Rect(item.boundingBox) } }
            .addOnCompleteListener { taskFinished() }
        labelTask.addOnSuccessListener { labels = it }
            .addOnCompleteListener { taskFinished() }

        // Publish once the three asynchronous results are complete.
        val publish = {
            val boxes = faceRects + objectRects
            analysisWidth = input.width
            analysisHeight = input.height
            val bestBox = selectTrackedBox(boxes, input.width, input.height)
            val labelNames = labels.sortedByDescending { it.confidence }.take(5).map { it.text }
            latestLabels = labelNames
            latestSubject = when {
                faceRects.isNotEmpty() -> "Manusia/wajah terdeteksi"
                labelNames.isNotEmpty() -> "Adegan: ${labelNames.take(2).joinToString(", ")}"
                objectRects.isNotEmpty() -> "Objek terdeteksi"
                else -> "Belum ada subjek dominan"
            }
            runOnUiThread {
                overlay.setDetections(if (trackingEnabled) listOfNotNull(bestBox) else boxes)
                updateAdvice()
            }
        }
        // A small completion barrier avoids reading partial detector results.
        objectTask.addOnCompleteListener {
            faceTask.addOnCompleteListener {
                labelTask.addOnCompleteListener { publish() }
            }
        }
    }

    private fun selectTrackedBox(boxes: List<Rect>, imageWidth: Int, imageHeight: Int): Rect? {
        if (boxes.isEmpty()) {
            lastTrackedBox = null
            return null
        }
        val candidates = boxes.map { RectF(it) }
        val previous = lastTrackedBox
        val chosen = if (!trackingEnabled || previous == null) {
            candidates.maxByOrNull { it.width() * it.height() }!!
        } else {
            candidates.minByOrNull { centerDistance(previous, it, imageWidth, imageHeight) }!!
        }
        lastTrackedBox = if (previous != null && trackingEnabled) {
            RectF(
                previous.left * .35f + chosen.left * .65f,
                previous.top * .35f + chosen.top * .65f,
                previous.right * .35f + chosen.right * .65f,
                previous.bottom * .35f + chosen.bottom * .65f
            )
        } else chosen
        return Rect(
            lastTrackedBox!!.left.toInt(), lastTrackedBox!!.top.toInt(),
            lastTrackedBox!!.right.toInt(), lastTrackedBox!!.bottom.toInt()
        )
    }

    private fun centerDistance(a: RectF, b: RectF, w: Int, h: Int): Float {
        val dx = (a.centerX() - b.centerX()) / max(1, w).toFloat()
        val dy = (a.centerY() - b.centerY()) / max(1, h).toFloat()
        return dx * dx + dy * dy
    }

    private fun triggerAiRecommendation() {
        if (!::subjectChip.isInitialized) return
        aiScanRequested = true
        overlay.aiGuidesEnabled = true
        overlay.invalidate()
        if (lastTrackedBox == null && latestLabels.isEmpty()) {
            subjectChip.text = "SCANNING FOR SUBJECT ↑"
            statusText.text = "Sedang mencari subjek. Arahkan kamera perlahan ke objek."
            guideMessage = "Mencari subjek utama…"
            return
        }
        updateAdvice("✦ Arahkan kamera mengikuti panduan")
    }

    private fun updateAdvice(extra: String? = null) {
        val box = lastTrackedBox
        val frameAdvice = when {
            manualFraming -> "Mode manual: atur komposisi memakai grid"
            box == null -> if (aiScanRequested) "Mencari subjek utama…" else "Arahkan kamera ke subjek utama"
            else -> {
                val fraction = (box.width() * box.height()) /
                    max(1f, analysisWidth.toFloat() * analysisHeight.toFloat())
                when {
                    fraction < .035f -> "Subjek kecil: dekati sedikit"
                    fraction > .58f -> "Subjek terlalu dekat: mundur sedikit"
                    else -> ""
                }
            }
        }

        val angle = if (manualFraming || box == null) {
            guideDx = 0f; guideDy = 0f
            if (box == null && aiScanRequested) "Mencari subjek utama…" else "Gunakan grid untuk menentukan posisi subjek"
        } else {
            val cx = (box.centerX() / max(1f, analysisWidth.toFloat())).coerceIn(0f, 1f)
            val cy = (box.centerY() / max(1f, analysisHeight.toFloat())).coerceIn(0f, 1f)
            subjectCenterX = cx
            subjectCenterY = cy
            // The yellow target box marks the recommended placement. Camera movement is
            // opposite to the subject's movement in the viewfinder.
            val errorX = targetCenterX - cx
            val errorY = targetCenterY - cy
            guideDx = (-errorX).coerceIn(-.8f, .8f)
            guideDy = (-errorY).coerceIn(-.8f, .8f)
            when {
                abs(errorX) > .12f && abs(errorX) >= abs(errorY) -> if (errorX > 0f) "Geser kamera ke kiri ←" else "Geser kamera ke kanan →"
                abs(errorY) > .12f -> if (errorY > 0f) "Naikkan kamera sedikit ↑" else "Turunkan kamera sedikit ↓"
                else -> sceneRecommendation(latestLabels)
            }
        }
        guideMessage = angle
        overlay.guideDx = guideDx
        overlay.guideDy = guideDy
        overlay.subjectCenterX = subjectCenterX
        overlay.subjectCenterY = subjectCenterY
        overlay.targetCenterX = targetCenterX
        overlay.targetCenterY = targetCenterY
        overlay.invalidate()

        val scene = latestLabels.take(2).joinToString(", ")
        val chipText = when {
            box != null && scene.isNotBlank() -> "${scene.lowercase()}  ↑"
            box != null -> "SUBJEK TERDETEKSI  ↑"
            latestLabels.isNotEmpty() -> "${scene.lowercase()}  ↑"
            aiScanRequested -> "SCANNING FOR SUBJECT ↑"
            else -> "AIM AT YOUR SUBJECT"
        }
        if (::subjectChip.isInitialized) subjectChip.text = chipText
        val advice = if (box != null) angle else frameAdvice
        statusText.text = listOf(frameAdvice, advice, horizonAdvice, extra).filter { it.isNotBlank() }.joinToString(" • ")
    }

    private fun openColorStudio() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(6))
        }
        val description = TextView(this).apply {
            text = "Pilih tone. Preview kamera berubah, lalu terapkan ke foto tanpa menimpa file asli."
            textSize = 13f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
        }
        panel.addView(description, LinearLayout.LayoutParams(-1, dp(54)))
        val selected = TextView(this).apply {
            text = "Tone aktif: ${currentTone.title}"
            textSize = 15f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }
        panel.addView(selected, LinearLayout.LayoutParams(-1, dp(42)))
        val previewSwatch = View(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(currentTone.tint.takeIf { it != Color.TRANSPARENT } ?: Color.rgb(110, 110, 110))
            }
        }
        panel.addView(previewSwatch, LinearLayout.LayoutParams(-1, dp(34)).apply { bottomMargin = dp(8) })
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Color Studio")
            .setView(panel)
            .setPositiveButton("Pilih foto untuk edit", null)
            .setNegativeButton("Selesai", null)
            .create()
        Tone.values().forEach { tone ->
            val choice = Button(this).apply {
                text = (if (tone == currentTone) "✓  " else "    ") + tone.title
                isAllCaps = false
                setTextColor(Color.DKGRAY)
                gravity = Gravity.CENTER_VERTICAL
                setOnClickListener {
                    currentTone = tone
                    this@MainActivity.overlay.toneTint = tone.tint
                    this@MainActivity.overlay.invalidate()
                    selected.text = "Tone aktif: ${tone.title}"
                    previewSwatch.background = android.graphics.drawable.GradientDrawable().apply {
                        cornerRadius = dp(12).toFloat()
                        setColor(tone.tint.takeIf { it != Color.TRANSPARENT } ?: Color.rgb(110, 110, 110))
                    }
                    statusText.text = "Color Studio: ${tone.title} dipilih"
                    (it as Button).text = "✓  ${tone.title}"
                }
            }
            panel.addView(choice, LinearLayout.LayoutParams(-1, dp(42)))
        }
        dialog.setOnShowListener {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                dialog.dismiss()
                photoPicker.launch("image/*")
            }
        }
        dialog.show()
    }

    private fun showPhotoPreview(uri: Uri, allowEdit: Boolean) {
        val image = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
        }
        try {
            image.setImageURI(uri)
        } catch (_: Exception) {
            Toast.makeText(this, "Foto tidak dapat dibuka", Toast.LENGTH_SHORT).show()
            return
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(4))
            addView(image, LinearLayout.LayoutParams(-1, dp(420)))
        }
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Preview foto")
            .setView(container)
            .setPositiveButton(if (allowEdit) "Terapkan ${currentTone.title}" else "Tutup", null)
            .setNeutralButton("Pilih foto lain", null)
            .setNegativeButton("Tutup", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (!allowEdit) { dialog.dismiss(); return@setOnClickListener }
                dialog.dismiss()
                applyToneToUri(uri)
            }
            dialog.getButton(android.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                dialog.dismiss()
                photoPicker.launch("image/*")
            }
        }
        dialog.show()
    }

    private fun applyToneToUri(uri: Uri) {
        cameraExecutor.execute {
            try {
                val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                    ?: throw IllegalStateException("Foto tidak dapat dibuka")
                val edited = applyTone(bitmap, currentTone)
                val saved = saveEditedBitmap(edited)
                bitmap.recycle()
                edited.recycle()
                runOnUiThread {
                    statusText.text = if (saved) "Salinan ${currentTone.title} tersimpan. Foto asli tetap aman." else "Gagal menyimpan hasil edit."
                    Toast.makeText(this, statusText.text, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread { statusText.text = "Edit gagal: ${e.localizedMessage}" }
            }
        }
    }

    private fun sceneRecommendation(labels: List<String>): String {
        val text = labels.joinToString(" ").lowercase()
        return when {
            text.contains("food") || text.contains("dish") -> "Saran: ambil sedikit dari atas, jaga detail makanan"
            text.contains("plant") || text.contains("flower") -> "Saran: pisahkan subjek dari latar"
            text.contains("building") || text.contains("architecture") -> "Saran: jaga garis vertikal tetap lurus"
            text.contains("landscape") || text.contains("sky") || text.contains("mountain") -> "Saran: tempatkan horizon di garis sepertiga"
            text.contains("animal") || text.contains("dog") || text.contains("cat") || text.contains("bird") -> "Saran: sejajarkan kamera dengan tinggi subjek"
            text.contains("person") || text.contains("people") -> "Saran: sisakan ruang di atas kepala"
            else -> "Saran: tempatkan subjek utama di titik sepertiga"
        }
    }

    private fun applyTone(source: Bitmap, tone: Tone): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix(tone.matrix))
        }
        canvas.drawBitmap(source, 0f, 0f, paint)
        return output
    }

    private fun saveEditedBitmap(bitmap: Bitmap): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "BestShot_Edit_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BestShotAI/Edits")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            val stream = contentResolver.openOutputStream(uri) ?: throw IllegalStateException("Penyimpanan tidak tersedia")
            stream.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 100, it) }
            true
        } catch (_: Exception) {
            contentResolver.delete(uri, null, null)
            false
        }
    }

    override fun onResume() {
        super.onResume()
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.also {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        sensorManager.unregisterListener(this)
        super.onPause()
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0]
        val y = event.values[1]
        rollDegrees = Math.toDegrees(kotlin.math.atan2(x.toDouble(), y.toDouble())).toFloat()
        overlay.rollDegrees = rollDegrees
        horizonAdvice = if (abs(rollDegrees) < 2.5f) "Horizon lurus" else "Miring ${"%.1f".format(abs(rollDegrees))}°"
        overlay.invalidate()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun captureBurst() {
        val capture = imageCapture ?: return
        if (isCapturing) return
        isCapturing = true
        shutterButton.isEnabled = false
        statusText.text = "Mengambil 3 foto dengan kualitas kamera maksimal…"
        captureNext(capture, mutableListOf(), 0)
    }

    private fun captureNext(capture: ImageCapture, files: MutableList<File>, index: Int) {
        if (index >= burstSize) {
            cameraExecutor.execute { chooseAndSaveBest(files) }
            return
        }
        val file = File(cacheDir, "bestshot_${System.nanoTime()}.jpg")
        val options = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                files.add(file)
                if (index + 1 < burstSize) statusText.text = "Foto ${index + 2}/$burstSize…"
                else statusText.text = "Memilih foto paling tajam…"
                captureNext(capture, files, index + 1)
            }
            override fun onError(exception: ImageCaptureException) {
                files.forEach { it.delete() }
                finishCapture("Capture gagal: ${exception.message}")
            }
        })
    }

    private fun chooseAndSaveBest(files: List<File>) {
        try {
            val scored = files.mapNotNull { f -> scoreImage(f)?.let { f to it } }
            val best = scored.maxByOrNull { it.second } ?: error("Tidak ada foto yang bisa dianalisis")
            val savedUri = saveOriginalJpeg(best.first)
            files.forEach { it.delete() }
            runOnUiThread {
                if (savedUri != null) updateGalleryThumbnail(savedUri)
                finishCapture(if (savedUri != null) "Foto terbaik tersimpan. JPEG kamera asli dipertahankan ✓" else "Gagal menyimpan foto")
            }
        } catch (e: Exception) {
            files.forEach { it.delete() }
            runOnUiThread { finishCapture("Analisis foto gagal: ${e.localizedMessage}") }
        }
    }

    // Decodes only a small sample for scoring. The selected original JPEG file is copied byte-for-byte.
    private fun scoreImage(file: File): Double? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sampleSize = 1
        while (max(bounds.outWidth, bounds.outHeight) / sampleSize > 1000) sampleSize *= 2
        val bitmap = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.RGB_565
        }) ?: return null
        try {
            val w = bitmap.width; val h = bitmap.height
            if (w < 3 || h < 3) return 0.0
            val px = IntArray(w * h)
            bitmap.getPixels(px, 0, w, 0, 0, w, h)
            fun lum(c: Int) = .299 * Color.red(c) + .587 * Color.green(c) + .114 * Color.blue(c)
            var sharp = 0.0; var bright = 0.0; var clipped = 0; var count = 0
            for (y in 1 until h - 1) for (x in 1 until w - 1) {
                val i = y * w + x
                val c = lum(px[i])
                sharp += abs(4 * c - lum(px[i - 1]) - lum(px[i + 1]) - lum(px[i - w]) - lum(px[i + w]))
                bright += c
                if (c < 7 || c > 248) clipped++
                count++
            }
            if (count == 0) return 0.0
            val average = bright / count
            val exposurePenalty = abs(average - 128.0) / 128.0
            val clippingPenalty = clipped.toDouble() / count
            return (sharp / count) * (1.0 - .30 * exposurePenalty) * (1.0 - clippingPenalty)
        } finally {
            bitmap.recycle()
        }
    }

    private fun saveOriginalJpeg(file: File): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "BestShot_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BestShotAI")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            val output = contentResolver.openOutputStream(uri) ?: error("Tidak bisa membuka galeri")
            output.use { out -> file.inputStream().use { input -> input.copyTo(out) } }
            uri
        } catch (_: Exception) {
            contentResolver.delete(uri, null, null)
            null
        }
    }

    private fun updateGalleryThumbnail(uri: Uri) {
        latestPhotoUri = uri
        try {
            val bitmap = if (android.os.Build.VERSION.SDK_INT >= 29) {
                contentResolver.loadThumbnail(uri, Size(240, 240), null)
            } else {
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }
            if (bitmap != null) galleryThumbnail.setImageBitmap(bitmap)
        } catch (_: Exception) { galleryThumbnail.setImageResource(android.R.drawable.ic_menu_gallery) }
    }

    private fun loadLatestPhoto() {
        try {
            val projection = arrayOf(MediaStore.Images.Media._ID)
            val selection = if (android.os.Build.VERSION.SDK_INT >= 29) "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?" else null
            val args = if (selection != null) arrayOf("Pictures/BestShotAI%") else null
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                args,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
                    val uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                    updateGalleryThumbnail(uri)
                }
            }
        } catch (_: Exception) { /* Gallery picker remains available through the thumbnail. */ }
    }

    private fun finishCapture(message: String) {
        isCapturing = false
        shutterButton.isEnabled = true
        statusText.text = message
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        if (::cameraExecutor.isInitialized) cameraExecutor.shutdown()
        objectDetector.close()
        faceDetector.close()
        imageLabeler.close()
        super.onDestroy()
    }

    private inner class GuideOverlay : View(this@MainActivity) {
        var gridEnabled = true
        var rollDegrees = 0f
        var toneTint = Color.TRANSPARENT
        var aiGuidesEnabled = false
        var guideDx = 0f
        var guideDy = 0f
        var subjectCenterX = .5f
        var subjectCenterY = .5f
        var targetCenterX = .62f
        var targetCenterY = .46f
        private var boxes: List<Rect> = emptyList()
        private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(155, 255, 255, 255); strokeWidth = 1.5f; style = Paint.Style.STROKE
        }
        private val targetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 214, 0); strokeWidth = dp(3).toFloat(); style = Paint.Style.STROKE
        }
        private val connectorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 214, 0); strokeWidth = dp(2).toFloat(); style = Paint.Style.STROKE
            pathEffect = android.graphics.DashPathEffect(floatArrayOf(dp(7).toFloat(), dp(6).toFloat()), 0f)
        }
        private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 214, 0); strokeWidth = dp(3).toFloat(); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
        }
        private val tintPaint = Paint()
        fun setDetections(value: List<Rect>) { boxes = value; invalidate() }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            if (gridEnabled) {
                canvas.drawLine(w / 3f, 0f, w / 3f, h, gridPaint)
                canvas.drawLine(2f * w / 3f, 0f, 2f * w / 3f, h, gridPaint)
                canvas.drawLine(0f, h / 3f, w, h / 3f, gridPaint)
                canvas.drawLine(0f, 2f * h / 3f, w, 2f * h / 3f, gridPaint)
            }
            canvas.save()
            canvas.rotate(rollDegrees, w / 2f, h / 2f)
            canvas.drawLine(w * .34f, h / 2f, w * .66f, h / 2f, gridPaint)
            canvas.restore()

            if (aiGuidesEnabled) {
                // Persistent yellow target frame. It never turns green; shutter stays manual.
                val tx = targetCenterX * w
                val ty = targetCenterY * h
                val bw = w * .34f
                val bh = h * .25f
                val target = RectF(tx - bw / 2f, ty - bh / 2f, tx + bw / 2f, ty + bh / 2f)
                canvas.drawRoundRect(target, dp(16).toFloat(), dp(16).toFloat(), targetPaint)

                if (boxes.isNotEmpty()) {
                    val sx = subjectCenterX * w
                    val sy = subjectCenterY * h
                    canvas.drawLine(sx, sy, tx, ty, connectorPaint)
                    // Direction arrow from view center toward the suggested camera movement.
                    val cx = w * .5f
                    val cy = h * .72f
                    val dx = guideDx * w * .18f
                    val dy = guideDy * h * .14f
                    if (abs(dx) > dp(5) || abs(dy) > dp(5)) {
                        val ex = cx + dx
                        val ey = cy + dy
                        canvas.drawLine(cx, cy, ex, ey, arrowPaint)
                        val angle = kotlin.math.atan2(dy, dx)
                        val head = dp(13).toFloat()
                        val a1 = angle + Math.PI * .78
                        val a2 = angle - Math.PI * .78
                        canvas.drawLine(ex, ey, ex + kotlin.math.cos(a1).toFloat() * head, ey + kotlin.math.sin(a1).toFloat() * head, arrowPaint)
                        canvas.drawLine(ex, ey, ex + kotlin.math.cos(a2).toFloat() * head, ey + kotlin.math.sin(a2).toFloat() * head, arrowPaint)
                    }
                }
            }
            if (toneTint != Color.TRANSPARENT) {
                tintPaint.color = toneTint
                canvas.drawRect(0f, 0f, w, h, tintPaint)
            }
        }
    }
}
