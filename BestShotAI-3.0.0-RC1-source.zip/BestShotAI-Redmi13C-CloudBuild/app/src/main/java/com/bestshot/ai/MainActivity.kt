package com.bestshot.ai

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.*
import android.net.Uri
import android.util.Size
import android.util.Rational
import android.widget.ImageView
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.content.Intent
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.core.ViewPort
import androidx.camera.core.Camera as CameraXCamera
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.label.ImageLabel
import com.google.mlkit.vision.label.ImageLabeler
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.ObjectDetector
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity(), SensorEventListener {
    private lateinit var previewView: PreviewView
    private lateinit var overlay: GuideOverlay
    private lateinit var statusText: TextView
    private lateinit var shutterButton: Button
    private lateinit var galleryThumbnail: ImageView
    private var latestPhotoUri: Uri? = null
    private var selectedPhotoUri: Uri? = null
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var sensorManager: SensorManager
    private var imageCapture: ImageCapture? = null
    private var previewUseCase: Preview? = null
    private var analysisUseCase: ImageAnalysis? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var isCapturing = false
    private var analysisBusy = false
    private var lastAnalysisAt = 0L
    private var boundCamera: CameraXCamera? = null
    private var manualFraming = false
    private var trackingEnabled = true
    private var lastTrackedBox: RectF? = null
    private var latestLabels: List<String> = emptyList()
    private var latestSubject = "Mencari subjek…"
    private lateinit var subjectChip: TextView
    private lateinit var ratioButton: TextView
    private var analysisWidth = 640
    private var analysisHeight = 480

    private var currentTone = Tone.NATURAL
    private var editBrightness = 0f
    private var editContrast = 1f
    private var editSaturation = 1f
    private var editHighlights = 0f
    private var editShadows = 0f
    private var editVignette = 0f
    private var editGrain = 0f
    private var editFrame = 0
    private var exposureSteps = 0
    private var zoomRatio = 1f
    private var selectedFrameRatio = 3f / 4f
    private var selectedFrameRatioLabel = "3:4"
    private var torchEnabled = false
    private var aiGuideEnabled = false
    private var rollDegrees = 0f
    private var horizonAdvice = "Horizon stabil"
    private var guideDx = 0f
    private var guideDy = 0f
    private var guideMessage = "Arahkan kamera ke subjek utama"
    private var aiScanRequested = false
    private var subjectCenterX = .5f
    private var subjectCenterY = .5f
    private var targetCenterX = .62f
    private var targetCenterY = .46f

    private val objectDetector: ObjectDetector by lazy {
        ObjectDetection.getClient(
            ObjectDetectorOptions.Builder()
                .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
                .enableClassification()
                .enableMultipleObjects()
                .build()
        )
    }
    private val faceDetector: FaceDetector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .build()
        )
    }
    // ML Kit's on-device base image-labeling model expands scene labels beyond object detector categories.
    private val imageLabeler: ImageLabeler by lazy {
        ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
    }

    private enum class Tone(val title: String, val tint: Int, val matrix: FloatArray) {
        NATURAL("Natural", Color.TRANSPARENT, floatArrayOf(
            1f,0f,0f,0f,0f, 0f,1f,0f,0f,0f, 0f,0f,1f,0f,0f, 0f,0f,0f,1f,0f
        )),
        WARM("Warm", Color.argb(22,255,155,70), floatArrayOf(
            1.08f,0f,0f,0f,5f, 0f,1.01f,0f,0f,1f, 0f,0f,0.91f,0f,-3f, 0f,0f,0f,1f,0f
        )),
        COOL("Cool", Color.argb(20,70,145,255), floatArrayOf(
            0.94f,0f,0f,0f,-2f, 0f,1.01f,0f,0f,1f, 0f,0f,1.10f,0f,4f, 0f,0f,0f,1f,0f
        )),
        FILM("Film", Color.argb(18,180,145,95), floatArrayOf(
            1.04f,0f,0f,0f,3f, 0f,1.00f,0f,0f,0f, 0f,0f,0.91f,0f,2f, 0f,0f,0f,1f,0f
        )),
        VIVID("Vivid", Color.argb(12,255,220,80), floatArrayOf(
            1.18f,0f,0f,0f,-8f, 0f,1.12f,0f,0f,-5f, 0f,0f,1.16f,0f,-7f, 0f,0f,0f,1f,0f
        )),
        MONO("Mono", Color.TRANSPARENT, floatArrayOf(
            0.30f,0.59f,0.11f,0f,0f, 0.30f,0.59f,0.11f,0f,0f, 0.30f,0.59f,0.11f,0f,0f, 0f,0f,0f,1f,0f
        ))
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera() else {
            statusText.text = "Izin kamera diperlukan."
            shutterButton.isEnabled = false
        }
    }

    private val photoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@registerForActivityResult
        selectedPhotoUri = uri
        showPhotoPreview(uri, allowEdit = true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        buildInterface()
        loadLatestPhoto()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildInterface() {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)

        // Top camera toolbar inspired by the supplied reference.
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        ratioButton = cameraLabel("▢   $selectedFrameRatioLabel  ⌄", 17f)
        top.addView(ratioButton, LinearLayout.LayoutParams(0, dp(48), 1f).also {
            ratioButton.setOnClickListener { showAspectRatioOptions() }
        })
        top.addView(cameraButton("ϟ") {
            val camera = boundCamera
            if (camera == null || !camera.cameraInfo.hasFlashUnit()) {
                statusText.text = "Flash tidak tersedia pada kamera ini."
            } else {
                torchEnabled = !torchEnabled
                camera.cameraControl.enableTorch(torchEnabled)
                statusText.text = if (torchEnabled) "Flash menyala" else "Flash mati"
            }
        })
        top.addView(cameraButton("◉") { openColorStudio() })
        top.addView(cameraButton("•••") { showCameraOptions() })
        root.addView(top, LinearLayout.LayoutParams(-1, dp(60)))

        val previewFrame = FrameLayout(this)
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        overlay = GuideOverlay().apply { aiGuidesEnabled = aiGuideEnabled }
        previewFrame.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        previewFrame.addView(overlay, FrameLayout.LayoutParams(-1, -1))

        subjectChip = TextView(this).apply {
            text = "MENCARI SUBJEK…"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.argb(220, 22, 22, 22))
                cornerRadius = dp(28).toFloat()
            }
        }
        val chipParams = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(20)
        }
        previewFrame.addView(subjectChip, chipParams)
        root.addView(previewFrame, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(Color.BLACK)
        }
        statusText = TextView(this).apply {
            text = "Point your camera and tap the ✦ button"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            maxLines = 2
            setPadding(dp(4), dp(3), dp(4), dp(12))
        }
        bottom.addView(statusText, LinearLayout.LayoutParams(-1, dp(42)))

        val zoomRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
        }
        listOf(.5f, 1f, 2f, 5f).forEach { zoom ->
            val b = cameraButton(if (zoom == .5f) ".5x" else "${zoom.toInt()}x") {
                setZoom(zoom)
            }
            b.textSize = 15f
            b.background = roundBackground(if (zoom == 1f) Color.rgb(40, 40, 40) else Color.rgb(25, 25, 25))
            zoomRow.addView(b, LinearLayout.LayoutParams(dp(62), dp(62)).apply {
                marginStart = dp(7); marginEnd = dp(7)
            })
        }
        bottom.addView(zoomRow, LinearLayout.LayoutParams(-1, dp(68)))

        val actionRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(8), dp(12), dp(2))
        }
        galleryThumbnail = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackground(roundBackground(Color.rgb(45, 45, 45)))
            setImageResource(android.R.drawable.ic_menu_gallery)
            contentDescription = "Preview foto terakhir. Ketuk untuk membuka foto"
            setOnClickListener {
                val uri = latestPhotoUri
                if (uri != null) showPhotoPreview(uri, allowEdit = true)
                else photoPicker.launch("image/*")
            }
        }
        actionRow.addView(galleryThumbnail, LinearLayout.LayoutParams(dp(68), dp(68)))
        val shutterWrap = FrameLayout(this)
        shutterButton = Button(this).apply {
            text = "●"
            textSize = 36f
            setTextColor(Color.BLACK)
            isAllCaps = false
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.WHITE)
                setStroke(dp(5), Color.WHITE)
            }
            setOnClickListener { capturePhoto() }
        }
        shutterWrap.addView(shutterButton, FrameLayout.LayoutParams(dp(84), dp(84), Gravity.CENTER))
        actionRow.addView(shutterWrap, LinearLayout.LayoutParams(0, dp(92), 1f))
        val aiButton = cameraButton("✦") {
            aiGuideEnabled = true
            overlay.aiGuidesEnabled = true
            overlay.invalidate()
            triggerAiRecommendation()
        }.apply {
            textSize = 30f
            setTextColor(Color.rgb(255, 220, 0))
            background = roundBackground(Color.rgb(48, 40, 0))
        }
        actionRow.addView(aiButton, LinearLayout.LayoutParams(dp(68), dp(68)))
        bottom.addView(actionRow, LinearLayout.LayoutParams(-1, dp(96)))
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(246)))
        setContentView(root)

        toneButton = cameraButton("Tone") { cycleTone(toneButton) }
        statusText.text = "Point your camera and tap the ✦ button"
    }

    private lateinit var toneButton: Button

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun cameraLabel(textValue: String, size: Float) = TextView(this).apply {
        text = textValue
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun cameraButton(label: String, action: (View) -> Unit) =
        Button(this).apply {
            text = label
            textSize = 18f
            isAllCaps = false
            minWidth = 0
            minHeight = 0
            setPadding(dp(5), 0, dp(5), 0)
            setTextColor(Color.WHITE)
            background = roundBackground(Color.TRANSPARENT)
            setOnClickListener(action)
        }

    private fun roundBackground(color: Int) =
        android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            setColor(color)
            cornerRadius = dp(40).toFloat()
        }

    private fun setZoom(requested: Float) {
        val camera = boundCamera ?: return
        val state = camera.cameraInfo.zoomState.value ?: return
        zoomRatio = requested.coerceIn(state.minZoomRatio, state.maxZoomRatio)
        camera.cameraControl.setZoomRatio(zoomRatio)
        statusText.text = "Zoom ${"%.1f".format(zoomRatio)}x • $horizonAdvice"
    }

    private fun showAspectRatioOptions() {
        val choices = arrayOf("3:4 (Foto)", "4:5 (Portrait)", "1:1 (Square)", "9:16 (Story)")
        android.app.AlertDialog.Builder(this)
            .setTitle("Rasio tampilan")
            .setItems(choices) { _, which ->
                // CameraX ViewPort applies this aspect ratio consistently to preview and
                // ImageCapture, so the saved JPEG is cropped to the selected framing.
                val ratio = choices[which].substringBefore(" ")
                selectedFrameRatioLabel = ratio
                selectedFrameRatio = when (ratio) {
                    "4:5" -> 4f / 5f
                    "1:1" -> 1f
                    "9:16" -> 9f / 16f
                    else -> 3f / 4f
                }
                overlay.frameRatio = selectedFrameRatio
                ratioButton.text = "▢   $selectedFrameRatioLabel  ⌄"
                overlay.invalidate()
                statusText.text = "Menerapkan rasio $ratio…"
                rebindCameraForSelectedRatio()
            }.show()
    }

    private fun showCameraOptions() {
        val options = arrayOf("Grid ON/OFF", "Auto / Manual framing", "Subject tracking ON/OFF", "Color tone")
        android.app.AlertDialog.Builder(this)
            .setTitle("BestShot controls")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> { overlay.gridEnabled = !overlay.gridEnabled; overlay.invalidate(); statusText.text = "Grid ${if (overlay.gridEnabled) "ON" else "OFF"}" }
                    1 -> { manualFraming = !manualFraming; updateAdvice() }
                    2 -> { trackingEnabled = !trackingEnabled; if (!trackingEnabled) lastTrackedBox = null; updateAdvice() }
                    3 -> openColorStudio()
                }
            }.show()
    }

    private fun controlButton(label: String, action: (View) -> Unit) =
        Button(this).apply {
            text = label
            textSize = 10f
            isAllCaps = false
            minWidth = 0
            setPadding(2, 0, 2, 0)
            setOnClickListener(action)
        }

    private fun cycleTone(button: Button) {
        currentTone = Tone.values()[(currentTone.ordinal + 1) % Tone.values().size]
        overlay.toneTint = currentTone.tint
        overlay.invalidate()
        button.text = "Tone ${currentTone.title}"
        updateAdvice()
    }

    private fun adjustExposure(direction: Int) {
        val camera = boundCamera ?: return
        val state = camera.cameraInfo.exposureState
        exposureSteps = (state.exposureCompensationIndex + direction).coerceIn(
            state.exposureCompensationRange.lower, state.exposureCompensationRange.upper
        )
        camera.cameraControl.setExposureCompensationIndex(exposureSteps)
        updateAdvice("Exposure index $exposureSteps")
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider
                val preview = Preview.Builder()
                    .setTargetRotation(previewView.display?.rotation ?: windowManager.defaultDisplay.rotation)
                    .build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setJpegQuality(100)
                    .setTargetRotation(previewView.display?.rotation ?: windowManager.defaultDisplay.rotation)
                    .build()
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setTargetResolution(Size(640, 480))
                    .build()
                analysis.setAnalyzer(cameraExecutor, ::analyzeFrame)
                previewUseCase = preview
                imageCapture = capture
                analysisUseCase = analysis
                bindCameraGroup()
                statusText.text = "Kamera aktif • deteksi lokal • $horizonAdvice"
            } catch (e: Exception) {
                statusText.text = "Kamera gagal dibuka: ${e.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun rebindCameraForSelectedRatio() {
        previewView.post {
            try {
                bindCameraGroup()
                statusText.text = "Rasio $selectedFrameRatioLabel diterapkan ke preview dan hasil foto."
            } catch (e: Exception) {
                statusText.text = "Gagal menerapkan rasio: ${e.localizedMessage}"
            }
        }
    }

    private fun bindCameraGroup() {
        val provider = cameraProvider ?: return
        val preview = previewUseCase ?: return
        val capture = imageCapture ?: return
        val analysis = analysisUseCase ?: return
        val rotation = previewView.display?.rotation ?: windowManager.defaultDisplay.rotation
        val ratioWidth = when (selectedFrameRatioLabel) {
            "4:5" -> 4
            "1:1" -> 1
            "9:16" -> 9
            else -> 3
        }
        val ratioHeight = when (selectedFrameRatioLabel) {
            "4:5" -> 5
            "1:1" -> 1
            "9:16" -> 16
            else -> 4
        }
        val viewport = ViewPort.Builder(Rational(ratioWidth, ratioHeight), rotation)
            .setScaleType(ViewPort.FILL_CENTER)
            .build()
        val group = UseCaseGroup.Builder()
            .setViewPort(viewport)
            .addUseCase(preview)
            .addUseCase(capture)
            .addUseCase(analysis)
            .build()
        preview.targetRotation = rotation
        capture.targetRotation = rotation
        analysis.targetRotation = rotation
        provider.unbindAll()
        boundCamera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, group)
    }

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    private fun analyzeFrame(proxy: ImageProxy) {
        val now = System.currentTimeMillis()
        if (analysisBusy || now - lastAnalysisAt < 450L) {
            proxy.close()
            return
        }
        val media = proxy.image
        if (media == null) {
            proxy.close()
            return
        }
        analysisBusy = true
        lastAnalysisAt = now
        val rotationDegrees = proxy.imageInfo.rotationDegrees
        val rotatedWidth = if (rotationDegrees == 90 || rotationDegrees == 270) proxy.height else proxy.width
        val rotatedHeight = if (rotationDegrees == 90 || rotationDegrees == 270) proxy.width else proxy.height
        val input = InputImage.fromMediaImage(media, rotationDegrees)

        // All three tasks read the same frame. Close ImageProxy only after all complete.
        val objectTask = objectDetector.process(input)
        val faceTask = faceDetector.process(input)
        val labelTask = imageLabeler.process(input)
        var completed = 0
        fun taskFinished() {
            completed++
            if (completed == 3) {
                proxy.close()
                analysisBusy = false
            }
        }

        var objectRects = emptyList<Rect>()
        var objectNames = emptyList<Pair<String, Float>>()
        var faceRects = emptyList<Rect>()
        var labels = emptyList<ImageLabel>()
        objectTask.addOnSuccessListener { detected ->
            objectRects = detected.map { item -> Rect(item.boundingBox) }
            objectNames = detected.flatMap { item ->
                item.labels.map { label -> label.text to label.confidence }
            }
        }.addOnCompleteListener { taskFinished() }
        faceTask.addOnSuccessListener { faceRects = it.map { item -> Rect(item.boundingBox) } }
            .addOnCompleteListener { taskFinished() }
        labelTask.addOnSuccessListener { labels = it }
            .addOnCompleteListener { taskFinished() }

        // Publish once the three asynchronous results are complete.
        val publish = {
            val boxes = faceRects + objectRects
            analysisWidth = rotatedWidth
            analysisHeight = rotatedHeight
            val bestBox = selectTrackedBox(boxes, analysisWidth, analysisHeight)
            val labelNames = (objectNames + labels.map { it.text to it.confidence })
                .filter { it.second >= .35f }
                .sortedByDescending { it.second }
                .map { it.first }
                .distinct()
                .take(5)
            latestLabels = labelNames
            latestSubject = when {
                faceRects.isNotEmpty() -> "Manusia/wajah terdeteksi"
                labelNames.isNotEmpty() -> "Adegan: ${labelNames.take(2).joinToString(", ")}"
                objectRects.isNotEmpty() -> "Objek terdeteksi"
                else -> "Belum ada subjek dominan"
            }
            runOnUiThread {
                overlay.setDetections(if (trackingEnabled) listOfNotNull(bestBox) else boxes)
                updateAdvice()
            }
        }
        // A small completion barrier avoids reading partial detector results.
        objectTask.addOnCompleteListener {
            faceTask.addOnCompleteListener {
                labelTask.addOnCompleteListener { publish() }
            }
        }
    }

    private fun selectTrackedBox(boxes: List<Rect>, imageWidth: Int, imageHeight: Int): Rect? {
        if (boxes.isEmpty()) {
            lastTrackedBox = null
            return null
        }
        val candidates = boxes.map { RectF(it) }
        val previous = lastTrackedBox
        val chosen = if (!trackingEnabled || previous == null) {
            candidates.maxByOrNull { it.width() * it.height() }!!
        } else {
            candidates.minByOrNull { centerDistance(previous, it, imageWidth, imageHeight) }!!
        }
        lastTrackedBox = if (previous != null && trackingEnabled) {
            RectF(
                previous.left * .35f + chosen.left * .65f,
                previous.top * .35f + chosen.top * .65f,
                previous.right * .35f + chosen.right * .65f,
                previous.bottom * .35f + chosen.bottom * .65f
            )
        } else chosen
        return Rect(
            lastTrackedBox!!.left.toInt(), lastTrackedBox!!.top.toInt(),
            lastTrackedBox!!.right.toInt(), lastTrackedBox!!.bottom.toInt()
        )
    }

    private fun centerDistance(a: RectF, b: RectF, w: Int, h: Int): Float {
        val dx = (a.centerX() - b.centerX()) / max(1, w).toFloat()
        val dy = (a.centerY() - b.centerY()) / max(1, h).toFloat()
        return dx * dx + dy * dy
    }

    private fun triggerAiRecommendation() {
        if (!::subjectChip.isInitialized) return
        aiScanRequested = true
        overlay.aiGuidesEnabled = true
        overlay.invalidate()
        if (lastTrackedBox == null) {
            subjectChip.text = "SCANNING FOR SUBJECT ↑"
            statusText.text = "Sedang memindai. Arahkan kamera perlahan ke objek."
            guideMessage = "Mencari subjek utama…"
            overlay.subjectBounds = null
            overlay.invalidate()
            return
        }
        updateAdvice()
    }

    private fun updateAdvice(extra: String? = null) {
        val box = lastTrackedBox
        val frameAdvice = when {
            manualFraming -> "Mode manual: atur komposisi memakai grid"
            box == null -> if (aiScanRequested) "Arahkan kamera perlahan ke subjek" else "Arahkan kamera ke subjek utama"
            else -> {
                val fraction = (box.width() * box.height()) /
                    max(1f, analysisWidth.toFloat() * analysisHeight.toFloat())
                when {
                    fraction < .025f -> "Subjek terlalu kecil: dekati sedikit"
                    fraction > .62f -> "Subjek terlalu besar: mundur sedikit"
                    else -> ""
                }
            }
        }

        val angle = if (manualFraming || box == null) {
            guideDx = 0f
            guideDy = 0f
            overlay.subjectBounds = null
            if (aiScanRequested) "Mencari subjek utama…" else "Tekan ✦ untuk mendapat arahan komposisi"
        } else {
            val width = max(1f, analysisWidth.toFloat())
            val height = max(1f, analysisHeight.toFloat())
            val bounds = RectF(
                (box.left / width).coerceIn(0f, 1f),
                (box.top / height).coerceIn(0f, 1f),
                (box.right / width).coerceIn(0f, 1f),
                (box.bottom / height).coerceIn(0f, 1f)
            )
            overlay.subjectBounds = bounds
            val cx = bounds.centerX()
            val cy = bounds.centerY()
            subjectCenterX = cx
            subjectCenterY = cy

            val errorX = targetCenterX - cx
            val errorY = targetCenterY - cy
            guideDx = (-errorX).coerceIn(-.8f, .8f)
            guideDy = (-errorY).coerceIn(-.8f, .8f)
            when {
                abs(errorX) > .075f && abs(errorX) >= abs(errorY) ->
                    if (errorX > 0f) "Geser kamera ke kiri ←" else "Geser kamera ke kanan →"
                abs(errorY) > .075f ->
                    if (errorY > 0f) "Naikkan kamera sedikit ↑" else "Turunkan kamera sedikit ↓"
                else -> sceneRecommendation(latestLabels)
            }
        }

        guideMessage = angle
        overlay.guideDx = guideDx
        overlay.guideDy = guideDy
        overlay.subjectCenterX = subjectCenterX
        overlay.subjectCenterY = subjectCenterY
        overlay.sourceAspectRatio = analysisWidth.toFloat() / max(1f, analysisHeight.toFloat())
        overlay.targetCenterX = targetCenterX
        overlay.targetCenterY = targetCenterY
        overlay.aiGuidesEnabled = aiGuideEnabled
        overlay.invalidate()

        val scene = latestLabels.firstOrNull().orEmpty()
        val chipText = when {
            box != null && scene.isNotBlank() -> scene.lowercase()
            box != null -> "SUBJEK TERDETEKSI"
            aiScanRequested -> "SCANNING FOR SUBJECT ↑"
            else -> "AIM AT YOUR SUBJECT"
        }
        if (::subjectChip.isInitialized) subjectChip.text = chipText
        val parts = mutableListOf<String>()
        if (frameAdvice.isNotBlank()) parts.add(frameAdvice)
        if (box != null || aiScanRequested) parts.add(angle)
        if (aiGuideEnabled && box != null && abs(rollDegrees) >= 2.5f) parts.add(horizonAdvice)
        if (!extra.isNullOrBlank()) parts.add(extra)
        statusText.text = parts.distinct().joinToString(" • ")
    }

    private fun openColorStudio() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val scroll = android.widget.ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        fun section(name: String) {
            content.addView(TextView(this).apply {
                text = name
                textSize = 14f
                setTextColor(Color.BLACK)
                setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(0, dp(10), 0, dp(4))
            })
        }
        fun slider(name: String, maxValue: Int, initial: Int, update: (Int) -> Unit) {
            val label = TextView(this).apply { text = "$name: $initial"; setTextColor(Color.DKGRAY); textSize = 13f }
            content.addView(label)
            content.addView(SeekBar(this).apply {
                max = maxValue
                progress = initial
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        label.text = "$name: $progress"
                        update(progress)
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                    override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
                })
            })
        }
        section("LOOKS")
        Tone.values().forEach { tone ->
            content.addView(Button(this).apply {
                text = "●  ${tone.title}"
                isAllCaps = false
                setTextColor(Color.WHITE)
                background = roundBackground(when (tone) {
                    Tone.NATURAL -> Color.DKGRAY
                    Tone.WARM -> Color.rgb(150, 92, 42)
                    Tone.COOL -> Color.rgb(48, 92, 145)
                    Tone.FILM -> Color.rgb(112, 91, 65)
                    Tone.VIVID -> Color.rgb(145, 105, 25)
                    Tone.MONO -> Color.rgb(75, 75, 75)
                })
                setOnClickListener {
                    currentTone = tone
                    overlay.toneTint = tone.tint
                    overlay.invalidate()
                    statusText.text = "Looks: ${tone.title} dipilih"
                }
            })
        }
        section("ADJUST")
        slider("Exposure", 200, (editBrightness + 100).toInt()) { editBrightness = it - 100f }
        slider("Contrast", 200, (editContrast * 100).toInt()) { editContrast = it.coerceAtLeast(1) / 100f }
        slider("Saturation", 200, (editSaturation * 100).toInt()) { editSaturation = it / 100f }
        slider("Highlights", 200, (editHighlights * 100 + 100).toInt()) { editHighlights = (it - 100) / 100f }
        slider("Shadows", 200, (editShadows * 100 + 100).toInt()) { editShadows = (it - 100) / 100f }
        section("EFFECTS")
        slider("Vignette", 100, (editVignette * 100).toInt()) { editVignette = it / 100f }
        slider("Grain", 100, (editGrain * 100).toInt()) { editGrain = it / 100f }
        section("FRAMES")
        val frameNames = arrayOf("No frame", "White", "Black", "Warm")
        frameNames.forEachIndexed { index, name ->
            content.addView(Button(this).apply {
                text = name
                isAllCaps = false
                setOnClickListener { editFrame = index; statusText.text = "Frame: $name" }
            })
        }
        panel.addView(scroll, LinearLayout.LayoutParams(-1, dp(440)))
        android.app.AlertDialog.Builder(this)
            .setTitle("Color Studio")
            .setView(panel)
            .setPositiveButton("Pilih foto untuk edit") { _, _ -> photoPicker.launch("image/*") }
            .setNegativeButton("Selesai", null)
            .show()
    }

    private fun showPhotoPreview(uri: Uri, allowEdit: Boolean) {
        val image = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
        }
        try {
            image.setImageURI(uri)
        } catch (_: Exception) {
            Toast.makeText(this, "Foto tidak dapat dibuka", Toast.LENGTH_SHORT).show()
            return
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(4))
            addView(image, LinearLayout.LayoutParams(-1, dp(420)))
        }
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Preview foto")
            .setView(container)
            .setPositiveButton(if (allowEdit) "Edit foto" else "Tutup", null)
            .setNeutralButton("Bagikan", null)
            .setNegativeButton("Hapus", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (!allowEdit) { dialog.dismiss(); return@setOnClickListener }
                dialog.dismiss()
                applyToneToUri(uri)
            }
            dialog.getButton(android.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val share = Intent(Intent.ACTION_SEND).apply { type = "image/*"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                startActivity(Intent.createChooser(share, "Bagikan foto"))
            }
            dialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                android.app.AlertDialog.Builder(this)
                    .setTitle("Hapus foto?")
                    .setMessage("Foto ini akan dihapus dari galeri.")
                    .setNegativeButton("Batal", null)
                    .setPositiveButton("Hapus") { _, _ ->
                        val deleted = contentResolver.delete(uri, null, null) > 0
                        statusText.text = if (deleted) "Foto dihapus" else "Foto tidak dapat dihapus"
                        if (uri == latestPhotoUri) { latestPhotoUri = null; galleryThumbnail.setImageResource(android.R.drawable.ic_menu_gallery) }
                        dialog.dismiss()
                    }.show()
            }
        }
        dialog.show()
    }

    private fun applyToneToUri(uri: Uri) {
        cameraExecutor.execute {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) error("Foto tidak dapat dibuka")
                // Keep memory use predictable on mid-range phones. The source photo is never modified.
                var sample = 1
                while ((bounds.outWidth.toLong() / sample) * (bounds.outHeight.toLong() / sample) > 8_000_000L) sample *= 2
                val bitmap = contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
                } ?: error("Foto tidak dapat dibuka")
                val edited = applyFullEdit(bitmap)
                val saved = saveEditedBitmap(edited)
                bitmap.recycle()
                edited.recycle()
                runOnUiThread {
                    statusText.text = if (saved) "Hasil edit tersimpan sebagai salinan. Foto asli tetap aman." else "Gagal menyimpan hasil edit."
                    Toast.makeText(this, statusText.text, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread { statusText.text = "Edit gagal: ${e.localizedMessage}" }
            }
        }
    }

    private fun applyFullEdit(source: Bitmap): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val toneMatrix = ColorMatrix(currentTone.matrix)
        val saturationMatrix = ColorMatrix().apply { setSaturation(editSaturation) }
        toneMatrix.postConcat(saturationMatrix)
        val contrast = editContrast
        val brightness = editBrightness
        val adjust = ColorMatrix(floatArrayOf(
            contrast,0f,0f,0f,brightness, 0f,contrast,0f,0f,brightness,
            0f,0f,contrast,0f,brightness, 0f,0f,0f,1f,0f
        ))
        toneMatrix.postConcat(adjust)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(toneMatrix)
        }
        canvas.drawBitmap(source, 0f, 0f, paint)
        if (editHighlights != 0f || editShadows != 0f) {
            // Process in small horizontal bands to avoid allocating a full-resolution
            // second pixel array on mid-range devices such as Redmi 13C.
            val bandHeight = 64
            var top = 0
            while (top < output.height) {
                val rows = min(bandHeight, output.height - top)
                val pixels = IntArray(output.width * rows)
                output.getPixels(pixels, 0, output.width, 0, top, output.width, rows)
                for (i in pixels.indices) {
                    val color = pixels[i]
                    val r = Color.red(color).toFloat()
                    val g = Color.green(color).toFloat()
                    val b = Color.blue(color).toFloat()
                    val luminance = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
                    val shadowLift = editShadows * (1f - luminance) * (1f - luminance) * 72f
                    val highlightShift = editHighlights * luminance * luminance * 72f
                    val delta = shadowLift + highlightShift
                    pixels[i] = Color.rgb(
                        (r + delta).toInt().coerceIn(0, 255),
                        (g + delta).toInt().coerceIn(0, 255),
                        (b + delta).toInt().coerceIn(0, 255)
                    )
                }
                output.setPixels(pixels, 0, output.width, 0, top, output.width, rows)
                top += rows
            }
        }
        if (editGrain > 0f) {
            val random = java.util.Random(7L)
            val count = (source.width.toLong() * source.height / 180L * editGrain).toInt().coerceAtMost(120000)
            val grainPaint = Paint().apply { alpha = (editGrain * 55).toInt(); strokeWidth = 1f }
            repeat(count) {
                val x = random.nextInt(source.width).toFloat()
                val y = random.nextInt(source.height).toFloat()
                grainPaint.color = if (random.nextBoolean()) Color.WHITE else Color.BLACK
                canvas.drawPoint(x, y, grainPaint)
            }
        }
        if (editVignette > 0f) {
            val radius = max(source.width, source.height) * .72f
            val shader = RadialGradient(source.width / 2f, source.height / 2f, radius,
                intArrayOf(Color.TRANSPARENT, Color.argb((editVignette * 180).toInt(), 0, 0, 0)),
                floatArrayOf(.45f, 1f), Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, source.width.toFloat(), source.height.toFloat(), Paint().apply { this.shader = shader })
        }
        if (editFrame > 0) {
            val color = when (editFrame) { 1 -> Color.WHITE; 2 -> Color.BLACK; else -> Color.rgb(210, 160, 100) }
            val width = max(8f, min(source.width, source.height) * .025f)
            canvas.drawRect(0f, 0f, source.width.toFloat(), source.height.toFloat(), Paint().apply {
                this.color = color; style = Paint.Style.STROKE; strokeWidth = width
            })
        }
        return output
    }

    private fun sceneRecommendation(labels: List<String>): String {
        val text = labels.joinToString(" ").lowercase()
        return when {
            text.contains("food") || text.contains("dish") -> "Saran: ambil sedikit dari atas, jaga detail makanan"
            text.contains("plant") || text.contains("flower") -> "Saran: pisahkan subjek dari latar"
            text.contains("building") || text.contains("architecture") -> "Saran: jaga garis vertikal tetap lurus"
            text.contains("landscape") || text.contains("sky") || text.contains("mountain") -> "Saran: tempatkan horizon di garis sepertiga"
            text.contains("animal") || text.contains("dog") || text.contains("cat") || text.contains("bird") -> "Saran: sejajarkan kamera dengan tinggi subjek"
            text.contains("person") || text.contains("people") -> "Saran: sisakan ruang di atas kepala"
            else -> "Saran: tempatkan subjek utama di titik sepertiga"
        }
    }

    private fun saveEditedBitmap(bitmap: Bitmap): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "BestShot_Edit_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BestShotAI/Edits")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            val stream = contentResolver.openOutputStream(uri) ?: throw IllegalStateException("Penyimpanan tidak tersedia")
            stream.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 100, it) }
            true
        } catch (_: Exception) {
            contentResolver.delete(uri, null, null)
            false
        }
    }

    override fun onResume() {
        super.onResume()
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.also {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        sensorManager.unregisterListener(this)
        super.onPause()
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0]
        val y = event.values[1]
        rollDegrees = Math.toDegrees(kotlin.math.atan2(x.toDouble(), y.toDouble())).toFloat()
        overlay.rollDegrees = rollDegrees
        horizonAdvice = if (abs(rollDegrees) < 2.5f) "Horizon lurus" else "Miring ${"%.1f".format(abs(rollDegrees))}°"
        overlay.invalidate()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    /** Capture exactly one frame per shutter press. No hidden burst or automatic selection. */
    private fun capturePhoto() {
        val capture = imageCapture
        if (capture == null) {
            statusText.text = "Kamera belum siap. Coba lagi sebentar."
            return
        }
        if (isCapturing) return
        isCapturing = true
        shutterButton.isEnabled = false
        statusText.text = "Mengambil foto kualitas maksimal…"
        val file = File(cacheDir, "bestshot_${System.nanoTime()}.jpg")
        val options = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                cameraExecutor.execute {
                    val savedUri = try { saveOriginalJpeg(file) } finally { file.delete() }
                    runOnUiThread {
                        if (savedUri != null) {
                            updateGalleryThumbnail(savedUri)
                            finishCapture("Foto tersimpan • JPEG kamera asli dipertahankan ✓")
                        } else {
                            finishCapture("Gagal menyimpan foto ke galeri.")
                        }
                    }
                }
            }
            override fun onError(exception: ImageCaptureException) {
                file.delete()
                finishCapture("Capture gagal: ${exception.message ?: "kesalahan kamera"}")
            }
        })
    }

    private fun saveOriginalJpeg(file: File): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "BestShot_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BestShotAI")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            val output = contentResolver.openOutputStream(uri) ?: error("Tidak bisa membuka galeri")
            output.use { out -> file.inputStream().use { input -> input.copyTo(out) } }
            uri
        } catch (_: Exception) {
            contentResolver.delete(uri, null, null)
            null
        }
    }

    private fun updateGalleryThumbnail(uri: Uri) {
        latestPhotoUri = uri
        try {
            val bitmap = if (android.os.Build.VERSION.SDK_INT >= 29) {
                contentResolver.loadThumbnail(uri, Size(240, 240), null)
            } else {
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }
            if (bitmap != null) galleryThumbnail.setImageBitmap(bitmap)
        } catch (_: Exception) { galleryThumbnail.setImageResource(android.R.drawable.ic_menu_gallery) }
    }

    private fun loadLatestPhoto() {
        try {
            val projection = arrayOf(MediaStore.Images.Media._ID)
            val selection = if (android.os.Build.VERSION.SDK_INT >= 29) "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?" else null
            val args = if (selection != null) arrayOf("Pictures/BestShotAI%") else null
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                args,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
                    val uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                    updateGalleryThumbnail(uri)
                }
            }
        } catch (_: Exception) { /* Gallery picker remains available through the thumbnail. */ }
    }

    private fun finishCapture(message: String) {
        isCapturing = false
        shutterButton.isEnabled = true
        statusText.text = message
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        if (::cameraExecutor.isInitialized) cameraExecutor.shutdown()
        objectDetector.close()
        faceDetector.close()
        imageLabeler.close()
        super.onDestroy()
    }

    private inner class GuideOverlay : View(this@MainActivity) {
        var gridEnabled = true
        var rollDegrees = 0f
        var toneTint = Color.TRANSPARENT
        var aiGuidesEnabled = false
        var guideDx = 0f
        var guideDy = 0f
        var subjectCenterX = .5f
        var subjectCenterY = .5f
        var targetCenterX = .62f
        var targetCenterY = .46f
        var sourceAspectRatio = 3f / 4f
        var frameRatio = 3f / 4f
        var subjectBounds: RectF? = null
        private var detections: List<Rect> = emptyList()
        private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(155, 255, 255, 255); strokeWidth = 1.5f; style = Paint.Style.STROKE
        }
        private val targetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 214, 0); strokeWidth = dp(3).toFloat(); style = Paint.Style.STROKE
        }
        private val detectorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; alpha = 210; strokeWidth = dp(2).toFloat(); style = Paint.Style.STROKE
            pathEffect = android.graphics.DashPathEffect(floatArrayOf(dp(4).toFloat(), dp(4).toFloat()), 0f)
        }
        private val connectorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 214, 0); strokeWidth = dp(2).toFloat(); style = Paint.Style.STROKE
            pathEffect = android.graphics.DashPathEffect(floatArrayOf(dp(7).toFloat(), dp(6).toFloat()), 0f)
        }
        private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 214, 0); strokeWidth = dp(3).toFloat(); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
        }
        private val tintPaint = Paint()
        fun setDetections(value: List<Rect>) {
            detections = value.map { Rect(it) }
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            if (gridEnabled) {
                canvas.drawLine(w / 3f, 0f, w / 3f, h, gridPaint)
                canvas.drawLine(2f * w / 3f, 0f, 2f * w / 3f, h, gridPaint)
                canvas.drawLine(0f, h / 3f, w, h / 3f, gridPaint)
                canvas.drawLine(0f, 2f * h / 3f, w, 2f * h / 3f, gridPaint)
            }
            canvas.save()
            canvas.rotate(rollDegrees, w / 2f, h / 2f)
            canvas.drawLine(w * .34f, h / 2f, w * .66f, h / 2f, gridPaint)
            canvas.restore()

            if (aiGuidesEnabled) {
                val bounds = subjectBounds
                if (bounds != null) {
                    // Yellow framing box follows the detected subject and updates per analysis frame.
                    // Match PreviewView FILL_CENTER cropping so ML Kit boxes line up with
                    // what the user actually sees in the portrait viewfinder.
                    val viewAspect = w / max(1f, h)
                    var left = bounds.left
                    var right = bounds.right
                    var top = bounds.top
                    var bottom = bounds.bottom
                    if (sourceAspectRatio > viewAspect) {
                        val visible = (viewAspect / sourceAspectRatio).coerceIn(0f, 1f)
                        val crop = (1f - visible) / 2f
                        left = (left - crop) / max(.001f, visible)
                        right = (right - crop) / max(.001f, visible)
                    } else {
                        val visible = (sourceAspectRatio / viewAspect).coerceIn(0f, 1f)
                        val crop = (1f - visible) / 2f
                        top = (top - crop) / max(.001f, visible)
                        bottom = (bottom - crop) / max(.001f, visible)
                    }
                    val subject = RectF(
                        left * w, top * h, right * w, bottom * h
                    )
                    subject.intersect(0f, 0f, w, h)
                    // White dashed rectangle is the detector result. The yellow rectangle
                    // below is a separate composition target, never a green/ready indicator.
                    canvas.drawRoundRect(subject, dp(8).toFloat(), dp(8).toFloat(), detectorPaint)
                    val targetWidth = (subject.width() * 1.12f).coerceIn(dp(58).toFloat(), w * .72f)
                    val targetHeight = (subject.height() * 1.12f).coerceIn(dp(72).toFloat(), h * .62f)
                    val tx = targetCenterX * w
                    val ty = targetCenterY * h
                    val target = RectF(
                        tx - targetWidth / 2f, ty - targetHeight / 2f,
                        tx + targetWidth / 2f, ty + targetHeight / 2f
                    )
                    target.offset(
                        (if (target.left < dp(8)) dp(8) - target.left else 0f) +
                            (if (target.right > w - dp(8)) (w - dp(8)) - target.right else 0f),
                        (if (target.top < dp(8)) dp(8) - target.top else 0f) +
                            (if (target.bottom > h - dp(8)) (h - dp(8)) - target.bottom else 0f)
                    )
                    canvas.drawRoundRect(target, dp(14).toFloat(), dp(14).toFloat(), targetPaint)

                    // Dashed connector leads from the detected subject to the target frame.
                    canvas.drawLine(subject.centerX(), subject.centerY(), target.centerX(), target.centerY(), connectorPaint)
                    val marker = dp(7).toFloat()
                    canvas.drawLine(target.centerX() - marker, target.centerY(), target.centerX() + marker, target.centerY(), arrowPaint)
                    canvas.drawLine(target.centerX(), target.centerY() - marker, target.centerX(), target.centerY() + marker, arrowPaint)

                    // Arrow indicates the physical movement of the phone.
                    val cx = w * .5f
                    val cy = h * .72f
                    val dx = guideDx * w * .22f
                    val dy = guideDy * h * .18f
                    if (abs(dx) > dp(5) || abs(dy) > dp(5)) {
                        val ex = cx + dx
                        val ey = cy + dy
                        canvas.drawLine(cx, cy, ex, ey, arrowPaint)
                        val angle = kotlin.math.atan2(dy, dx)
                        val head = dp(13).toFloat()
                        val a1 = angle + Math.PI * .78
                        val a2 = angle - Math.PI * .78
                        canvas.drawLine(ex, ey, ex + kotlin.math.cos(a1).toFloat() * head, ey + kotlin.math.sin(a1).toFloat() * head, arrowPaint)
                        canvas.drawLine(ex, ey, ex + kotlin.math.cos(a2).toFloat() * head, ey + kotlin.math.sin(a2).toFloat() * head, arrowPaint)
                    }
                }
            }
            // Optional aspect-ratio guide. It is an overlay only; captured JPEG stays native.
            if (frameRatio > 0f) {
                val viewRatio = w / max(1f, h)
                val frameW: Float
                val frameH: Float
                if (viewRatio > frameRatio) {
                    frameH = h
                    frameW = h * frameRatio
                } else {
                    frameW = w
                    frameH = w / frameRatio
                }
                val frame = RectF((w - frameW) / 2f, (h - frameH) / 2f,
                    (w + frameW) / 2f, (h + frameH) / 2f)
                val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.argb(150, 255, 255, 255)
                    style = Paint.Style.STROKE
                    strokeWidth = dp(1).toFloat()
                }
                canvas.drawRect(frame, framePaint)
            }
            if (toneTint != Color.TRANSPARENT) {
                tintPaint.color = toneTint
                canvas.drawRect(0f, 0f, w, h, tintPaint)
            }
        }
    }
}
