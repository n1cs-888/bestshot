package com.bestshot.ai

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.*
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.core.Camera as CameraXCamera
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.label.ImageLabel
import com.google.mlkit.vision.label.ImageLabeler
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.ObjectDetector
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity(), SensorEventListener {
    private lateinit var previewView: PreviewView
    private lateinit var overlay: GuideOverlay
    private lateinit var statusText: TextView
    private lateinit var shutterButton: Button
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var sensorManager: SensorManager
    private var imageCapture: ImageCapture? = null
    private var isCapturing = false
    private var analysisBusy = false
    private var lastAnalysisAt = 0L
    private var boundCamera: CameraXCamera? = null
    private var manualFraming = false
    private var trackingEnabled = true
    private var lastTrackedBox: RectF? = null
    private var latestLabels: List<String> = emptyList()
    private var latestSubject = "Mencari subjek…"
    private lateinit var subjectChip: TextView
    private var analysisWidth = 640
    private var analysisHeight = 480

    private var currentTone = Tone.NATURAL
    private var exposureSteps = 0
    private var zoomRatio = 1f
    private var aiGuideEnabled = true
    private var rollDegrees = 0f
    private var horizonAdvice = "Horizon stabil"
    private val burstSize = 3

    private val objectDetector: ObjectDetector by lazy {
        ObjectDetection.getClient(
            ObjectDetectorOptions.Builder()
                .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
                .enableClassification()
                .enableMultipleObjects()
                .build()
        )
    }
    private val faceDetector: FaceDetector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .build()
        )
    }
    // ML Kit's on-device base image-labeling model expands scene labels beyond object detector categories.
    private val imageLabeler: ImageLabeler by lazy {
        ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
    }

    private enum class Tone(val title: String, val tint: Int, val matrix: FloatArray) {
        NATURAL("Natural", Color.TRANSPARENT, floatArrayOf(
            1f,0f,0f,0f,0f, 0f,1f,0f,0f,0f, 0f,0f,1f,0f,0f, 0f,0f,0f,1f,0f
        )),
        WARM("Warm", Color.argb(22,255,155,70), floatArrayOf(
            1.08f,0f,0f,0f,5f, 0f,1.01f,0f,0f,1f, 0f,0f,0.91f,0f,-3f, 0f,0f,0f,1f,0f
        )),
        COOL("Cool", Color.argb(20,70,145,255), floatArrayOf(
            0.94f,0f,0f,0f,-2f, 0f,1.01f,0f,0f,1f, 0f,0f,1.10f,0f,4f, 0f,0f,0f,1f,0f
        )),
        FILM("Film", Color.argb(18,180,145,95), floatArrayOf(
            1.04f,0f,0f,0f,3f, 0f,1.00f,0f,0f,0f, 0f,0f,0.91f,0f,2f, 0f,0f,0f,1f,0f
        )),
        VIVID("Vivid", Color.argb(12,255,220,80), floatArrayOf(
            1.18f,0f,0f,0f,-8f, 0f,1.12f,0f,0f,-5f, 0f,0f,1.16f,0f,-7f, 0f,0f,0f,1f,0f
        )),
        MONO("Mono", Color.TRANSPARENT, floatArrayOf(
            0.30f,0.59f,0.11f,0f,0f, 0.30f,0.59f,0.11f,0f,0f, 0.30f,0.59f,0.11f,0f,0f, 0f,0f,0f,1f,0f
        ))
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera() else {
            statusText.text = "Izin kamera diperlukan."
            shutterButton.isEnabled = false
        }
    }

    private val photoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@registerForActivityResult
        cameraExecutor.execute {
            try {
                val bitmap = contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it)
                } ?: throw IllegalStateException("Foto tidak dapat dibuka")
                val edited = applyTone(bitmap, currentTone)
                val saved = saveEditedBitmap(edited)
                bitmap.recycle()
                if (edited !== bitmap) edited.recycle()
                runOnUiThread {
                    statusText.text = if (saved) "Salinan ${currentTone.title} tersimpan. Foto asli aman." else "Gagal menyimpan hasil edit."
                }
            } catch (e: Exception) {
                runOnUiThread { statusText.text = "Edit gagal: ${e.localizedMessage}" }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        buildInterface()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildInterface() {
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }

        // Top camera toolbar inspired by the supplied reference.
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val ratio = cameraLabel("▢   3:4  ⌄", 17f)
        top.addView(ratio, LinearLayout.LayoutParams(0, dp(48), 1f))
        top.addView(cameraButton("ϟ̸") { statusText.text = "Flash tidak tersedia pada semua kamera." })
        top.addView(cameraButton("◉") { openColorStudio() })
        top.addView(cameraButton("•••") { showCameraOptions() })
        root.addView(top, LinearLayout.LayoutParams(-1, dp(56)))

        val previewFrame = FrameLayout(this)
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        overlay = GuideOverlay()
        previewFrame.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        previewFrame.addView(overlay, FrameLayout.LayoutParams(-1, -1))

        subjectChip = TextView(this).apply {
            text = "MENCARI SUBJEK…"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.argb(220, 22, 22, 22))
                cornerRadius = dp(28).toFloat()
            }
        }
        val chipParams = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(20)
        }
        previewFrame.addView(subjectChip, chipParams)
        root.addView(previewFrame, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(Color.BLACK)
        }
        statusText = TextView(this).apply {
            text = "Point your camera and tap the ✦ button"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            maxLines = 2
            setPadding(dp(4), dp(3), dp(4), dp(12))
        }
        bottom.addView(statusText, LinearLayout.LayoutParams(-1, dp(42)))

        val zoomRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
        }
        listOf(.5f, 1f, 2f, 5f).forEach { zoom ->
            val b = cameraButton(if (zoom == .5f) ".5x" else "${zoom.toInt()}x") {
                setZoom(zoom)
            }
            b.textSize = 15f
            b.background = roundBackground(if (zoom == 1f) Color.rgb(40, 40, 40) else Color.rgb(25, 25, 25))
            zoomRow.addView(b, LinearLayout.LayoutParams(dp(62), dp(62)).apply {
                marginStart = dp(7); marginEnd = dp(7)
            })
        }
        bottom.addView(zoomRow, LinearLayout.LayoutParams(-1, dp(68)))

        val actionRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(8), dp(12), dp(2))
        }
        val thumbnail = cameraButton("▧") { photoPicker.launch("image/*") }.apply {
            textSize = 25f
            background = roundBackground(Color.rgb(35, 35, 35))
        }
        actionRow.addView(thumbnail, LinearLayout.LayoutParams(dp(68), dp(68)))
        val shutterWrap = FrameLayout(this)
        shutterButton = Button(this).apply {
            text = "●"
            textSize = 36f
            setTextColor(Color.BLACK)
            isAllCaps = false
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.WHITE)
                setStroke(dp(5), Color.WHITE)
            }
            setOnClickListener { captureBurst() }
        }
        shutterWrap.addView(shutterButton, FrameLayout.LayoutParams(dp(84), dp(84), Gravity.CENTER))
        actionRow.addView(shutterWrap, LinearLayout.LayoutParams(0, dp(92), 1f))
        val aiButton = cameraButton("✦") {
            aiGuideEnabled = true
            overlay.aiGuidesEnabled = true
            overlay.invalidate()
            triggerAiRecommendation()
        }.apply {
            textSize = 30f
            setTextColor(Color.rgb(255, 220, 0))
            background = roundBackground(Color.rgb(48, 40, 0))
        }
        actionRow.addView(aiButton, LinearLayout.LayoutParams(dp(68), dp(68)))
        bottom.addView(actionRow, LinearLayout.LayoutParams(-1, dp(96)))
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(246)))
        setContentView(root)

        toneButton = cameraButton("Tone") { cycleTone(toneButton) }
        statusText.text = "Point your camera and tap the ✦ button"
    }

    private lateinit var toneButton: Button

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun cameraLabel(textValue: String, size: Float) = TextView(this).apply {
        text = textValue
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun cameraButton(label: String, action: (View) -> Unit) =
        Button(this).apply {
            text = label
            textSize = 18f
            isAllCaps = false
            minWidth = 0
            minHeight = 0
            setPadding(dp(5), 0, dp(5), 0)
            setTextColor(Color.WHITE)
            background = roundBackground(Color.TRANSPARENT)
            setOnClickListener(action)
        }

    private fun roundBackground(color: Int) =
        android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            setColor(color)
            cornerRadius = dp(40).toFloat()
        }

    private fun setZoom(requested: Float) {
        val camera = boundCamera ?: return
        val state = camera.cameraInfo.zoomState.value ?: return
        zoomRatio = requested.coerceIn(state.minZoomRatio, state.maxZoomRatio)
        camera.cameraControl.setZoomRatio(zoomRatio)
        statusText.text = "Zoom ${"%.1f".format(zoomRatio)}x • $horizonAdvice"
    }

    private fun showCameraOptions() {
        val options = arrayOf("Grid ON/OFF", "Auto / Manual framing", "Subject tracking ON/OFF", "Color tone")
        android.app.AlertDialog.Builder(this)
            .setTitle("BestShot controls")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> { overlay.gridEnabled = !overlay.gridEnabled; overlay.invalidate(); statusText.text = "Grid ${if (overlay.gridEnabled) "ON" else "OFF"}" }
                    1 -> { manualFraming = !manualFraming; updateAdvice() }
                    2 -> { trackingEnabled = !trackingEnabled; if (!trackingEnabled) lastTrackedBox = null; updateAdvice() }
                    3 -> openColorStudio()
                }
            }.show()
    }

    private fun controlButton(label: String, action: (View) -> Unit) =
        Button(this).apply {
            text = label
            textSize = 10f
            isAllCaps = false
            minWidth = 0
            setPadding(2, 0, 2, 0)
            setOnClickListener(action)
        }

    private fun cycleTone(button: Button) {
        currentTone = Tone.values()[(currentTone.ordinal + 1) % Tone.values().size]
        overlay.toneTint = currentTone.tint
        overlay.invalidate()
        button.text = "Tone ${currentTone.title}"
        updateAdvice()
    }

    private fun adjustExposure(direction: Int) {
        val camera = boundCamera ?: return
        val state = camera.cameraInfo.exposureState
        exposureSteps = (state.exposureCompensationIndex + direction).coerceIn(
            state.exposureCompensationRange.lower, state.exposureCompensationRange.upper
        )
        camera.cameraControl.setExposureCompensationIndex(exposureSteps)
        updateAdvice("Exposure index $exposureSteps")
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setJpegQuality(100)
                    .build()
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setTargetResolution(android.util.Size(640, 480))
                    .build()
                analysis.setAnalyzer(cameraExecutor, ::analyzeFrame)
                provider.unbindAll()
                boundCamera = provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture, analysis
                )
                statusText.text = "Kamera aktif • deteksi lokal • ${horizonAdvice}"
            } catch (e: Exception) {
                statusText.text = "Kamera gagal dibuka: ${e.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    private fun analyzeFrame(proxy: ImageProxy) {
        val now = System.currentTimeMillis()
        if (analysisBusy || now - lastAnalysisAt < 450L) {
            proxy.close()
            return
        }
        val media = proxy.image
        if (media == null) {
            proxy.close()
            return
        }
        analysisBusy = true
        lastAnalysisAt = now
        val input = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)

        // All three tasks read the same frame. Close ImageProxy only after all complete.
        val objectTask = objectDetector.process(input)
        val faceTask = faceDetector.process(input)
        val labelTask = imageLabeler.process(input)
        var completed = 0
        fun taskFinished() {
            completed++
            if (completed == 3) {
                proxy.close()
                analysisBusy = false
            }
        }

        var objectRects = emptyList<Rect>()
        var faceRects = emptyList<Rect>()
        var labels = emptyList<ImageLabel>()
        objectTask.addOnSuccessListener { objectRects = it.map { item -> Rect(item.boundingBox) } }
            .addOnCompleteListener { taskFinished() }
        faceTask.addOnSuccessListener { faceRects = it.map { item -> Rect(item.boundingBox) } }
            .addOnCompleteListener { taskFinished() }
        labelTask.addOnSuccessListener { labels = it }
            .addOnCompleteListener { taskFinished() }

        // Publish once the three asynchronous results are complete.
        val publish = {
            val boxes = faceRects + objectRects
            analysisWidth = input.width
            analysisHeight = input.height
            val bestBox = selectTrackedBox(boxes, input.width, input.height)
            val labelNames = labels.sortedByDescending { it.confidence }.take(5).map { it.text }
            latestLabels = labelNames
            latestSubject = when {
                faceRects.isNotEmpty() -> "Manusia/wajah terdeteksi"
                labelNames.isNotEmpty() -> "Adegan: ${labelNames.take(2).joinToString(", ")}"
                objectRects.isNotEmpty() -> "Objek terdeteksi"
                else -> "Belum ada subjek dominan"
            }
            runOnUiThread {
                overlay.setDetections(if (trackingEnabled) listOfNotNull(bestBox) else boxes)
                updateAdvice()
            }
        }
        // A small completion barrier avoids reading partial detector results.
        objectTask.addOnCompleteListener {
            faceTask.addOnCompleteListener {
                labelTask.addOnCompleteListener { publish() }
            }
        }
    }

    private fun selectTrackedBox(boxes: List<Rect>, imageWidth: Int, imageHeight: Int): Rect? {
        if (boxes.isEmpty()) {
            lastTrackedBox = null
            return null
        }
        val candidates = boxes.map { RectF(it) }
        val previous = lastTrackedBox
        val chosen = if (!trackingEnabled || previous == null) {
            candidates.maxByOrNull { it.width() * it.height() }!!
        } else {
            candidates.minByOrNull { centerDistance(previous, it, imageWidth, imageHeight) }!!
        }
        lastTrackedBox = if (previous != null && trackingEnabled) {
            RectF(
                previous.left * .35f + chosen.left * .65f,
                previous.top * .35f + chosen.top * .65f,
                previous.right * .35f + chosen.right * .65f,
                previous.bottom * .35f + chosen.bottom * .65f
            )
        } else chosen
        return Rect(
            lastTrackedBox!!.left.toInt(), lastTrackedBox!!.top.toInt(),
            lastTrackedBox!!.right.toInt(), lastTrackedBox!!.bottom.toInt()
        )
    }

    private fun centerDistance(a: RectF, b: RectF, w: Int, h: Int): Float {
        val dx = (a.centerX() - b.centerX()) / max(1, w).toFloat()
        val dy = (a.centerY() - b.centerY()) / max(1, h).toFloat()
        return dx * dx + dy * dy
    }

    private fun triggerAiRecommendation() {
        if (!::subjectChip.isInitialized) return
        if (lastTrackedBox == null && latestLabels.isEmpty()) {
            subjectChip.text = "ARAHKAN KAMERA KE SUBJEK"
            statusText.text = "Belum ada subjek terdeteksi. Arahkan kamera ke objek dengan pencahayaan cukup."
            return
        }
        updateAdvice("✦ Rekomendasi diperbarui")
    }

    private fun updateAdvice(extra: String? = null) {
        val box = lastTrackedBox
        val frameAdvice = when {
            manualFraming -> "Mode manual: atur komposisi memakai grid"
            box == null -> "Arahkan kamera ke subjek utama"
            else -> {
                val fraction = (box.width() * box.height()) /
                    max(1f, analysisWidth.toFloat() * analysisHeight.toFloat())
                when {
                    fraction < .045f -> "Subjek kecil: dekati sedikit"
                    fraction > .52f -> "Subjek terlalu dekat: mundur sedikit"
                    else -> "Ukuran subjek cukup"
                }
            }
        }

        val angle = if (manualFraming || box == null) {
            "Gunakan grid untuk menentukan posisi subjek"
        } else {
            val cx = box.centerX() / max(1f, analysisWidth.toFloat())
            val cy = box.centerY() / max(1f, analysisHeight.toFloat())
            when {
                cx < .36f -> "Geser kamera ke kanan agar subjek lebih seimbang"
                cx > .64f -> "Geser kamera ke kiri agar subjek lebih seimbang"
                cy < .28f -> "Turunkan sudut kamera sedikit dan sisakan ruang di atas"
                cy > .72f -> "Naikkan sudut kamera sedikit"
                else -> sceneRecommendation(latestLabels)
            }
        }

        val scene = latestLabels.take(2).joinToString(", ")
        val chipText = when {
            box != null && scene.isNotBlank() -> "$scene  ↑"
            box != null -> "SUBJEK TERDETEKSI  ↑"
            latestLabels.isNotEmpty() -> "$scene  ↑"
            else -> "MENCARI SUBJEK…"
        }
        if (::subjectChip.isInitialized) subjectChip.text = chipText

        val advice = if (box != null || latestLabels.isNotEmpty()) angle else frameAdvice
        statusText.text = listOfNotNull(frameAdvice, advice, horizonAdvice, extra).joinToString(" • ")
    }

    private fun openColorStudio() {
        val toneNames = Tone.values().map { it.title }.toTypedArray()
        android.app.AlertDialog.Builder(this)
            .setTitle("Color Studio")
            .setSingleChoiceItems(toneNames, currentTone.ordinal) { dialog, which ->
                currentTone = Tone.values()[which]
                overlay.toneTint = currentTone.tint
                overlay.invalidate()
                statusText.text = "Tone ${currentTone.title} dipilih. Preview ini simulasi overlay."
            }
            .setPositiveButton("Pilih foto untuk edit") { _, _ ->
                photoPicker.launch("image/*")
            }
            .setNegativeButton("Selesai", null)
            .show()
    }

    private fun sceneRecommendation(labels: List<String>): String {
        val text = labels.joinToString(" ").lowercase()
        return when {
            text.contains("food") || text.contains("dish") -> "Saran: ambil sedikit dari atas, jaga detail makanan"
            text.contains("plant") || text.contains("flower") -> "Saran: pisahkan subjek dari latar"
            text.contains("building") || text.contains("architecture") -> "Saran: jaga garis vertikal tetap lurus"
            text.contains("landscape") || text.contains("sky") || text.contains("mountain") -> "Saran: tempatkan horizon di garis sepertiga"
            text.contains("animal") || text.contains("dog") || text.contains("cat") || text.contains("bird") -> "Saran: sejajarkan kamera dengan tinggi subjek"
            text.contains("person") || text.contains("people") -> "Saran: sisakan ruang di atas kepala"
            else -> "Saran: tempatkan subjek utama di titik sepertiga"
        }
    }

    private fun applyTone(source: Bitmap, tone: Tone): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix(tone.matrix))
        }
        canvas.drawBitmap(source, 0f, 0f, paint)
        return output
    }

    private fun saveEditedBitmap(bitmap: Bitmap): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "BestShot_Edit_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BestShotAI/Edits")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            val stream = contentResolver.openOutputStream(uri) ?: throw IllegalStateException("Penyimpanan tidak tersedia")
            stream.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 100, it) }
            true
        } catch (_: Exception) {
            contentResolver.delete(uri, null, null)
            false
        }
    }

    override fun onResume() {
        super.onResume()
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.also {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        sensorManager.unregisterListener(this)
        super.onPause()
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0]
        val y = event.values[1]
        rollDegrees = Math.toDegrees(kotlin.math.atan2(x.toDouble(), y.toDouble())).toFloat()
        overlay.rollDegrees = rollDegrees
        horizonAdvice = if (abs(rollDegrees) < 2.5f) "Horizon lurus" else "Miring ${"%.1f".format(abs(rollDegrees))}°"
        overlay.invalidate()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun captureBurst() {
        val capture = imageCapture ?: return
        if (isCapturing) return
        isCapturing = true
        shutterButton.isEnabled = false
        statusText.text = "Mengambil 3 foto dengan kualitas kamera maksimal…"
        captureNext(capture, mutableListOf(), 0)
    }

    private fun captureNext(capture: ImageCapture, files: MutableList<File>, index: Int) {
        if (index >= burstSize) {
            cameraExecutor.execute { chooseAndSaveBest(files) }
            return
        }
        val file = File(cacheDir, "bestshot_${System.nanoTime()}.jpg")
        val options = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                files.add(file)
                if (index + 1 < burstSize) statusText.text = "Foto ${index + 2}/$burstSize…"
                else statusText.text = "Memilih foto paling tajam…"
                captureNext(capture, files, index + 1)
            }
            override fun onError(exception: ImageCaptureException) {
                files.forEach { it.delete() }
                finishCapture("Capture gagal: ${exception.message}")
            }
        })
    }

    private fun chooseAndSaveBest(files: List<File>) {
        try {
            val scored = files.mapNotNull { f -> scoreImage(f)?.let { f to it } }
            val best = scored.maxByOrNull { it.second } ?: error("Tidak ada foto yang bisa dianalisis")
            val saved = saveOriginalJpeg(best.first)
            files.forEach { it.delete() }
            runOnUiThread { finishCapture(if (saved) "Foto terbaik tersimpan. JPEG kamera asli dipertahankan ✓" else "Gagal menyimpan foto") }
        } catch (e: Exception) {
            files.forEach { it.delete() }
            runOnUiThread { finishCapture("Analisis foto gagal: ${e.localizedMessage}") }
        }
    }

    // Decodes only a small sample for scoring. The selected original JPEG file is copied byte-for-byte.
    private fun scoreImage(file: File): Double? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sampleSize = 1
        while (max(bounds.outWidth, bounds.outHeight) / sampleSize > 1000) sampleSize *= 2
        val bitmap = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.RGB_565
        }) ?: return null
        try {
            val w = bitmap.width; val h = bitmap.height
            if (w < 3 || h < 3) return 0.0
            val px = IntArray(w * h)
            bitmap.getPixels(px, 0, w, 0, 0, w, h)
            fun lum(c: Int) = .299 * Color.red(c) + .587 * Color.green(c) + .114 * Color.blue(c)
            var sharp = 0.0; var bright = 0.0; var clipped = 0; var count = 0
            for (y in 1 until h - 1) for (x in 1 until w - 1) {
                val i = y * w + x
                val c = lum(px[i])
                sharp += abs(4 * c - lum(px[i - 1]) - lum(px[i + 1]) - lum(px[i - w]) - lum(px[i + w]))
                bright += c
                if (c < 7 || c > 248) clipped++
                count++
            }
            if (count == 0) return 0.0
            val average = bright / count
            val exposurePenalty = abs(average - 128.0) / 128.0
            val clippingPenalty = clipped.toDouble() / count
            return (sharp / count) * (1.0 - .30 * exposurePenalty) * (1.0 - clippingPenalty)
        } finally {
            bitmap.recycle()
        }
    }

    private fun saveOriginalJpeg(file: File): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "BestShot_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BestShotAI")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            val output = contentResolver.openOutputStream(uri) ?: error("Tidak bisa membuka galeri")
            output.use { out -> file.inputStream().use { input -> input.copyTo(out) } }
            true
        } catch (_: Exception) {
            contentResolver.delete(uri, null, null)
            false
        }
    }

    private fun finishCapture(message: String) {
        isCapturing = false
        shutterButton.isEnabled = true
        statusText.text = message
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        if (::cameraExecutor.isInitialized) cameraExecutor.shutdown()
        objectDetector.close()
        faceDetector.close()
        imageLabeler.close()
        super.onDestroy()
    }

    private inner class GuideOverlay : View(this@MainActivity) {
        var gridEnabled = true
        var rollDegrees = 0f
        var toneTint = Color.TRANSPARENT
        var aiGuidesEnabled = true
        private var boxes: List<Rect> = emptyList()
        private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(190, 255, 255, 255); strokeWidth = 1.7f; style = Paint.Style.STROKE
        }
        private val subjectPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 214, 0); strokeWidth = 3f; style = Paint.Style.STROKE
        }
        private val tintPaint = Paint()
        fun setDetections(value: List<Rect>) { boxes = value; invalidate() }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            if (gridEnabled && aiGuidesEnabled) {
                canvas.drawLine(w / 3f, 0f, w / 3f, h, gridPaint)
                canvas.drawLine(2f * w / 3f, 0f, 2f * w / 3f, h, gridPaint)
                canvas.drawLine(0f, h / 3f, w, h / 3f, gridPaint)
                canvas.drawLine(0f, 2f * h / 3f, w, 2f * h / 3f, gridPaint)
            }
            canvas.save()
            canvas.rotate(rollDegrees, w / 2f, h / 2f)
            canvas.drawLine(w * .34f, h / 2f, w * .66f, h / 2f, subjectPaint)
            canvas.restore()
            // ML Kit coordinates are normalized against analysis frame; scale into preview overlay.
            if (aiGuidesEnabled) boxes.forEach { r ->
                val left = r.left.toFloat() / 640f * w
                val top = r.top.toFloat() / 480f * h
                val right = r.right.toFloat() / 640f * w
                val bottom = r.bottom.toFloat() / 480f * h
                canvas.drawRoundRect(left, top, right, bottom, 12f, 12f, subjectPaint)
            }
            if (toneTint != Color.TRANSPARENT) {
                tintPaint.color = toneTint
                canvas.drawRect(0f, 0f, w, h, tintPaint)
            }
        }
    }
}
