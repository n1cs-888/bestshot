# BestShot AI 2.0 - Feature Expansion

Android Kotlin + CameraX application intended for Redmi 13C testing.

## Implemented in this source
- Rear CameraX preview and max-quality JPEG capture configuration.
- Three-shot burst and heuristic sharpness/exposure ranking.
- Byte-for-byte copy of the selected original JPEG to MediaStore; analysis decodes only a downsampled copy.
- ML Kit face detection, stream-mode object detection/classification, and on-device image labeling.
- Rule-based scene hints for common labels, framing hints, and approximate subject continuity using nearest-box tracking.
- Thirds grid, accelerometer roll indicator, exposure compensation controls.
- Live preview tone tint overlays and post-capture tone editor that saves a separate JPEG copy.
- Auto/manual framing toggle and tracking toggle.

## Known limits (important)
- ML Kit's default image-labeling model and object detector do not guarantee recognition of every animal, building, object, or landscape. A dedicated custom-trained model and model evaluation dataset are required for comprehensive recognition.
- Angle, distance, and composition recommendations are heuristics, not a trained photography expert model or calibrated metric distance measurement.
- Subject continuity is approximate bounding-box matching, not robust multi-object identity tracking.
- Preview tone is an overlay; it does not change the camera sensor output. Post-edit applies a color matrix and creates a separate JPEG copy.
- Overlay box alignment is approximate due to CameraX crop/rotation/aspect-ratio transforms and must be calibrated on the target device.
- Build and on-device performance must be verified using GitHub Actions and a Redmi 13C.


## Camera UI refresh
The camera screen now follows the supplied visual direction: black full-screen camera canvas, compact top toolbar, floating subject-recognition chip, thirds grid and level guide, bottom shooting hint, zoom presets, gallery thumbnail, central shutter, and yellow AI-assist button. Some toolbar glyphs are text-based placeholders and should be replaced with polished vector icons during UI refinement.


## UX corrective update
- Subject chip is now updated from the latest ML Kit labels/detections instead of remaining permanently on SEARCHING.
- AI star now explicitly requests a fresh rule-based framing recommendation and keeps the guide overlay enabled.
- Composition/framing ratios now use the analysis frame dimensions rather than preview pixel dimensions.
- Added a dedicated Color Studio selector with Natural, Warm, Cool, Film, Vivid, and Mono choices; selecting a photo applies the chosen tone and saves a separate JPEG copy.
- The preview tone remains a lightweight overlay simulation, not sensor-level live color grading. Recommendations remain heuristic and depend on the ML Kit results.


## Camera UX update 2.1.0
- Applies safe system-bar insets so the top camera controls remain tappable on edge-to-edge Android versions.
- Replaces the bottom-left gallery glyph with a recent-photo thumbnail; tapping it opens a photo preview. If no BestShot photo exists yet, it opens the system photo picker.
- Adds a dedicated Color Studio panel with selectable tone presets and a photo-edit flow that saves a separate copy.
- Adds directional arrow guidance derived from the detected subject's normalized position when the AI star is tapped.
- Keeps the original captured JPEG unchanged and saves edited images separately.
