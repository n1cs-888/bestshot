# BestShot AI 4.0.0-alpha3

This alpha introduces a fixed composition target after AI subject acquisition.

When the AI finds a subject, it freezes the yellow framing box at that initial composition. The live detector is shown separately as a white dashed rectangle. As the user physically moves the phone closer or adjusts its position, the live detection changes while the yellow target remains stationary. The app marks the composition Ready when the detected subject is centered and grows to approximately fill the locked target.

The lock resets when the user cancels the scan or starts a fresh scan. This is a composition lock, not a promise that the camera lens or optical autofocus will track the subject.

Build with Android Studio using the included Gradle project. Device validation is required; this environment has not run an Android SDK build.
