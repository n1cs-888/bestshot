# BestShot AI 4.0.0-alpha3

## AI Subject Lock / Fixed Composition Frame
- The first confident subject detection establishes a frozen yellow target frame.
- The yellow frame no longer follows subsequent detector movement or scale changes.
- A separate white dashed detection rectangle follows the live subject.
- The composition coach evaluates the live subject against the frozen frame, including center alignment and relative subject size.
- The target frame remains visible when the composition reaches Ready.
- Starting a new scan or cancelling the current scan clears the locked frame.

## Notes
- This is a heuristic visual guidance feature, not optical camera autofocus tracking.
- Detection quality and framing behavior must be validated on physical Android devices.
