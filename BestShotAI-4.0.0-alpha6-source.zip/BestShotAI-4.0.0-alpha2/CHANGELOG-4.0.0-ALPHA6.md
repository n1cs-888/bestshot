# 4.0.0-alpha6

- Fixed the explicit ML Kit Pose type import and callback typing after the alpha4/alpha5 Actions compiler error.
- Started throttled scene-label inference during initial scanning to improve subject-name refinement.
- Preserved the Framed-style live yellow subject box, subject identity lock, top label chip, dotted leader, contextual guidance and Ready state.
- Preserved the existing camera, capture, editor and gallery features.
