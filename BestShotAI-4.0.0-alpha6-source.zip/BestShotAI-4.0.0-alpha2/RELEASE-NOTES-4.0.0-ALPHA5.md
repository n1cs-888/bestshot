# BestShot AI 4.0.0-alpha5

This build changes the AI camera experience to follow the supplied Framed reference flow: scan, select a stable subject, track one yellow bounding box, identify it with a top chip and dotted leader, give contextual framing instructions, then show Ready after stable composition. Zoom remains manual.

The source ZIP is prepared for the existing workflow's outer folder path `BestShotAI-4.0.0-alpha2`; the actual Android app version is `4.0.0-alpha5` (versionCode 18).

Build status: source/archive checks completed; Android build still requires confirmation from GitHub Actions.
