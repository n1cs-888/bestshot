# BestShot AI 4.0.0-alpha4 - merged source

This build combines the AI improvements from alpha2 with the Fixed Composition Lock implementation from alpha3, while applying the ML Kit Pose API compatibility fixes identified in the GitHub Actions logs.

## Included
- AI object, face, image-label and pose detection foundation from alpha2.
- Fixed yellow composition target captured at first confident subject lock.
- Live subject detection box remains independent and follows the detected subject.
- Composition readiness checks compare live subject alignment/size against the locked target.
- Reset behavior clears the locked target when a new scan starts or AI guide is disabled.
- Pose Detection uses `com.google.mlkit.vision.pose.defaults.PoseDetectorOptions`.
- Pose landmarks use explicit Java getter calls for compatibility.
- Canvas pose-point radius uses an integer dp argument.

## Validation
- Source merge checks passed.
- ZIP integrity check passed.
- Android Gradle compilation has NOT yet been run in this environment. Run the repository GitHub Actions workflow to confirm build success.
