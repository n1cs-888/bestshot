# BestShot AI release test checklist

Do not mark this build as final until every device test below passes on the Redmi 13C.

## Build
- [ ] GitHub Actions `Build BestShot AI APK` completes successfully.
- [ ] APK installs and launches on Redmi 13C.
- [ ] Camera permission denial and later permission grant behave correctly.

## Camera
- [ ] Live rear-camera preview starts and recovers after returning from background.
- [ ] Shutter saves one JPEG per press to Pictures/BestShotAI.
- [ ] JPEG opens in the system gallery and has expected full camera resolution.
- [ ] Flash toggles torch only when hardware supports it.
- [ ] Each zoom step is clamped to the device's actual supported range.
- [ ] Each of 3:4, 4:5, 1:1, and 9:16 changes the captured image crop, not just the overlay.
- [ ] Rebinding after changing ratio does not freeze preview or stop analysis.

## AI composition
- [ ] Face and object detection appear in the correct position in the viewfinder.
- [ ] White dashed detector rectangle and yellow composition target are visibly distinct.
- [ ] Yellow target never turns green and does not trigger automatic capture.
- [ ] Guidance direction changes appropriately as the phone moves.
- [ ] Horizon guide responds correctly in portrait orientation.

## Gallery and editor
- [ ] Latest-photo thumbnail opens the correct image.
- [ ] Gallery picker opens an existing image.
- [ ] Looks and every Adjust/Effects/Frames control changes the exported image.
- [ ] Edited image saves as a new file; original remains unchanged.
- [ ] Share opens Android Sharesheet with the selected image.
- [ ] Delete asks for confirmation and removes only the selected image.
- [ ] Editing large photos does not cause an out-of-memory crash.

## Performance
- [ ] Camera analysis remains responsive for at least 5 minutes.
- [ ] No crash occurs while rapidly switching ratios, opening editor, and returning to camera.
- [ ] Device temperature and memory use remain acceptable during normal use.


## 3.1.1-RC1 additional regression checks
- [ ] READY never appears before the AI sparkle button is tapped.
- [ ] READY appears only after at least three consecutive stable analysis frames.
- [ ] Moving the subject out of the target resets READY.
- [ ] Tilting the phone beyond the level threshold resets READY.
- [ ] Switching to manual framing prevents READY.
- [ ] Rapid scene changes do not freeze object detection.
- [ ] Large photos open in preview without loading their full-resolution bitmap.
- [ ] Failed JPEG encoding reports an error and does not leave a broken gallery item.
- [ ] Captured JPEG copy is non-empty and opens in the gallery.
- [ ] Edit Save creates a separate JPEG and leaves the original unchanged.

## 4.0.0-alpha1 advanced controls
- [ ] Professional Camera panel opens and reports unsupported manual-sensor hardware clearly.
- [ ] On manual-sensor devices, ISO changes exposure without crashing or freezing preview.
- [ ] Shutter time changes exposure and stays within the advertised sensor range.
- [ ] Auto exposure reset restores normal AE behavior.
- [ ] Each enabled white-balance preset visibly changes the image consistently in preview and capture.
- [ ] Manual exposure and white-balance settings survive aspect-ratio use-case rebinding.
- [ ] Temperature and Tint update the editor preview and exported JPEG.
- [ ] Undo/redo restores Temperature and Tint values correctly.


## 4.0.0-alpha2 AI composition validation
- [ ] Confirm Pose Detection model initializes on a fresh install.
- [ ] Verify body landmarks and skeleton overlay align with the visible preview in portrait and landscape orientations.
- [ ] Verify pose inference only runs during an active AI scan and does not stall capture.
- [ ] Test face, full-body, object-only, food, and low-detail scenes.
- [ ] Confirm the composition score changes with subject alignment, subject occupancy, and phone roll.
- [ ] Confirm subject box remains stable across brief missed detections and does not jump between nearby objects.
- [ ] Measure preview FPS, CPU load, memory, temperature, and battery use on Redmi 13C.
- [ ] Confirm analyzer always releases ImageProxy after success and failure of each ML task.


## 4.0.0-alpha5 Framed-style subject coach regression
- [ ] Tapping the AI sparkle displays `Finding your shot…` while detections stabilize.
- [ ] No synthetic saliency rectangle is shown as if it were a detected object.
- [ ] A yellow bounding rectangle appears only after the same candidate is confirmed across three analysis results.
- [ ] The yellow rectangle follows the selected object's live bounding box; it is not frozen at the first detected position.
- [ ] The app uses the ML Kit object tracking ID when available and does not jump to a higher-scoring nearby object during brief misses.
- [ ] The selected-object label stays associated with the locked subject.
- [ ] Small targets prompt the user to isolate the subject and go tighter; oversized subjects prompt the user to back up.
- [ ] The level guide stays independent of the subject bounding box and responds to phone roll.
- [ ] Ready requires three consecutive analysis results meeting the size, placement, edge and level heuristics.
- [ ] When Ready appears, the subject box clears and the subject/Ready chip appears at the top of the preview.
- [ ] AI guidance never changes zoom without the user touching a zoom preset.
- [ ] Test object-only, person, plant, food, low-detail, occlusion and multiple-object scenes on Redmi 13C.
- [ ] Verify analyzer closes ImageProxy on success and failure and remains responsive for five minutes.

## 4.0.0-alpha5 Framed-style AI subject coach checks
- [ ] Tap AI scan: status changes to `Finding your shot…` while the camera scans.
- [ ] After a stable real detection, exactly one yellow rounded box follows the selected subject.
- [ ] Subject-name chip stays near top center and a dotted yellow leader connects it to the tracked subject.
- [ ] No frozen yellow target frame or separate white dashed detector box is visible.
- [ ] Small yellow level guide tilts with device roll; advice reacts to horizon, subject scale, placement and clipping.
- [ ] Selected object identity holds through brief occlusion and does not immediately jump to another object.
- [ ] After three consecutive acceptable frames, box/leader disappear and top chip shows `Ready`.
- [ ] AI does not automatically change zoom; user zoom buttons remain in control.
- [ ] Test scene labels and detection behavior with small details, furniture, plants and people; record missed detections honestly.
- [ ] Check thermal load, dropped frames and battery impact on entry-level Android hardware.
