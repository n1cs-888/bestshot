package com.bestshot.ai

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.*
import android.net.Uri
import android.util.Size
import android.util.Rational
import android.widget.ImageView
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.content.Intent
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.core.ViewPort
import androidx.camera.core.Camera as CameraXCamera
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.label.ImageLabel
import com.google.mlkit.vision.label.ImageLabeler
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.ObjectDetector
import com.google.mlkit.vision.objects.DetectedObject
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseDetector
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import com.google.mlkit.vision.pose.PoseLandmark
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity(), SensorEventListener {
    private lateinit var previewView: PreviewView
    private lateinit var overlay: GuideOverlay
    private lateinit var statusText: TextView
    private lateinit var shutterButton: Button
    private lateinit var galleryThumbnail: ImageView
    private var latestPhotoUri: Uri? = null
    private var selectedPhotoUri: Uri? = null
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var sensorManager: SensorManager
    private var imageCapture: ImageCapture? = null
    private var previewUseCase: Preview? = null
    private var analysisUseCase: ImageAnalysis? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var isCapturing = false
    @Volatile private var analysisBusy = false
    private var readyFrameCount = 0
    private var lastAnalysisAt = 0L
    private var boundCamera: CameraXCamera? = null
    private var manualFraming = false
    private var trackingEnabled = true
    private var lastTrackedBox: RectF? = null
    private var lastPoseAnalysisAt = 0L
    private var lastLabelAnalysisAt = 0L
    private var latestPosePresent = false
    private var latestPoseBounds: Rect? = null
    private var latestPosePoints: Map<Int, PointF> = emptyMap()
    private var latestCompositionScore = 0
    private var latestLabels: List<String> = emptyList()
    private var latestSceneLabelObjects: List<ImageLabel> = emptyList()
    private var latestSubject = "Finding your shot…"
    private lateinit var subjectChip: TextView
    private lateinit var ratioButton: TextView
    private var analysisWidth = 640
    private var analysisHeight = 480

    private var currentTone = Tone.NATURAL
    private var editBrightness = 0f
    private var editContrast = 1f
    private var editSaturation = 1f
    private var editTemperature = 0f
    private var editTint = 0f
    private var editHighlights = 0f
    private var editShadows = 0f
    private var editVignette = 0f
    private var editGrain = 0f
    private var editFrame = 0
    private var exposureSteps = 0
    private var zoomRatio = 1f
    private var selectedFrameRatio = 3f / 4f
    private var selectedFrameRatioLabel = "3:4"
    private var torchEnabled = false
    private var manualExposureEnabled = false
    private var manualIso = 400
    private var manualExposureNs = 10_000_000L
    private var whiteBalanceMode = CaptureRequest.CONTROL_AWB_MODE_AUTO
    private var aiGuideEnabled = false
    private var rollDegrees = 0f
    private var horizonAdvice = "Level"
    private var guideMessage = "Point your camera and tap the ✦ button"
    private var aiScanRequested = false
    private var compositionReady = false
    private var scanFinished = false
    @Volatile private var emptyDetectionFrames = 0
    private lateinit var aiButton: Button
    private val zoomButtons = mutableListOf<Button>()
    private val zoomPresets = mutableListOf(.5f, 1f, 2f, 5f)

    private val objectDetector: ObjectDetector by lazy {
        ObjectDetection.getClient(
            ObjectDetectorOptions.Builder()
                .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
                .enableClassification()
                .enableMultipleObjects()
                .build()
        )
    }
    private val faceDetector: FaceDetector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .build()
        )
    }
    // ML Kit's on-device base image-labeling model expands scene labels beyond object detector categories.
    private val imageLabeler: ImageLabeler by lazy {
        ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
    }
    // Pose detection runs only during an active AI scan and is throttled separately
    // to keep the live preview responsive on entry-level Android devices.
    private val poseDetector: PoseDetector by lazy {
        PoseDetection.getClient(
            PoseDetectorOptions.Builder()
                .setDetectorMode(PoseDetectorOptions.STREAM_MODE)
                .build()
        )
    }

    private enum class Tone(val title: String, val tint: Int, val matrix: FloatArray) {
        NATURAL("Natural", Color.TRANSPARENT, floatArrayOf(
            1f,0f,0f,0f,0f, 0f,1f,0f,0f,0f, 0f,0f,1f,0f,0f, 0f,0f,0f,1f,0f
        )),
        WARM("Warm", Color.argb(22,255,155,70), floatArrayOf(
            1.08f,0f,0f,0f,5f, 0f,1.01f,0f,0f,1f, 0f,0f,0.91f,0f,-3f, 0f,0f,0f,1f,0f
        )),
        COOL("Cool", Color.argb(20,70,145,255), floatArrayOf(
            0.94f,0f,0f,0f,-2f, 0f,1.01f,0f,0f,1f, 0f,0f,1.10f,0f,4f, 0f,0f,0f,1f,0f
        )),
        FILM("Film", Color.argb(18,180,145,95), floatArrayOf(
            1.04f,0f,0f,0f,3f, 0f,1.00f,0f,0f,0f, 0f,0f,0.91f,0f,2f, 0f,0f,0f,1f,0f
        )),
        VIVID("Vivid", Color.argb(12,255,220,80), floatArrayOf(
            1.18f,0f,0f,0f,-8f, 0f,1.12f,0f,0f,-5f, 0f,0f,1.16f,0f,-7f, 0f,0f,0f,1f,0f
        )),
        MONO("Mono", Color.TRANSPARENT, floatArrayOf(
            0.30f,0.59f,0.11f,0f,0f, 0.30f,0.59f,0.11f,0f,0f, 0.30f,0.59f,0.11f,0f,0f, 0f,0f,0f,1f,0f
        ))
    }

    /** A candidate is a real ML Kit detection, never a synthetic saliency rectangle. */
    private data class SubjectCandidate(
        val bounds: RectF,
        val source: String,
        val semantic: String,
        val label: String,
        val confidence: Float,
        val trackingId: Int?
    )

    // AI subject selection is a two-stage process: stabilize a candidate, then keep its
    // ML Kit tracking identity (or a strict spatial/semantic match) until it is genuinely lost.
    private var pendingSubjectCandidate: SubjectCandidate? = null
    private var pendingSubjectFrames = 0
    private var lockedSubjectCandidate: SubjectCandidate? = null
    private var lockedSubjectMissFrames = 0

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera() else {
            statusText.text = "Camera permission is required."
            shutterButton.isEnabled = false
        }
    }

    private val photoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@registerForActivityResult
        selectedPhotoUri = uri
        showPhotoPreview(uri, allowEdit = true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        buildInterface()
        loadLatestPhoto()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildInterface() {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)

        // Top camera toolbar inspired by the supplied reference.
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        ratioButton = cameraLabel("▢   $selectedFrameRatioLabel  ⌄", 17f)
        top.addView(ratioButton, LinearLayout.LayoutParams(0, dp(48), 1f).also {
            ratioButton.setOnClickListener { showAspectRatioOptions() }
        })
        top.addView(cameraButton("ϟ") {
            val camera = boundCamera
            if (camera == null || !camera.cameraInfo.hasFlashUnit()) {
                statusText.text = "Flash is not available on this camera."
            } else {
                torchEnabled = !torchEnabled
                camera.cameraControl.enableTorch(torchEnabled)
                statusText.text = if (torchEnabled) "Flash on" else "Flash off"
            }
        })
        top.addView(cameraButton("◉") { openColorStudio() })
        top.addView(cameraButton("PRO") { showProCameraPanel() })
        top.addView(cameraButton("•••") { showCameraOptions() })
        root.addView(top, LinearLayout.LayoutParams(-1, dp(60)))

        val previewFrame = FrameLayout(this)
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        overlay = GuideOverlay().apply { aiGuidesEnabled = aiGuideEnabled }
        previewFrame.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        previewFrame.addView(overlay, FrameLayout.LayoutParams(-1, -1))

        subjectChip = TextView(this).apply {
            text = ""
            visibility = View.GONE
            textSize = 11.5f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(13), dp(7), dp(13), dp(7))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.argb(220, 22, 22, 22))
                cornerRadius = dp(28).toFloat()
            }
        }
        val chipParams = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(12)
        }
        previewFrame.addView(subjectChip, chipParams)
        root.addView(previewFrame, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(Color.BLACK)
        }
        statusText = TextView(this).apply {
            text = "Point your camera and tap the ✦ button"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            maxLines = 2
            setPadding(dp(4), dp(3), dp(4), dp(12))
        }
        bottom.addView(statusText, LinearLayout.LayoutParams(-1, dp(42)))

        val zoomRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
        }
        zoomPresets.indices.forEach { index ->
            val b = cameraButton("") { setZoom(zoomPresets[index]) }
            b.textSize = 15f
            zoomButtons.add(b)
            zoomRow.addView(b, LinearLayout.LayoutParams(dp(62), dp(62)).apply {
                marginStart = dp(7); marginEnd = dp(7)
            })
        }
        refreshZoomButtons()
        bottom.addView(zoomRow, LinearLayout.LayoutParams(-1, dp(68)))

        val actionRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(8), dp(12), dp(2))
        }
        galleryThumbnail = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackground(roundBackground(Color.rgb(45, 45, 45)))
            setImageResource(android.R.drawable.ic_menu_gallery)
            contentDescription = "Latest photo. Tap to open"
            setOnClickListener {
                val uri = latestPhotoUri
                if (uri != null) showPhotoPreview(uri, allowEdit = true)
                else photoPicker.launch("image/*")
            }
        }
        actionRow.addView(galleryThumbnail, LinearLayout.LayoutParams(dp(68), dp(68)))
        val shutterWrap = FrameLayout(this)
        shutterButton = Button(this).apply {
            text = "●"
            textSize = 36f
            setTextColor(Color.BLACK)
            isAllCaps = false
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.WHITE)
                setStroke(dp(5), Color.WHITE)
            }
            setOnClickListener { capturePhoto() }
        }
        shutterWrap.addView(shutterButton, FrameLayout.LayoutParams(dp(84), dp(84), Gravity.CENTER))
        actionRow.addView(shutterWrap, LinearLayout.LayoutParams(0, dp(92), 1f))
        aiButton = cameraButton("✦") { onAiButtonClicked() }.apply {
            textSize = 30f
            setTextColor(Color.rgb(255, 220, 0))
            background = roundBackground(Color.rgb(48, 40, 0))
        }
        actionRow.addView(aiButton, LinearLayout.LayoutParams(dp(68), dp(68)))
        bottom.addView(actionRow, LinearLayout.LayoutParams(-1, dp(96)))
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(246)))
        setContentView(root)

        toneButton = cameraButton("Tone") { cycleTone(toneButton) }
        statusText.text = "Point your camera and tap the ✦ button"
    }

    private lateinit var toneButton: Button

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun cameraLabel(textValue: String, size: Float) = TextView(this).apply {
        text = textValue
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun cameraButton(label: String, action: (View) -> Unit) =
        Button(this).apply {
            text = label
            textSize = 18f
            isAllCaps = false
            minWidth = 0
            minHeight = 0
            setPadding(dp(5), 0, dp(5), 0)
            setTextColor(Color.WHITE)
            background = roundBackground(Color.TRANSPARENT)
            setOnClickListener(action)
        }

    private fun roundBackground(color: Int) =
        android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            setColor(color)
            cornerRadius = dp(40).toFloat()
        }

    private fun setZoom(requested: Float) {
        val camera = boundCamera ?: return
        val state = camera.cameraInfo.zoomState.value ?: return
        zoomRatio = requested.coerceIn(state.minZoomRatio, state.maxZoomRatio)
        camera.cameraControl.setZoomRatio(zoomRatio)
        refreshZoomButtons()
    }

    private fun zoomLabel(z: Float): String = when {
        z == .5f -> ".5x"
        z % 1f == 0f -> "${z.toInt()}x"
        else -> "${"%.1f".format(java.util.Locale.US, z)}×"
    }

    private fun refreshZoomButtons() {
        if (zoomButtons.isEmpty()) return
        val state = boundCamera?.cameraInfo?.zoomState?.value
        var active = 0
        var best = Float.MAX_VALUE
        zoomPresets.forEachIndexed { i, z ->
            val effective = if (state != null) z.coerceIn(state.minZoomRatio, state.maxZoomRatio) else z
            val d = abs(effective - zoomRatio)
            if (d <= best) { best = d; active = i }   // ties go to the higher preset
        }
        zoomButtons.forEachIndexed { i, b ->
            val on = i == active
            b.text = zoomLabel(zoomPresets[i])
            b.setTextColor(if (on) Color.rgb(255, 214, 0) else Color.WHITE)
            b.background = roundBackground(if (on) Color.rgb(48, 40, 0) else Color.rgb(25, 25, 25))
        }
    }

    private fun resetZoomPresets() {
        zoomPresets.clear()
        zoomPresets.addAll(listOf(.5f, 1f, 2f, 5f))
    }

    /** AI zoom suggestion: the 2x / 5x slot becomes the recommended value (e.g. "2.5×"). */
    private fun applyAutoZoom(target: Float) {
        val idx = if (abs(zoomPresets[2] - target) <= abs(zoomPresets[3] - target)) 2 else 3
        zoomPresets[idx] = target
        setZoom(target)
    }

    private fun showAspectRatioOptions() {
        val choices = arrayOf("3:4 (Photo)", "4:5 (Portrait)", "1:1 (Square)", "9:16 (Story)")
        android.app.AlertDialog.Builder(this)
            .setTitle("Aspect ratio")
            .setItems(choices) { _, which ->
                // CameraX ViewPort applies this aspect ratio consistently to preview and
                // ImageCapture, so the saved JPEG is cropped to the selected framing.
                val ratio = choices[which].substringBefore(" ")
                selectedFrameRatioLabel = ratio
                selectedFrameRatio = when (ratio) {
                    "4:5" -> 4f / 5f
                    "1:1" -> 1f
                    "9:16" -> 9f / 16f
                    else -> 3f / 4f
                }
                overlay.frameRatio = selectedFrameRatio
                ratioButton.text = "▢   $selectedFrameRatioLabel  ⌄"
                overlay.invalidate()
                statusText.text = "Applying ratio $ratio…"
                rebindCameraForSelectedRatio()
            }.show()
    }


    /** Advanced Camera2 controls. Availability and ranges are read from the active device. */
    private fun showProCameraPanel() {
        val camera = boundCamera
        if (camera == null) {
            Toast.makeText(this, "Camera is not ready yet", Toast.LENGTH_SHORT).show()
            return
        }
        val info = Camera2CameraInfo.from(camera.cameraInfo)
        val capabilities = info.getCameraCharacteristic(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
        val supportsManual = capabilities?.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) == true
        val isoRange = info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val exposureRange = info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(12))
            setBackgroundColor(Color.rgb(18, 18, 20))
        }
        fun heading(text: String) {
            panel.addView(TextView(this).apply {
                this.text = text
                setTextColor(Color.WHITE)
                textSize = 13f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(0, dp(10), 0, dp(4))
            })
        }
        fun slider(label: String, minValue: Int, maxValue: Int, initial: Int, suffix: String = "", onChange: (Int) -> Unit) {
            val value = TextView(this).apply {
                setTextColor(Color.LTGRAY)
                textSize = 12f
                text = "$label: $initial$suffix"
            }
            panel.addView(value)
            val seek = SeekBar(this).apply {
                max = (maxValue - minValue).coerceAtLeast(1)
                progress = (initial - minValue).coerceIn(0, max)
                isEnabled = supportsManual
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                        val v = minValue + progress
                        value.text = "$label: $v$suffix"
                        if (fromUser) onChange(v)
                    }
                    override fun onStartTrackingTouch(bar: SeekBar?) = Unit
                    override fun onStopTrackingTouch(bar: SeekBar?) = Unit
                })
            }
            panel.addView(seek)
        }

        heading("MANUAL EXPOSURE")
        if (!supportsManual || isoRange == null || exposureRange == null) {
            panel.addView(TextView(this).apply {
                text = "This camera does not expose full manual sensor controls. Auto exposure remains available."
                setTextColor(Color.LTGRAY)
                textSize = 12f
            })
        } else {
            val isoMin = isoRange.lower
            val isoMax = isoRange.upper
            val initialIso = manualIso.coerceIn(isoMin, isoMax)
            slider("ISO", isoMin, isoMax, initialIso) { value ->
                manualIso = value
                applyManualExposure()
            }
            val minMs = (exposureRange.lower / 1_000_000L).toInt().coerceAtLeast(1)
            val maxMs = (exposureRange.upper / 1_000_000L).toInt().coerceAtLeast(minMs)
            val initialMs = (manualExposureNs / 1_000_000L).toInt().coerceIn(minMs, maxMs)
            slider("Shutter", minMs, maxMs.coerceAtMost(1000), initialMs.coerceAtMost(1000), " ms") { value ->
                manualExposureNs = value * 1_000_000L
                applyManualExposure()
            }
        }

        heading("WHITE BALANCE")
        val wbLabels = listOf("Auto", "Daylight", "Cloudy", "Shade", "Tungsten", "Fluorescent")
        val wbValues = listOf(
            CaptureRequest.CONTROL_AWB_MODE_AUTO,
            CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,
            CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,
            CaptureRequest.CONTROL_AWB_MODE_SHADE,
            CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,
            CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT
        )
        val wbRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        wbLabels.forEachIndexed { index, label ->
            val b = Button(this).apply {
                text = label
                textSize = 9f
                isAllCaps = false
                setTextColor(Color.WHITE)
                isEnabled = info.getCameraCharacteristic(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)?.contains(wbValues[index]) == true
                setOnClickListener {
                    whiteBalanceMode = wbValues[index]
                    applyWhiteBalance()
                    Toast.makeText(this@MainActivity, "White balance: $label", Toast.LENGTH_SHORT).show()
                }
            }
            wbRow.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
        panel.addView(wbRow)
        val note = TextView(this).apply {
            text = "Manual ISO/shutter depend on sensor support. Exposure time is shown in milliseconds. Changing modes may briefly interrupt preview on some devices."
            setTextColor(Color.GRAY)
            textSize = 10f
            setPadding(0, dp(8), 0, 0)
        }
        panel.addView(note)
        val scroll = android.widget.ScrollView(this).apply { addView(panel) }
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Professional Camera")
            .setView(scroll)
            .setNegativeButton("Auto exposure") { _, _ ->
                manualExposureEnabled = false
                Camera2CameraControl.from(camera.cameraControl).clearCaptureRequestOptions()
                if (whiteBalanceMode != CaptureRequest.CONTROL_AWB_MODE_AUTO) applyWhiteBalance()
                statusText.text = "Exposure returned to automatic"
            }
            .setPositiveButton("Close", null)
            .create()
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * .94f).toInt(), -2)
    }

    private fun applyManualExposure() {
        manualExposureEnabled = true
        applyCamera2Options()
    }

    private fun applyWhiteBalance() {
        applyCamera2Options()
    }

    /** Keep AE, sensor values and AWB in one request-options bundle so controls do not overwrite each other. */
    private fun applyCamera2Options() {
        val camera = boundCamera ?: return
        try {
            val builder = CaptureRequestOptions.Builder()
                .setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, whiteBalanceMode)
            if (manualExposureEnabled) {
                builder.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                    .setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, manualIso)
                    .setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, manualExposureNs)
                statusText.text = "Manual exposure · ISO $manualIso · ${manualExposureNs / 1_000_000L} ms"
            } else {
                builder.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                statusText.text = "Automatic exposure"
            }
            Camera2CameraControl.from(camera.cameraControl).setCaptureRequestOptions(builder.build())
        } catch (e: Exception) {
            statusText.text = "Camera control unavailable: ${e.localizedMessage}"
        }
    }

    private fun showCameraOptions() {
        val options = arrayOf("Grid ON/OFF", "Auto / Manual framing", "Subject tracking ON/OFF", "Color tone")
        android.app.AlertDialog.Builder(this)
            .setTitle("BestShot controls")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> { overlay.gridEnabled = !overlay.gridEnabled; overlay.invalidate(); statusText.text = "Grid ${if (overlay.gridEnabled) "ON" else "OFF"}" }
                    1 -> { manualFraming = !manualFraming; updateAdvice() }
                    2 -> { trackingEnabled = !trackingEnabled; if (!trackingEnabled) lastTrackedBox = null; updateAdvice() }
                    3 -> openColorStudio()
                }
            }.show()
    }

    private fun controlButton(label: String, action: (View) -> Unit) =
        Button(this).apply {
            text = label
            textSize = 10f
            isAllCaps = false
            minWidth = 0
            setPadding(2, 0, 2, 0)
            setOnClickListener(action)
        }

    private fun cycleTone(button: Button) {
        currentTone = Tone.values()[(currentTone.ordinal + 1) % Tone.values().size]
        overlay.toneTint = currentTone.tint
        overlay.invalidate()
        button.text = "Tone ${currentTone.title}"
        updateAdvice()
    }

    private fun adjustExposure(direction: Int) {
        val camera = boundCamera ?: return
        val state = camera.cameraInfo.exposureState
        exposureSteps = (state.exposureCompensationIndex + direction).coerceIn(
            state.exposureCompensationRange.lower, state.exposureCompensationRange.upper
        )
        camera.cameraControl.setExposureCompensationIndex(exposureSteps)
        updateAdvice("Exposure index $exposureSteps")
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider
                val preview = Preview.Builder()
                    .setTargetRotation(previewView.display?.rotation ?: windowManager.defaultDisplay.rotation)
                    .build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setJpegQuality(100)
                    .setTargetRotation(previewView.display?.rotation ?: windowManager.defaultDisplay.rotation)
                    .build()
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setTargetResolution(Size(640, 480))
                    .build()
                analysis.setAnalyzer(cameraExecutor, ::analyzeFrame)
                previewUseCase = preview
                imageCapture = capture
                analysisUseCase = analysis
                bindCameraGroup()
                statusText.text = "Point your camera and tap the ✦ button"
            } catch (e: Exception) {
                statusText.text = "Camera failed to open: ${e.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun rebindCameraForSelectedRatio() {
        previewView.post {
            try {
                bindCameraGroup()
                statusText.text = "Ratio $selectedFrameRatioLabel applied to preview and photo."
            } catch (e: Exception) {
                statusText.text = "Could not apply ratio: ${e.localizedMessage}"
            }
        }
    }

    private fun bindCameraGroup() {
        val provider = cameraProvider ?: return
        val preview = previewUseCase ?: return
        val capture = imageCapture ?: return
        val analysis = analysisUseCase ?: return
        val rotation = previewView.display?.rotation ?: windowManager.defaultDisplay.rotation
        val ratioWidth = when (selectedFrameRatioLabel) {
            "4:5" -> 4
            "1:1" -> 1
            "9:16" -> 9
            else -> 3
        }
        val ratioHeight = when (selectedFrameRatioLabel) {
            "4:5" -> 5
            "1:1" -> 1
            "9:16" -> 16
            else -> 4
        }
        val viewport = ViewPort.Builder(Rational(ratioWidth, ratioHeight), rotation)
            .setScaleType(ViewPort.FILL_CENTER)
            .build()
        val group = UseCaseGroup.Builder()
            .setViewPort(viewport)
            .addUseCase(preview)
            .addUseCase(capture)
            .addUseCase(analysis)
            .build()
        preview.targetRotation = rotation
        capture.targetRotation = rotation
        analysis.targetRotation = rotation
        provider.unbindAll()
        boundCamera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, group)
        if (manualExposureEnabled || whiteBalanceMode != CaptureRequest.CONTROL_AWB_MODE_AUTO) applyCamera2Options()
    }

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    private fun analyzeFrame(proxy: ImageProxy) {
        val now = System.currentTimeMillis()
        // Give STREAM_MODE enough consecutive frames to acquire its object track, while
        // throttling secondary models to protect entry-level Android devices.
        // Keep the object detector fed frequently during a scan. STREAM_MODE needs
        // a sequence of frames to establish stable tracking IDs; a long throttle
        // makes first-subject acquisition feel sluggish on a live camera.
        val minInterval = if (aiScanRequested) 140L else 520L
        if (analysisBusy || now - lastAnalysisAt < minInterval) {
            proxy.close()
            return
        }
        val media = proxy.image
        if (media == null) {
            proxy.close()
            return
        }

        analysisBusy = true
        lastAnalysisAt = now
        val rotationDegrees = proxy.imageInfo.rotationDegrees
        val rotatedWidth = if (rotationDegrees == 90 || rotationDegrees == 270) proxy.height else proxy.width
        val rotatedHeight = if (rotationDegrees == 90 || rotationDegrees == 270) proxy.width else proxy.height
        val input = InputImage.fromMediaImage(media, rotationDegrees)

        val objectTask = objectDetector.process(input)
        val faceTask = faceDetector.process(input)
        // Delay scene labeling until a real tracked subject exists. This keeps the
        // first detection pass light; scene labels can refine the subject name later.
        val runLabels = aiScanRequested && now - lastLabelAnalysisAt >= 1_600L
        val labelTask = if (runLabels) {
            lastLabelAnalysisAt = now
            imageLabeler.process(input)
        } else null
        // Pose landmarks are only useful for a selected person. Do not spend CPU on
        // pose inference while the user is scanning objects or architecture.
        val runPose = aiScanRequested &&
            (lockedSubjectCandidate == null || lockedSubjectCandidate?.semantic == "person") &&
            now - lastPoseAnalysisAt >= 2_200L
        val poseTask = if (runPose) {
            lastPoseAnalysisAt = now
            poseDetector.process(input)
        } else null

        val expectedTasks = 2 + (if (labelTask != null) 1 else 0) + (if (poseTask != null) 1 else 0)
        val completed = java.util.concurrent.atomic.AtomicInteger(0)
        var detectedObjects: List<DetectedObject> = emptyList()
        var faceRects: List<Rect> = emptyList()
        var sceneLabels: List<ImageLabel> = emptyList()
        var poseRects: List<Rect> = emptyList()
        var posePoints: Map<Int, PointF> = emptyMap()

        fun publishResults() {
            analysisWidth = rotatedWidth
            analysisHeight = rotatedHeight

            if (labelTask != null) {
                latestSceneLabelObjects = sceneLabels
                latestLabels = sceneLabels
                    .filter { it.confidence >= 0.32f }
                    .sortedByDescending { it.confidence }
                    .take(8)
                    .map { it.text }
            }
            if (poseTask == null) {
                // Reuse the previous pose result between throttled inference passes.
                latestPoseBounds?.let { poseRects = listOf(Rect(it)) }
                posePoints = latestPosePoints
            } else {
                latestPosePresent = poseRects.isNotEmpty()
                latestPoseBounds = poseRects.firstOrNull()?.let { Rect(it) }
                latestPosePoints = posePoints
            }

            val candidates = buildSubjectCandidates(
                detectedObjects = detectedObjects,
                faceRects = faceRects,
                poseRects = poseRects,
                labels = latestSceneLabelObjects,
                imageWidth = rotatedWidth,
                imageHeight = rotatedHeight
            )
            val selected = if (aiScanRequested) {
                updateSubjectLock(candidates, rotatedWidth, rotatedHeight)
            } else null

            latestSubject = lockedSubjectCandidate?.label ?: "Finding your shot…"
            runOnUiThread {
                overlay.setDetections(if (selected != null) listOf(selected) else emptyList())
                overlay.setPosePoints(if (latestPosePresent && lockedSubjectCandidate?.semantic == "person") posePoints else emptyMap())
                updateAdvice(fromAnalysis = true)
            }
        }

        fun taskFinished() {
            if (completed.incrementAndGet() == expectedTasks) {
                try {
                    publishResults()
                } finally {
                    proxy.close()
                    analysisBusy = false
                }
            }
        }

        objectTask.addOnSuccessListener { results -> detectedObjects = results }
            .addOnCompleteListener { taskFinished() }
        faceTask.addOnSuccessListener { results -> faceRects = results.map { Rect(it.boundingBox) } }
            .addOnCompleteListener { taskFinished() }
        labelTask?.addOnSuccessListener { results -> sceneLabels = results }
            ?.addOnCompleteListener { taskFinished() }
        poseTask?.addOnSuccessListener { poseResult: Pose ->
            // Use the official ML Kit accessor with inferred Pose type. This avoids an
            // unnecessary explicit callback type while preserving the full Pose API.
            val landmarks = poseResult.getAllPoseLandmarks()
            val visible = landmarks.filter { it.getInFrameLikelihood() >= 0.35f }
            if (visible.size >= 5) {
                val xs = visible.map { it.getPosition().x }
                val ys = visible.map { it.getPosition().y }
                val minX = xs.minOrNull() ?: 0f
                val maxX = xs.maxOrNull() ?: 0f
                val minY = ys.minOrNull() ?: 0f
                val maxY = ys.maxOrNull() ?: 0f
                val padX = (rotatedWidth * 0.025f).toInt()
                val padY = (rotatedHeight * 0.025f).toInt()
                poseRects = listOf(
                    Rect(
                        (minX.toInt() - padX).coerceAtLeast(0),
                        (minY.toInt() - padY).coerceAtLeast(0),
                        (maxX.toInt() + padX).coerceAtMost(rotatedWidth),
                        (maxY.toInt() + padY).coerceAtMost(rotatedHeight)
                    )
                )
                val points = mutableMapOf<Int, PointF>()
                visible.forEach { landmark ->
                    val position = landmark.getPosition()
                    points[landmark.getLandmarkType()] = PointF(position.x, position.y)
                }
                posePoints = points
            }
        }?.addOnCompleteListener { taskFinished() }
    }

    private fun buildSubjectCandidates(
        detectedObjects: List<DetectedObject>,
        faceRects: List<Rect>,
        poseRects: List<Rect>,
        labels: List<ImageLabel>,
        imageWidth: Int,
        imageHeight: Int
    ): List<SubjectCandidate> {
        val sceneHints = labels
            .filter { it.confidence >= 0.40f }
            .sortedByDescending { it.confidence }
            .map { it.text.lowercase(java.util.Locale.US) }

        val candidates = mutableListOf<SubjectCandidate>()
        detectedObjects.forEach { detected ->
            val box = RectF(detected.boundingBox)
            val topLabel = detected.labels.maxByOrNull { it.confidence }
            val category = topLabel?.text?.lowercase(java.util.Locale.US)?.trim().orEmpty().ifBlank { "object" }
            val confidence = topLabel?.confidence ?: 0.42f
            candidates.add(
                SubjectCandidate(
                    bounds = box,
                    source = "object",
                    semantic = normalizeSemantic(category),
                    label = inferSubjectLabel(category, sceneHints),
                    confidence = confidence,
                    trackingId = detected.trackingId
                )
            )
        }

        // Prefer a face box over a duplicate whole-body pose box when a face is visible.
        val face = faceRects.maxByOrNull { it.width().toLong() * it.height().toLong() }
        if (face != null) {
            candidates.add(
                SubjectCandidate(RectF(face), "face", "person", "person", 0.94f, null)
            )
        } else {
            val pose = poseRects.maxByOrNull { it.width().toLong() * it.height().toLong() }
            if (pose != null) {
                candidates.add(
                    SubjectCandidate(RectF(pose), "pose", "person", "person", 0.86f, null)
                )
            }
        }

        return candidates.filter { candidate ->
            candidate.bounds.width() >= 10f && candidate.bounds.height() >= 10f &&
                candidate.bounds.right > 0f && candidate.bounds.bottom > 0f &&
                candidate.bounds.left < imageWidth && candidate.bounds.top < imageHeight
        }
    }

    private fun normalizeSemantic(category: String): String = when {
        category.contains("food") -> "food"
        category.contains("plant") -> "plant"
        category.contains("fashion") -> "fashion"
        category.contains("home") -> "home"
        category.contains("place") -> "place"
        category.contains("person") -> "person"
        else -> "object"
    }

    private fun inferSubjectLabel(category: String, sceneHints: List<String>): String {
        val semantic = normalizeSemantic(category)
        val hints = sceneHints.map { it.lowercase(java.util.Locale.US).replace('_', ' ').trim() }
        fun has(vararg words: String): Boolean = hints.any { hint ->
            words.any { word -> hint == word || hint.contains("$word ") || hint.contains(" $word") }
        }

        // Combine related scene labels into a useful object name when the on-device
        // labeler actually supplies those details. Never invent material or attributes.
        if (semantic == "home") {
            if (has("door") && has("handle", "knob")) {
                return if (has("metal", "steel", "brass", "chrome")) "metal door handle" else "door handle"
            }
            if (has("hanging", "pendant") && has("light", "lamp", "lighting")) return "hanging light"
            if (has("ceiling") && has("light", "lamp", "lighting")) return "ceiling light"
            if (has("lamp", "light", "lighting")) return "light"
            if (has("chair", "armchair")) return "chair"
            if (has("table", "desk")) return "table"
            if (has("sofa", "couch")) return "sofa"
            if (has("mirror")) return "mirror"
            if (has("window")) return "window"
            if (has("clock")) return "clock"
            if (has("vase")) return "vase"
            if (has("bottle")) return "bottle"
            if (has("cup", "mug")) return "cup"
        }
        if (semantic == "plant") {
            if (has("flower", "blossom")) return "flower"
            if (has("leaf", "foliage")) return "leaf detail"
            if (has("tree")) return "tree"
        }
        if (semantic == "food") {
            if (has("cake", "pastry")) return "cake detail"
            if (has("bread", "loaf")) return "bread"
            if (has("fruit")) return "fruit"
            if (has("dish", "meal")) return "dish"
        }
        if (semantic == "fashion") {
            if (has("shoe", "sneaker", "footwear")) return "shoe detail"
            if (has("bag", "backpack", "handbag")) return "bag detail"
            if (has("hat", "cap")) return "hat"
        }
        if (semantic == "place") {
            if (has("building", "architecture")) return "architectural detail"
            if (has("bridge")) return "bridge"
            if (has("car", "vehicle")) return "vehicle"
        }
        return when (semantic) {
            "food" -> "food detail"
            "plant" -> "plant detail"
            "fashion" -> "fashion detail"
            "home" -> "home detail"
            "place" -> "place detail"
            "person" -> "person"
            else -> "subject detail"
        }
    }

    private fun candidateInterestScore(candidate: SubjectCandidate, imageWidth: Int, imageHeight: Int): Float {
        val area = (candidate.bounds.width() * candidate.bounds.height()) /
            max(1f, imageWidth.toFloat() * imageHeight.toFloat())
        val sizeScore = when {
            area < 0.0012f -> 0.08f
            area < 0.008f -> (0.25f + area / 0.008f * 0.65f).coerceIn(0f, 1f)
            area <= 0.30f -> 1f
            area <= 0.52f -> 0.62f
            else -> 0.12f
        }
        val dx = candidate.bounds.centerX() / max(1f, imageWidth.toFloat()) - 0.5f
        val dy = candidate.bounds.centerY() / max(1f, imageHeight.toFloat()) - 0.5f
        val centerScore = 1f - (kotlin.math.sqrt(dx * dx + dy * dy) / 0.72f).coerceIn(0f, 1f)
        val semanticScore = when (candidate.semantic) {
            "person" -> 0.92f
            "plant", "food", "fashion", "home" -> 0.88f
            "place" -> 0.72f
            else -> 0.60f
        }
        val sourceBonus: Float = when (candidate.source) {
            "face" -> 0.08f
            "pose" -> 0.04f
            else -> 0f
        }
        val edgePenalty = if (
            candidate.bounds.left <= imageWidth * 0.01f || candidate.bounds.top <= imageHeight * 0.01f ||
            candidate.bounds.right >= imageWidth * 0.99f || candidate.bounds.bottom >= imageHeight * 0.99f
        ) 0.06f else 0f
        return (candidate.confidence.coerceIn(0.15f, 1f) * 0.30f +
            sizeScore * 0.31f + centerScore * 0.16f + semanticScore * 0.23f +
            sourceBonus - edgePenalty).coerceIn(0f, 1f)
    }

    private fun sameSubject(a: SubjectCandidate, b: SubjectCandidate, imageWidth: Int, imageHeight: Int): Boolean {
        if (a.trackingId != null && b.trackingId != null && a.source == "object" && b.source == "object") {
            return a.trackingId == b.trackingId
        }
        if (a.semantic != b.semantic) return false
        val iou = intersectionOverUnion(a.bounds, b.bounds)
        val distance = centerDistance(a.bounds, b.bounds, imageWidth, imageHeight)
        return iou >= 0.10f || distance <= 0.0225f
    }

    private fun updateSubjectLock(candidates: List<SubjectCandidate>, imageWidth: Int, imageHeight: Int): Rect? {
        val locked = lockedSubjectCandidate
        if (locked != null) {
            val matching = candidates
                .filter { sameSubject(locked, it, imageWidth, imageHeight) }
                .maxByOrNull { candidateInterestScore(it, imageWidth, imageHeight) }
            if (matching != null) {
                lockedSubjectMissFrames = 0
                val previous = lastTrackedBox
                val target = matching.bounds
                val smoothing = if (trackingEnabled && previous != null) 0.68f else 1f
                val smoothed = if (previous == null) RectF(target) else RectF(
                    previous.left + (target.left - previous.left) * smoothing,
                    previous.top + (target.top - previous.top) * smoothing,
                    previous.right + (target.right - previous.right) * smoothing,
                    previous.bottom + (target.bottom - previous.bottom) * smoothing
                )
                lastTrackedBox = smoothed
                lockedSubjectCandidate = matching.copy(
                    bounds = RectF(smoothed),
                    trackingId = locked.trackingId ?: matching.trackingId,
                    label = if (
                        locked.label in setOf("subject detail", "home detail", "plant detail", "food detail", "fashion detail", "place detail") &&
                        matching.label !in setOf("subject detail", "home detail", "plant detail", "food detail", "fashion detail", "place detail")
                    ) matching.label else locked.label
                )
                return Rect(smoothed.left.toInt(), smoothed.top.toInt(), smoothed.right.toInt(), smoothed.bottom.toInt())
            }

            // Keep the identity and last position briefly through detector dropouts. Never
            // jump to a different nearby object just because it scores higher for one frame.
            lockedSubjectMissFrames++
            if (lockedSubjectMissFrames <= 12) {
                val previous = lastTrackedBox ?: return null
                return Rect(previous.left.toInt(), previous.top.toInt(), previous.right.toInt(), previous.bottom.toInt())
            }
            lockedSubjectCandidate = null
            lockedSubjectMissFrames = 0
            lastTrackedBox = null
            pendingSubjectCandidate = null
            pendingSubjectFrames = 0
        }

        val best = candidates.maxByOrNull { candidateInterestScore(it, imageWidth, imageHeight) }
        if (best == null || candidateInterestScore(best, imageWidth, imageHeight) < 0.38f) {
            pendingSubjectCandidate = null
            pendingSubjectFrames = 0
            return null
        }

        val pending = pendingSubjectCandidate
        if (pending != null && sameSubject(pending, best, imageWidth, imageHeight)) {
            pendingSubjectFrames++
            pendingSubjectCandidate = best
        } else {
            pendingSubjectCandidate = best
            pendingSubjectFrames = 1
        }

        // Require repeated detections before drawing a target. This avoids yellow boxes
        // flashing around transient, low-confidence detections while the user scans a room.
        if (pendingSubjectFrames < 3) return null

        val stable = pendingSubjectCandidate ?: best
        lockedSubjectCandidate = stable.copy(bounds = RectF(stable.bounds))
        lockedSubjectMissFrames = 0
        lastTrackedBox = RectF(stable.bounds)
        return Rect(
            stable.bounds.left.toInt(), stable.bounds.top.toInt(),
            stable.bounds.right.toInt(), stable.bounds.bottom.toInt()
        )
    }

    private fun intersectionOverUnion(a: RectF, b: RectF): Float {
        val left = max(a.left, b.left)
        val top = max(a.top, b.top)
        val right = min(a.right, b.right)
        val bottom = min(a.bottom, b.bottom)
        val intersection = max(0f, right - left) * max(0f, bottom - top)
        val union = a.width() * a.height() + b.width() * b.height() - intersection
        return if (union <= 0f) 0f else intersection / union
    }

    private fun centerDistance(a: RectF, b: RectF, imageWidth: Int, imageHeight: Int): Float {
        val dx = (a.centerX() - b.centerX()) / max(1, imageWidth).toFloat()
        val dy = (a.centerY() - b.centerY()) / max(1, imageHeight).toFloat()
        return dx * dx + dy * dy
    }

    private fun onAiButtonClicked() {
        when {
            !aiScanRequested -> triggerAiRecommendation()                       // ✦ start
            compositionReady -> { resetAiScan(); triggerAiRecommendation() }    // ↻ scan a new scene
            else -> resetAiScan()                                               // ✕ cancel
        }
    }

    private fun triggerAiRecommendation() {
        if (!::subjectChip.isInitialized) return
        aiScanRequested = true
        scanFinished = false
        emptyDetectionFrames = 0
        lastTrackedBox = null
        latestLabels = emptyList()
        latestSceneLabelObjects = emptyList()
        latestPosePresent = false
        latestPoseBounds = null
        latestPosePoints = emptyMap()
        lastLabelAnalysisAt = 0L
        lastPoseAnalysisAt = 0L
        pendingSubjectCandidate = null
        pendingSubjectFrames = 0
        lockedSubjectCandidate = null
        lockedSubjectMissFrames = 0
        overlay.subjectBounds = null
        overlay.subjectLabel = ""
        readyFrameCount = 0
        compositionReady = false
        aiGuideEnabled = true
        overlay.aiGuidesEnabled = true
        updateAdvice()
    }

    private fun resetAiScan() {
        aiScanRequested = false
        scanFinished = true
        emptyDetectionFrames = 0
        readyFrameCount = 0
        compositionReady = false
        pendingSubjectCandidate = null
        pendingSubjectFrames = 0
        lockedSubjectCandidate = null
        lockedSubjectMissFrames = 0
        lastTrackedBox = null
        aiGuideEnabled = false
        overlay.aiGuidesEnabled = false
        overlay.subjectBounds = null
        overlay.subjectLabel = ""
        resetZoomPresets()
        setZoom(1f)
        refreshZoomButtons()
        updateAdvice()
    }

    private fun updateAiButton() {
        if (!::aiButton.isInitialized) return
        val yellow = Color.rgb(255, 214, 0)
        when {
            !aiScanRequested -> {
                aiButton.text = "✦"; aiButton.textSize = 30f
                aiButton.setTextColor(yellow)
                aiButton.background = roundBackground(Color.rgb(48, 40, 0))
                aiButton.contentDescription = "Scan scene"
            }
            compositionReady -> {
                aiButton.text = "↻"; aiButton.textSize = 28f
                aiButton.setTextColor(yellow)
                aiButton.background = roundBackground(Color.rgb(48, 40, 0))
                aiButton.contentDescription = "Scan a new scene"
            }
            else -> {
                aiButton.text = "✕"; aiButton.textSize = 24f
                aiButton.setTextColor(Color.WHITE)
                aiButton.background = roundBackground(Color.rgb(40, 40, 40))
                aiButton.contentDescription = "Cancel scan"
            }
        }
    }

    private fun updateAdvice(extra: String? = null, fromAnalysis: Boolean = false) {
        val box = lastTrackedBox
        val lockedSubject = lockedSubjectCandidate
        var hint: String
        var hintColor = Color.WHITE

        if (manualFraming || !aiScanRequested || box == null || lockedSubject == null) {
            readyFrameCount = 0
            compositionReady = false
            overlay.subjectBounds = null
            overlay.subjectLabel = ""
            overlay.boxAlpha = 0f
            overlay.readyState = false
            hint = when {
                manualFraming -> "Manual framing: use the grid to compose"
                aiScanRequested -> "Finding your shot…"
                scanFinished -> "Tap ✦ to scan a new scene"
                else -> "Point your camera and tap the ✦ button"
            }
            hintColor = if (aiScanRequested && !manualFraming) Color.rgb(255, 214, 0) else Color.LTGRAY
        } else {
            val width = max(1f, analysisWidth.toFloat())
            val height = max(1f, analysisHeight.toFloat())
            val bounds = RectF(
                (box.left / width).coerceIn(0f, 1f),
                (box.top / height).coerceIn(0f, 1f),
                (box.right / width).coerceIn(0f, 1f),
                (box.bottom / height).coerceIn(0f, 1f)
            )
            overlay.subjectBounds = bounds
            overlay.subjectLabel = lockedSubject.label
            overlay.boxAlpha = 1f

            val subjectArea = bounds.width() * bounds.height()
            val centerX = bounds.centerX()
            val centerY = bounds.centerY()
            val levelOk = abs(rollDegrees) < 3.5f
            val sizeOk = subjectArea in 0.022f..0.34f
            val placementOk = centerX in 0.30f..0.70f && centerY in 0.24f..0.76f
            val notClipped = bounds.left > 0.005f && bounds.top > 0.005f &&
                bounds.right < 0.995f && bounds.bottom < 0.995f
            val aligned = levelOk && sizeOk && placementOk && notClipped

            val centerError = abs(centerX - 0.5f) + abs(centerY - 0.5f)
            val alignmentScore = (100f - centerError * 165f).coerceIn(0f, 100f)
            val sizeScore = when {
                subjectArea in 0.045f..0.24f -> 100f
                subjectArea < 0.045f -> (subjectArea / 0.045f * 100f).coerceIn(0f, 100f)
                else -> (100f - (subjectArea - 0.24f) * 210f).coerceIn(0f, 100f)
            }
            val levelScore = (100f - abs(rollDegrees) * 13f).coerceIn(0f, 100f)
            latestCompositionScore = (alignmentScore * 0.34f + sizeScore * 0.42f + levelScore * 0.24f).toInt()

            if (!aligned) {
                readyFrameCount = 0
                compositionReady = false
            } else if (fromAnalysis) {
                readyFrameCount = (readyFrameCount + 1).coerceAtMost(3)
                compositionReady = readyFrameCount >= 3
            }

            val name = lockedSubject.label.lowercase(java.util.Locale.US)
            hint = when {
                !levelOk -> "Level the horizon."
                subjectArea < 0.022f -> "Isolate that $name. Go tighter."
                subjectArea > 0.34f -> "Back up a little. Give the $name room."
                !placementOk -> "Reframe the $name a little closer to the center."
                !notClipped -> "Keep the whole $name inside the frame."
                compositionReady -> "Shot ready. Hold steady."
                else -> "Hold the $name steady."
            }
            hintColor = if (compositionReady) Color.rgb(120, 235, 155) else Color.WHITE
        }

        if (!extra.isNullOrBlank()) hint = extra
        guideMessage = hint
        overlay.sourceAspectRatio = analysisWidth.toFloat() / max(1f, analysisHeight.toFloat())
        overlay.aiGuidesEnabled = aiGuideEnabled
        overlay.readyState = compositionReady
        overlay.rollDegrees = rollDegrees
        overlay.invalidate()

        // While aligning, the label is attached to the live object box. Once Ready,
        // Framed-style UI clears the box and promotes the label to the fixed top chip.
        if (::subjectChip.isInitialized) {
            if (compositionReady && lockedSubjectCandidate != null) {
                val readyLabel = android.text.SpannableString("${lockedSubjectCandidate!!.label}   Ready")
                readyLabel.setSpan(
                    android.text.style.ForegroundColorSpan(Color.rgb(145, 242, 170)),
                    readyLabel.length - "Ready".length, readyLabel.length,
                    android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                subjectChip.text = readyLabel
                subjectChip.visibility = View.VISIBLE
            } else if (aiScanRequested && lockedSubjectCandidate != null && !manualFraming) {
                subjectChip.text = lockedSubjectCandidate!!.label
                subjectChip.setTextColor(Color.WHITE)
                subjectChip.visibility = View.VISIBLE
            } else {
                subjectChip.visibility = View.INVISIBLE
            }
        }
        statusText.setTextColor(hintColor)
        statusText.text = hint
        updateAiButton()
    }

    private data class EditState(
        val tone: Tone, val brightness: Float, val contrast: Float, val saturation: Float,
        val highlights: Float, val shadows: Float, val vignette: Float, val grain: Float, val frame: Int,
        val temperature: Float, val tint: Float
    )

    private fun currentEditState() = EditState(
        currentTone, editBrightness, editContrast, editSaturation,
        editHighlights, editShadows, editVignette, editGrain, editFrame, editTemperature, editTint
    )

    private fun restoreEditState(state: EditState) {
        currentTone = state.tone
        editBrightness = state.brightness
        editContrast = state.contrast
        editSaturation = state.saturation
        editHighlights = state.highlights
        editShadows = state.shadows
        editVignette = state.vignette
        editGrain = state.grain
        editFrame = state.frame
        editTemperature = state.temperature
        editTint = state.tint
    }

    private fun openColorStudio(sourceUri: Uri? = null) {
        val uri = sourceUri ?: latestPhotoUri ?: selectedPhotoUri
        if (uri == null) {
            Toast.makeText(this, "Take or pick a photo first to open Color Studio", Toast.LENGTH_LONG).show()
            photoPicker.launch("image/*")
            return
        }
        selectedPhotoUri = uri
        val dialog = android.app.Dialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(8, 8, 10))
            setPadding(dp(16), dp(10), dp(16), dp(12))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "Color Studio"
            textSize = 20f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))
        val close = TextView(this).apply {
            text = "✕"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(8), dp(8), dp(8))
            setOnClickListener { dialog.dismiss() }
        }
        header.addView(close)
        root.addView(header)

        val previewFrame = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }
        val preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }
        try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            var sample = 1
            while (max(opts.outWidth, opts.outHeight) / sample > 1400) sample *= 2
            val bmp = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            }
            if (bmp != null) preview.setImageBitmap(bmp)
        } catch (_: Exception) {
            Toast.makeText(this, "Photo preview could not be loaded", Toast.LENGTH_SHORT).show()
        }
        previewFrame.addView(preview, FrameLayout.LayoutParams(-1, -1))
        root.addView(previewFrame, LinearLayout.LayoutParams(-1, 0, 1.0f).apply {
            topMargin = dp(8); bottomMargin = dp(12)
        })

        val tabs = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        val bodyScroll = android.widget.ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(8)) }
        bodyScroll.addView(body)
        root.addView(tabs, LinearLayout.LayoutParams(-1, dp(42)))
        root.addView(bodyScroll, LinearLayout.LayoutParams(-1, dp(190)))

        val history = mutableListOf(currentEditState())
        var historyIndex = 0
        fun recordChange() {
            while (history.lastIndex > historyIndex) history.removeAt(history.lastIndex)
            history.add(currentEditState())
            if (history.size > 30) history.removeAt(0)
            historyIndex = history.lastIndex
        }
        fun refreshPreview() {
            val matrix = ColorMatrix(currentTone.matrix)
            matrix.postConcat(ColorMatrix().apply { setSaturation(editSaturation) })
            val c = editContrast
            val b = editBrightness + editShadows * 18f + editHighlights * 10f
            matrix.postConcat(ColorMatrix(floatArrayOf(
                c,0f,0f,0f,b + editTemperature * .18f, 0f,c,0f,0f,b + editTint * .10f, 0f,0f,c,0f,b - editTemperature * .18f, 0f,0f,0f,1f,0f
            )))
            preview.colorFilter = android.graphics.ColorMatrixColorFilter(matrix)
            previewFrame.foreground = when (editFrame) {
                1 -> android.graphics.drawable.GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(dp(10), Color.WHITE) }
                2 -> android.graphics.drawable.GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(dp(10), Color.BLACK) }
                3 -> android.graphics.drawable.GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(dp(10), Color.rgb(210,160,100)) }
                else -> null
            }
        }
        fun heading(text: String) {
            body.addView(TextView(this).apply {
                this.text = text.uppercase(); textSize = 11f; setTextColor(Color.LTGRAY)
                setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, dp(4), 0, dp(10))
            })
        }
        fun addSlider(label: String, minValue: Int, maxValue: Int, initial: Int, onValue: (Int) -> Unit) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val valueLabel = TextView(this).apply { text = "$label  $initial"; textSize = 12f; setTextColor(Color.WHITE) }
            val seek = SeekBar(this).apply {
                max = maxValue - minValue
                progress = (initial - minValue).coerceIn(0, max)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        val value = progress + minValue
                        valueLabel.text = "$label  $value"
                        onValue(value)
                        refreshPreview()
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                    override fun onStopTrackingTouch(seekBar: SeekBar?) { if (seekBar != null) recordChange() }
                })
            }
            row.addView(valueLabel); row.addView(seek)
            body.addView(row)
        }
        var activeTab = "Looks"
        fun showTab(tab: String) {
            body.removeAllViews()
            when (tab) {
                "Looks" -> {
                    heading("Choose your look")
                    val names = listOf("LEAN", "HARBOR", "DUSK", "PRESS", "ALBU")
                    val tones = listOf(Tone.NATURAL, Tone.COOL, Tone.FILM, Tone.MONO, Tone.WARM)
                    val colors = listOf(Color.rgb(45,76,72), Color.rgb(44,88,91), Color.rgb(91,91,76), Color.DKGRAY, Color.rgb(118,86,61))
                    val strip = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
                    names.forEachIndexed { index, name ->
                        val tile = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(4), dp(4), dp(4)) }
                        val swatch = View(this).apply { background = roundBackground(colors[index]) }
                        tile.addView(swatch, LinearLayout.LayoutParams(dp(48), dp(54)))
                        tile.addView(TextView(this).apply { text = name; textSize = 9f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
                        tile.setOnClickListener { currentTone = tones[index]; recordChange(); refreshPreview(); showTab("Looks") }
                        strip.addView(tile, LinearLayout.LayoutParams(0, dp(88), 1f))
                    }
                    body.addView(strip)
                }
                "Adjust" -> {
                    heading("Fine tune")
                    addSlider("Exposure", -100, 100, editBrightness.toInt()) { editBrightness = it.toFloat() }
                    addSlider("Contrast", 50, 150, (editContrast * 100).toInt()) { editContrast = it / 100f }
                    addSlider("Highlights", -100, 100, (editHighlights * 100).toInt()) { editHighlights = it / 100f }
                    addSlider("Shadows", -100, 100, (editShadows * 100).toInt()) { editShadows = it / 100f }
                    addSlider("Saturation", 0, 200, (editSaturation * 100).toInt()) { editSaturation = it / 100f }
                    addSlider("Temperature", -100, 100, editTemperature.toInt()) { editTemperature = it.toFloat() }
                    addSlider("Tint", -100, 100, editTint.toInt()) { editTint = it.toFloat() }
                }
                "Effects" -> {
                    heading("Texture & atmosphere")
                    addSlider("Grain", 0, 100, (editGrain * 100).toInt()) { editGrain = it / 100f }
                    addSlider("Vignette", 0, 100, (editVignette * 100).toInt()) { editVignette = it / 100f }
                }
                "Frames" -> {
                    heading("Frame")
                    listOf("None", "White", "Black", "Warm").forEachIndexed { index, label ->
                        val button = Button(this).apply { text = label; isAllCaps = false; setTextColor(Color.WHITE); background = roundBackground(Color.rgb(35,35,38)) }
                        button.setOnClickListener { editFrame = index; recordChange(); refreshPreview() }
                        body.addView(button, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(4) })
                    }
                }
            }
        }
        listOf("Looks", "Adjust", "Effects", "Frames").forEach { tab ->
            val button = TextView(this).apply {
                text = tab; gravity = Gravity.CENTER; textSize = 12f; setTextColor(Color.WHITE)
                setPadding(dp(9), 0, dp(9), 0)
                setOnClickListener { activeTab = tab; showTab(tab) }
            }
            tabs.addView(button, LinearLayout.LayoutParams(0, -1, 1f))
        }
        val actions = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        fun action(text: String, onClick: () -> Unit) {
            actions.addView(Button(this).apply { this.text = text; isAllCaps = false; setTextColor(Color.WHITE); background = roundBackground(Color.rgb(38,38,42)); setOnClickListener { onClick() } },
                LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) })
        }
        action("Delete") {
            android.app.AlertDialog.Builder(this).setTitle("Delete photo?")
                .setMessage("The original photo will be deleted from your gallery.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete") { _, _ ->
                    val ok = contentResolver.delete(uri, null, null) > 0
                    if (ok && uri == latestPhotoUri) { latestPhotoUri = null; galleryThumbnail.setImageResource(android.R.drawable.ic_menu_gallery) }
                    Toast.makeText(this, if (ok) "Photo deleted" else "Could not delete photo", Toast.LENGTH_SHORT).show()
                    if (ok) dialog.dismiss()
                }.show()
        }
        action("↶") { if (historyIndex > 0) { historyIndex--; restoreEditState(history[historyIndex]); refreshPreview(); showTab(activeTab) } }
        action("↷") { if (historyIndex < history.lastIndex) { historyIndex++; restoreEditState(history[historyIndex]); refreshPreview(); showTab(activeTab) } }
        val save = Button(this).apply {
            text = "✓ Save"; isAllCaps = false; setTextColor(Color.BLACK)
            background = roundBackground(Color.rgb(255, 210, 20))
            setOnClickListener { dialog.dismiss(); applyToneToUri(uri) }
        }
        actions.addView(save, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(actions, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })
        showTab(activeTab)
        refreshPreview()
        dialog.setContentView(root)
        dialog.window?.setBackgroundDrawableResource(android.R.color.black)
        dialog.window?.setLayout(-1, -1)
        dialog.show()
        dialog.window?.setLayout(-1, -1)
    }

    private fun decodePreviewBitmap(uri: Uri, maxDimension: Int = 1600): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth / sample, bounds.outHeight / sample) > maxDimension) sample *= 2
        return contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            })
        }
    }

    private fun showPhotoPreview(uri: Uri, allowEdit: Boolean) {
        val image = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
        }
        try {
            val previewBitmap = decodePreviewBitmap(uri)
            if (previewBitmap == null) throw IllegalStateException("Photo could not be opened")
            image.setImageBitmap(previewBitmap)
        } catch (_: Exception) {
            Toast.makeText(this, "Photo could not be opened", Toast.LENGTH_SHORT).show()
            return
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(4))
            addView(image, LinearLayout.LayoutParams(-1, dp(420)))
        }
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Photo preview")
            .setView(container)
            .setPositiveButton(if (allowEdit) "Edit photo" else "Close", null)
            .setNeutralButton("Share", null)
            .setNegativeButton("Delete", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (!allowEdit) { dialog.dismiss(); return@setOnClickListener }
                dialog.dismiss()
                openColorStudio(uri)
            }
            dialog.getButton(android.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val share = Intent(Intent.ACTION_SEND).apply { type = "image/*"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                startActivity(Intent.createChooser(share, "Share photo"))
            }
            dialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                android.app.AlertDialog.Builder(this)
                    .setTitle("Delete photo?")
                    .setMessage("This photo will be deleted from your gallery.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete") { _, _ ->
                        val deleted = contentResolver.delete(uri, null, null) > 0
                        statusText.text = if (deleted) "Photo deleted" else "Could not delete photo"
                        if (uri == latestPhotoUri) { latestPhotoUri = null; galleryThumbnail.setImageResource(android.R.drawable.ic_menu_gallery) }
                        dialog.dismiss()
                    }.show()
            }
        }
        dialog.show()
    }

    private fun applyToneToUri(uri: Uri) {
        cameraExecutor.execute {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) error("Photo could not be opened")
                // Keep memory use predictable on mid-range phones. The source photo is never modified.
                var sample = 1
                while ((bounds.outWidth.toLong() / sample) * (bounds.outHeight.toLong() / sample) > 6_000_000L) sample *= 2
                val bitmap = contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
                } ?: error("Photo could not be opened")
                val edited = applyFullEdit(bitmap)
                val saved = saveEditedBitmap(edited)
                bitmap.recycle()
                edited.recycle()
                runOnUiThread {
                    statusText.text = if (saved) "Edit saved as a copy. Your original is untouched." else "Could not save the edit."
                    Toast.makeText(this, statusText.text, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread { statusText.text = "Edit failed: ${e.localizedMessage}" }
            }
        }
    }

    private fun applyFullEdit(source: Bitmap): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val toneMatrix = ColorMatrix(currentTone.matrix)
        val saturationMatrix = ColorMatrix().apply { setSaturation(editSaturation) }
        toneMatrix.postConcat(saturationMatrix)
        val contrast = editContrast
        val brightness = editBrightness
        val adjust = ColorMatrix(floatArrayOf(
            contrast,0f,0f,0f,brightness, 0f,contrast,0f,0f,brightness,
            0f,0f,contrast,0f,brightness, 0f,0f,0f,1f,0f
        ))
        toneMatrix.postConcat(adjust)
        toneMatrix.postConcat(ColorMatrix(floatArrayOf(
            1f,0f,0f,0f,editTemperature * .18f,
            0f,1f,0f,0f,editTint * .10f,
            0f,0f,1f,0f,-editTemperature * .18f,
            0f,0f,0f,1f,0f
        )))
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(toneMatrix)
        }
        canvas.drawBitmap(source, 0f, 0f, paint)
        if (editHighlights != 0f || editShadows != 0f) {
            // Process in small horizontal bands to avoid allocating a full-resolution
            // second pixel array on mid-range devices such as Redmi 13C.
            val bandHeight = 64
            var top = 0
            while (top < output.height) {
                val rows = min(bandHeight, output.height - top)
                val pixels = IntArray(output.width * rows)
                output.getPixels(pixels, 0, output.width, 0, top, output.width, rows)
                for (i in pixels.indices) {
                    val color = pixels[i]
                    val r = Color.red(color).toFloat()
                    val g = Color.green(color).toFloat()
                    val b = Color.blue(color).toFloat()
                    val luminance = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
                    val shadowLift = editShadows * (1f - luminance) * (1f - luminance) * 72f
                    val highlightShift = editHighlights * luminance * luminance * 72f
                    val delta = shadowLift + highlightShift
                    pixels[i] = Color.rgb(
                        (r + delta).toInt().coerceIn(0, 255),
                        (g + delta).toInt().coerceIn(0, 255),
                        (b + delta).toInt().coerceIn(0, 255)
                    )
                }
                output.setPixels(pixels, 0, output.width, 0, top, output.width, rows)
                top += rows
            }
        }
        if (editGrain > 0f) {
            val random = java.util.Random(7L)
            val count = (source.width.toLong() * source.height / 180L * editGrain).toInt().coerceAtMost(120000)
            val grainPaint = Paint().apply { alpha = (editGrain * 55).toInt(); strokeWidth = 1f }
            repeat(count) {
                val x = random.nextInt(source.width).toFloat()
                val y = random.nextInt(source.height).toFloat()
                grainPaint.color = if (random.nextBoolean()) Color.WHITE else Color.BLACK
                canvas.drawPoint(x, y, grainPaint)
            }
        }
        if (editVignette > 0f) {
            val radius = max(source.width, source.height) * .72f
            val shader = RadialGradient(source.width / 2f, source.height / 2f, radius,
                intArrayOf(Color.TRANSPARENT, Color.argb((editVignette * 180).toInt(), 0, 0, 0)),
                floatArrayOf(.45f, 1f), Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, source.width.toFloat(), source.height.toFloat(), Paint().apply { this.shader = shader })
        }
        if (editFrame > 0) {
            val color = when (editFrame) { 1 -> Color.WHITE; 2 -> Color.BLACK; else -> Color.rgb(210, 160, 100) }
            val width = max(8f, min(source.width, source.height) * .025f)
            canvas.drawRect(0f, 0f, source.width.toFloat(), source.height.toFloat(), Paint().apply {
                this.color = color; style = Paint.Style.STROKE; strokeWidth = width
            })
        }
        return output
    }

    private fun sceneRecommendation(labels: List<String>, subjectFraction: Float = 0.3f): String {
        val text = labels.joinToString(" ").lowercase()
        val base = when {
            text.contains("food") || text.contains("dish") -> "Shoot slightly from above."
            text.contains("plant") || text.contains("flower") -> "Separate the subject from the background."
            text.contains("building") || text.contains("architecture") -> "Keep the vertical lines straight."
            text.contains("landscape") || text.contains("sky") || text.contains("mountain") -> "Place the horizon on a thirds line."
            text.contains("animal") || text.contains("dog") || text.contains("cat") || text.contains("bird") -> "Get level with your subject."
            text.contains("person") || text.contains("people") -> "Leave some room above the head."
            labels.isNotEmpty() -> "Isolate the ${labels.first().lowercase()}."
            else -> "Place the subject on a thirds point."
        }
        return if (subjectFraction < 0.06f) "$base Go tighter." else base
    }

    private fun saveEditedBitmap(bitmap: Bitmap): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "BestShot_Edit_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BestShotAI/Edits")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            val stream = contentResolver.openOutputStream(uri) ?: throw IllegalStateException("Storage is unavailable")
            val encoded = stream.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 96, it) }
            if (!encoded) throw IllegalStateException("JPEG encoding failed")
            true
        } catch (_: Exception) {
            contentResolver.delete(uri, null, null)
            false
        }
    }

    override fun onResume() {
        super.onResume()
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.also {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        sensorManager.unregisterListener(this)
        super.onPause()
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0]
        val y = event.values[1]
        rollDegrees = Math.toDegrees(kotlin.math.atan2(x.toDouble(), y.toDouble())).toFloat()
        overlay.rollDegrees = rollDegrees
        horizonAdvice = if (abs(rollDegrees) < 2.5f) "Level" else "Tilted ${"%.1f".format(java.util.Locale.US, abs(rollDegrees))}°"
        overlay.invalidate()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    /** Capture exactly one frame per shutter press. No hidden burst or automatic selection. */
    private fun capturePhoto() {
        val capture = imageCapture
        if (capture == null) {
            statusText.text = "Camera not ready. Try again in a moment."
            return
        }
        if (isCapturing) return
        isCapturing = true
        shutterButton.isEnabled = false
        statusText.text = "Capturing at full quality…"
        val file = File(cacheDir, "bestshot_${System.nanoTime()}.jpg")
        val options = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                cameraExecutor.execute {
                    val savedUri = try { saveOriginalJpeg(file) } finally { file.delete() }
                    runOnUiThread {
                        if (savedUri != null) {
                            updateGalleryThumbnail(savedUri)
                            finishCapture("Photo saved • original camera JPEG kept ✓")
                        } else {
                            finishCapture("Could not save photo to gallery.")
                        }
                    }
                }
            }
            override fun onError(exception: ImageCaptureException) {
                file.delete()
                finishCapture("Capture failed: ${exception.message ?: "camera error"}")
            }
        })
    }

    private fun saveOriginalJpeg(file: File): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "BestShot_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BestShotAI")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            val output = contentResolver.openOutputStream(uri) ?: error("Could not open the gallery")
            output.use { out -> file.inputStream().use { input -> input.copyTo(out) } }
            if (file.length() <= 0L) throw IllegalStateException("Photo file is empty")
            uri
        } catch (_: Exception) {
            contentResolver.delete(uri, null, null)
            null
        }
    }

    private fun updateGalleryThumbnail(uri: Uri) {
        latestPhotoUri = uri
        try {
            val bitmap = if (android.os.Build.VERSION.SDK_INT >= 29) {
                contentResolver.loadThumbnail(uri, Size(240, 240), null)
            } else {
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }
            if (bitmap != null) galleryThumbnail.setImageBitmap(bitmap)
        } catch (_: Exception) { galleryThumbnail.setImageResource(android.R.drawable.ic_menu_gallery) }
    }

    private fun loadLatestPhoto() {
        try {
            val projection = arrayOf(MediaStore.Images.Media._ID)
            val selection = if (android.os.Build.VERSION.SDK_INT >= 29) "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?" else null
            val args = if (selection != null) arrayOf("Pictures/BestShotAI%") else null
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                args,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
                    val uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                    updateGalleryThumbnail(uri)
                }
            }
        } catch (_: Exception) { /* Gallery picker remains available through the thumbnail. */ }
    }

    private fun finishCapture(message: String) {
        isCapturing = false
        shutterButton.isEnabled = true
        statusText.text = message
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        if (::cameraExecutor.isInitialized) cameraExecutor.shutdown()
        objectDetector.close()
        faceDetector.close()
        imageLabeler.close()
        poseDetector.close()
        super.onDestroy()
    }

    private inner class GuideOverlay : View(this@MainActivity) {
        var gridEnabled = true
        var rollDegrees = 0f
        var toneTint = Color.TRANSPARENT
        var aiGuidesEnabled = false
        var sourceAspectRatio = 3f / 4f
        var frameRatio = 3f / 4f
        var subjectBounds: RectF? = null
        // One yellow rectangle follows the selected subject's live tracked bounding box.
        var subjectLabel: String = ""
        var readyState = false
        var boxAlpha = 0f
        private var detections: List<Rect> = emptyList()
        private var posePoints: Map<Int, PointF> = emptyMap()
        private val poseLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(80, 220, 190); strokeWidth = dp(2).toFloat(); style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        private val posePointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.FILL
        }
        private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(155, 255, 255, 255); strokeWidth = 1.5f; style = Paint.Style.STROKE
        }
        private val tintPaint = Paint()
        private val subjectPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 214, 0); strokeWidth = dp(2).toFloat(); style = Paint.Style.STROKE
        }
        private val leaderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 214, 0)
            strokeWidth = dp(1).toFloat()
            style = Paint.Style.STROKE
            pathEffect = android.graphics.DashPathEffect(floatArrayOf(dp(3).toFloat(), dp(4).toFloat()), 0f)
        }
        private val centerMarkerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 214, 0); style = Paint.Style.FILL
        }
        private val levelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            strokeWidth = dp(2).toFloat(); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
        }
        fun setDetections(value: List<Rect>) {
            detections = value.map { Rect(it) }
            invalidate()
        }
        fun setPosePoints(value: Map<Int, PointF>) {
            posePoints = value.mapValues { PointF(it.value.x, it.value.y) }
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            if (gridEnabled) {
                canvas.drawLine(w / 3f, 0f, w / 3f, h, gridPaint)
                canvas.drawLine(2f * w / 3f, 0f, 2f * w / 3f, h, gridPaint)
                canvas.drawLine(0f, h / 3f, w, h / 3f, gridPaint)
                canvas.drawLine(0f, 2f * h / 3f, w, 2f * h / 3f, gridPaint)
            }
            if (aiGuidesEnabled && subjectBounds != null) {
                levelPaint.color = Color.argb(235, 255, 214, 0)
                canvas.save()
                val levelCenterX = w * 0.26f
                val levelCenterY = h * 0.34f
                canvas.rotate(rollDegrees, levelCenterX, levelCenterY)
                canvas.drawLine(w * .15f, levelCenterY, w * .37f, levelCenterY, levelPaint)
                canvas.drawLine(levelCenterX, levelCenterY - dp(6), levelCenterX, levelCenterY + dp(6), levelPaint)
                canvas.restore()
            }

            if (aiGuidesEnabled && !readyState) {
                val bounds = subjectBounds
                if (bounds != null) {
                    // PreviewView uses FILL_CENTER. Apply the same center crop to ML Kit's
                    // image coordinates so the yellow subject rectangle overlays the right pixels.
                    val viewAspect = w / max(1f, h)
                    var left = bounds.left
                    var right = bounds.right
                    var top = bounds.top
                    var bottom = bounds.bottom
                    if (sourceAspectRatio > viewAspect) {
                        val visible = (viewAspect / sourceAspectRatio).coerceIn(0f, 1f)
                        val crop = (1f - visible) / 2f
                        left = (left - crop) / max(.001f, visible)
                        right = (right - crop) / max(.001f, visible)
                    } else {
                        val visible = (sourceAspectRatio / viewAspect).coerceIn(0f, 1f)
                        val crop = (1f - visible) / 2f
                        top = (top - crop) / max(.001f, visible)
                        bottom = (bottom - crop) / max(.001f, visible)
                    }
                    val subject = RectF(left * w, top * h, right * w, bottom * h)
                    if (subject.intersect(0f, 0f, w, h)) {
                        val targetAlpha = 1f
                        boxAlpha += (targetAlpha - boxAlpha) * 0.42f
                        if (abs(targetAlpha - boxAlpha) > 0.02f) postInvalidateOnAnimation() else boxAlpha = targetAlpha

                        // The name chip stays at the top of the preview. A dotted yellow
                        // leader connects it to the live subject box, as in the reference clips.
                        val chipAnchorX = w / 2f
                        val chipAnchorY = dp(12 + 31).toFloat()
                        val inset = min(dp(3).toFloat(), subject.width() / 2f)
                        val targetX = chipAnchorX.coerceIn(subject.left + inset, subject.right - inset)
                        val targetY = if (subject.top > chipAnchorY) subject.top else subject.centerY()
                        if (Math.hypot((targetX - chipAnchorX).toDouble(), (targetY - chipAnchorY).toDouble()) > dp(18).toDouble()) {
                            leaderPaint.alpha = (230 * boxAlpha).toInt()
                            canvas.drawLine(chipAnchorX, chipAnchorY, targetX, targetY, leaderPaint)
                        }

                        subjectPaint.alpha = (255 * boxAlpha).toInt()
                        canvas.drawRoundRect(subject, dp(8).toFloat(), dp(8).toFloat(), subjectPaint)

                        // Small center marker is tied to the detected object's live bounds.
                        val marker = dp(3).toFloat()
                        centerMarkerPaint.alpha = (210 * boxAlpha).toInt()
                        canvas.drawCircle(subject.centerX(), subject.centerY(), marker, centerMarkerPaint)
                    }
                }
            }
            if (aiGuidesEnabled && posePoints.isNotEmpty()) {
                val viewAspect = w / max(1f, h)
                val mapped = posePoints.mapValues { (_, point) ->
                    var nx = point.x / max(1f, analysisWidth.toFloat())
                    var ny = point.y / max(1f, analysisHeight.toFloat())
                    if (analysisWidth.toFloat() / max(1f, analysisHeight.toFloat()) > viewAspect) {
                        val visible = (viewAspect / (analysisWidth.toFloat() / max(1f, analysisHeight.toFloat()))).coerceIn(0f, 1f)
                        val crop = (1f - visible) / 2f
                        nx = (nx - crop) / max(.001f, visible)
                    } else {
                        val visible = ((analysisWidth.toFloat() / max(1f, analysisHeight.toFloat())) / viewAspect).coerceIn(0f, 1f)
                        val crop = (1f - visible) / 2f
                        ny = (ny - crop) / max(.001f, visible)
                    }
                    PointF(nx * w, ny * h)
                }
                val bones = listOf(
                    PoseLandmark.LEFT_SHOULDER to PoseLandmark.RIGHT_SHOULDER,
                    PoseLandmark.LEFT_SHOULDER to PoseLandmark.LEFT_ELBOW,
                    PoseLandmark.LEFT_ELBOW to PoseLandmark.LEFT_WRIST,
                    PoseLandmark.RIGHT_SHOULDER to PoseLandmark.RIGHT_ELBOW,
                    PoseLandmark.RIGHT_ELBOW to PoseLandmark.RIGHT_WRIST,
                    PoseLandmark.LEFT_SHOULDER to PoseLandmark.LEFT_HIP,
                    PoseLandmark.RIGHT_SHOULDER to PoseLandmark.RIGHT_HIP,
                    PoseLandmark.LEFT_HIP to PoseLandmark.RIGHT_HIP,
                    PoseLandmark.LEFT_HIP to PoseLandmark.LEFT_KNEE,
                    PoseLandmark.LEFT_KNEE to PoseLandmark.LEFT_ANKLE,
                    PoseLandmark.RIGHT_HIP to PoseLandmark.RIGHT_KNEE,
                    PoseLandmark.RIGHT_KNEE to PoseLandmark.RIGHT_ANKLE
                )
                bones.forEach { (a, b) ->
                    val pa = mapped[a]; val pb = mapped[b]
                    if (pa != null && pb != null) canvas.drawLine(pa.x, pa.y, pb.x, pb.y, poseLinePaint)
                }
                mapped.values.forEach { canvas.drawCircle(it.x, it.y, dp(3).toFloat(), posePointPaint) }
            }

            // Optional aspect-ratio guide. It is an overlay only; captured JPEG stays native.
            if (frameRatio > 0f) {
                val viewRatio = w / max(1f, h)
                val frameW: Float
                val frameH: Float
                if (viewRatio > frameRatio) {
                    frameH = h
                    frameW = h * frameRatio
                } else {
                    frameW = w
                    frameH = w / frameRatio
                }
                val frame = RectF((w - frameW) / 2f, (h - frameH) / 2f,
                    (w + frameW) / 2f, (h + frameH) / 2f)
                val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.argb(150, 255, 255, 255)
                    style = Paint.Style.STROKE
                    strokeWidth = dp(1).toFloat()
                }
                canvas.drawRect(frame, framePaint)
            }
            if (toneTint != Color.TRANSPARENT) {
                tintPaint.color = toneTint
                canvas.drawRect(0f, 0f, w, h, tintPaint)
            }
        }
    }
}
