# BestShot AI 4.0.0-alpha5 — Framed-style AI subject coach

## AI flow implemented from the supplied reference videos
1. The user taps the AI scan button. The camera shows `Finding your shot…`.
2. ML Kit returns real object/face/pose candidates. A candidate is ranked and must remain stable across three analysis results before it is selected.
3. One yellow rounded rectangle follows the selected subject's live bounding box. It is not a frozen target frame and there is no second white dashed detector box.
4. A small subject-name chip remains near the top center of the preview. A dotted yellow leader links the chip to the tracked subject.
5. A small yellow level guide rotates with device roll. The instruction below the preview changes according to subject size, placement, clipping and horizon angle (for example, `Isolate that … Go tighter.` or `Level the horizon.`).
6. After three consecutive acceptable analysis results, the yellow subject box and leader disappear and the top chip changes to `Subject name  Ready`. The zoom buttons remain user-controlled; the AI does not change zoom automatically.
7. Capture and the existing editor/gallery flow remain available.

## Detection and identity behavior
- Object Detection runs in STREAM_MODE with multiple objects and classification enabled. Its tracking ID is used to retain the chosen object's identity from frame to frame.
- Face detection and throttled pose detection support people/portrait framing. Pose inference is limited to scanning without a selected subject and to a selected person, to reduce load on lower-end phones.
- Image labeling starts after a real subject has been selected and may refine a generic category label when the frame supplies a relevant detail label.
- The lock tolerates short detection dropouts and does not immediately jump to a different nearby candidate.
- The scan feed is throttled to about 7 frames per second while AI scanning; secondary label/pose models run less frequently to reduce device load.

## Important model limitation
This is a functional first-pass subject coach using ML Kit's on-device general detector, image labeler, face detector and pose detector. ML Kit's built-in object categories are coarse (home goods, fashion goods, food, plants and places). The candidate ranking is a transparent heuristic using confidence, size, center proximity, category and edge clipping; it is not a trained aesthetic model or a reproduction of Framed's proprietary model. It may not identify tiny, fine-grained details such as a specific door handle unless the installed models actually detect and label them. A fine-grained custom object model and aesthetic-composition dataset are the next step for closer semantic behavior.

## Build verification
The archive and source-level checks are verified here. This environment does not include the Android SDK/Gradle, so Android compilation has not been confirmed. Run the existing GitHub Actions workflow and test tracking/overlay alignment and camera performance on the target Android phone before treating this as a release build.
