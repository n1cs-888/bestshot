# 4.0.0-alpha5

- Replaced the old frozen target frame and competing dashed detector box with one yellow box that follows the selected real subject.
- Added a fixed top subject-name chip and a dotted yellow leader connecting it to the selected subject.
- Added a small yellow roll-responsive level guide while a subject is selected.
- Added multi-frame subject confirmation and stable object identity tracking with temporary occlusion tolerance.
- Added category-aware subject naming and contextual camera instructions.
- Added a three-consecutive-frame Ready gate; when ready, the tracked box/leader disappear and the top chip displays `Ready`.
- Kept zoom under user control; no automatic zoom is applied.
- Increased AI scan analysis cadence and throttled secondary scene-label/pose inference for better responsiveness on entry-level Android devices.
- Preserved existing camera, manual controls, pose/face/object detection, editor and gallery functionality.
- Updated Android versionCode to 18 and versionName to 4.0.0-alpha5.
