# BestShot AI 4.0.0-alpha6 — Framed-style AI subject coach

This build continues the camera-coach implementation based on the two supplied Framed reference videos.

## Behaviour implemented
- Tap the AI sparkle button to scan the live scene.
- The app gathers real ML Kit object, face and pose detections and periodically runs image labeling during the scan.
- A candidate must remain stable across multiple analysis results before it is selected.
- The selected subject is identity-locked using ML Kit object tracking IDs where available, with spatial/semantic continuity for face and pose candidates.
- One yellow rounded rectangle follows the selected subject. There is no fixed yellow target rectangle and no competing white dashed box.
- A subject-name pill sits near the top of the preview with a dotted yellow leader line to the subject.
- Contextual prompts guide the user (for example, move closer, give the subject room, reframe, or level the horizon).
- A Ready state appears after multiple consecutive acceptable frames; the subject box and leader then clear, matching the reference flow.
- Zoom remains user-controlled; the AI does not silently zoom the camera.
- Existing capture, camera controls, editing, gallery, grid, face/object/pose detection remain in the source.

## Alpha 6 compile correction
- Explicitly imports `com.google.mlkit.vision.pose.Pose` and types the ML Kit pose success callback as `Pose`, resolving the unresolved `Pose`/`getAllPoseLandmarks` compiler errors shown in the supplied GitHub Actions screenshot.
- Image labeling is allowed to run during the initial scan (throttled) so labels can inform the first subject label instead of waiting until after a subject is locked.

## Model limitations
This is a first-pass on-device coach using ML Kit's general object detector/classifier, image labeler, face detector and pose detector. ML Kit's built-in object categories are coarse. Image labeling can help refine a label but does not return a bounding box for every tiny detail. Therefore it may not identify every fine-grained subject (such as a specific metal door handle or hanging light) as precisely as Framed. The ranking and readiness logic are heuristics, not a trained aesthetic model or a reproduction of Framed's proprietary AI. A fine-grained custom detection model and a trained composition model would be needed to close that gap.

## Build status
The source package structure and ZIP integrity are checked. This environment does not have Android SDK/Gradle installed, so Android compilation has not been independently verified here. Run GitHub Actions and test camera alignment/performance on the target phone before treating this as a release build.
