# BestShot AI 4.0.0-alpha5 workflow compatibility

The outer folder is intentionally still named `BestShotAI-4.0.0-alpha2` because the existing GitHub Actions command supplied in the build screenshot targets:

```bash
gradle -p extracted/BestShotAI-4.0.0-alpha2 assembleDebug
```

This is a folder-path compatibility choice only. The Android app itself is `4.0.0-alpha5`, `versionCode = 17`, in `app/build.gradle.kts`. Do not rename the outer folder unless the workflow's `-p` path is updated too.

The ZIP has been checked for archive integrity and source-level consistency. Android SDK/Gradle are not installed in the editing environment, so this package is not represented as a successfully compiled APK. GitHub Actions must confirm the build; then test the moving subject box, zoom prompts and Ready transition on the target phone.
