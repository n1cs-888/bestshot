# BestShot AI 3.0.0-rc2

- Added a composition `READY` state when a detected subject is aligned with the composition target and remains within the configured subject-size range.
- Shows `FINDING YOUR SHOT…` while scanning without a detected subject.
- Activates the AI guide state consistently when the AI action is triggered.
- Shutter remains manual; no automatic capture is performed.

## Verification
- Source edits only. Android Gradle compilation has not been run in this environment.
- Runtime behavior and camera/ML Kit alignment must be tested on the Redmi 13C.
- This is a release-candidate source package, not a verified final APK.
