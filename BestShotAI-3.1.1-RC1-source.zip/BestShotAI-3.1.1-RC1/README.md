# BestShot AI 3.1.1-RC1

Android Kotlin + CameraX application intended for Redmi 13C testing.

## Implemented in this source
- Rear CameraX preview and max-quality JPEG capture configuration.
- Three-shot burst and heuristic sharpness/exposure ranking.
- Byte-for-byte copy of the selected original JPEG to MediaStore; analysis decodes only a downsampled copy.
- ML Kit face detection, stream-mode object detection/classification, and on-device image labeling.
- Rule-based scene hints for common labels, framing hints, and approximate subject continuity using nearest-box tracking.
- Thirds grid, accelerometer roll indicator, exposure compensation controls.
- Live preview tone tint overlays and post-capture tone editor that saves a separate JPEG copy.
- Auto/manual framing toggle and tracking toggle.

## Known limits (important)
- ML Kit's default image-labeling model and object detector do not guarantee recognition of every animal, building, object, or landscape. A dedicated custom-trained model and model evaluation dataset are required for comprehensive recognition.
- Angle, distance, and composition recommendations are heuristics, not a trained photography expert model or calibrated metric distance measurement.
- Subject continuity is approximate bounding-box matching, not robust multi-object identity tracking.
- Preview tone is an overlay; it does not change the camera sensor output. Post-edit applies a color matrix and creates a separate JPEG copy.
- Overlay box alignment is approximate due to CameraX crop/rotation/aspect-ratio transforms and must be calibrated on the target device.
- Build and on-device performance must be verified using GitHub Actions and a Redmi 13C.


## Camera UI refresh
The camera screen now follows the supplied visual direction: black full-screen camera canvas, compact top toolbar, floating subject-recognition chip, thirds grid and level guide, bottom shooting hint, zoom presets, gallery thumbnail, central shutter, and yellow AI-assist button. Some toolbar glyphs are text-based placeholders and should be replaced with polished vector icons during UI refinement.


## UX corrective update
- Subject chip is now updated from the latest ML Kit labels/detections instead of remaining permanently on SEARCHING.
- AI star now explicitly requests a fresh rule-based framing recommendation and keeps the guide overlay enabled.
- Composition/framing ratios now use the analysis frame dimensions rather than preview pixel dimensions.
- Added a dedicated Color Studio selector with Natural, Warm, Cool, Film, Vivid, and Mono choices; selecting a photo applies the chosen tone and saves a separate JPEG copy.
- The preview tone remains a lightweight overlay simulation, not sensor-level live color grading. Recommendations remain heuristic and depend on the ML Kit results.


## Camera UX update 2.1.0
- Applies safe system-bar insets so the top camera controls remain tappable on edge-to-edge Android versions.
- Replaces the bottom-left gallery glyph with a recent-photo thumbnail; tapping it opens a photo preview. If no BestShot photo exists yet, it opens the system photo picker.
- Adds a dedicated Color Studio panel with selectable tone presets and a photo-edit flow that saves a separate copy.
- Adds directional arrow guidance derived from the detected subject's normalized position when the AI star is tapped.
- Keeps the original captured JPEG unchanged and saves edited images separately.


## BestShot AI 2.2 camera guidance update

- AI scan is started from the sparkle button.
- A persistent yellow target frame is drawn in the viewfinder. It never turns green and never triggers automatic capture.
- Subject position is compared with the recommended composition target. The app displays one camera movement instruction and a dashed guide line.
- The shutter remains fully manual.
- Version 2.2.0 uses JPEG capture quality 100; RAW/DNG is not enabled.

Note: object/scene recognition is on-device ML Kit detection and image labeling. Composition advice is a local heuristic, not a generative photography model.


## BestShot AI 2.2.2 - AI Direction correction
- Draws a yellow frame around the detected subject only after a subject is detected.
- Recalculates movement advice from the tracked subject position on each analysis result.
- Adds a dashed connector from the subject to the composition anchor and a visible movement arrow.
- Uses object detector classification labels alongside image labels.
- Accounts for portrait rotation and PreviewView FILL_CENTER crop when mapping detection boxes.
- Keeps the yellow guide yellow; no green READY state and no automatic shutter.
- Keeps original JPEG capture flow and manual shutter.

## 2.3.0 source changes
- Added a real camera torch toggle when the selected camera exposes a flash unit.
- Added aspect-ratio composition guides (3:4, 4:5, 1:1, 9:16); these are viewfinder guides and do not crop the original JPEG.
- Separated the yellow composition target frame from the detected subject position in the guide overlay.
- The original JPEG capture path remains byte-for-byte copied to MediaStore after burst scoring.

Build and device validation are still required through GitHub Actions and a Redmi 13C.


## Status versi 2.4.0-dev

Perubahan pada checkpoint ini: tombol shutter sekarang mengambil **satu foto per tekanan** (tidak lagi menjalankan burst tiga foto dan memilih otomatis), dan pilihan rasio memperbarui label serta panduan framing. Pilihan rasio masih berupa panduan overlay; hasil JPEG belum dipotong ke rasio pilihan. Color Studio juga belum menjadi editor Looks/Adjust/Effects/Frames penuh. Versi ini adalah checkpoint perbaikan, bukan rilis final teruji. Build dan pengujian perangkat wajib dilakukan sebelum dipakai sebagai APK final.


## Catatan pemeriksaan source 2.4.1-dev
- Memperbaiki referensi tombol rasio yang sebelumnya tertimpa variabel lokal `ratio` dan berpotensi menggagalkan kompilasi Kotlin.
- Ini adalah hotfix source, bukan klaim aplikasi final.
- Rasio masih berupa panduan overlay; hasil JPEG belum dipotong mengikuti rasio pilihan.
- Color Studio belum memiliki rangkaian Looks / Adjust / Effects / Frames lengkap.
- Build Gradle dan pengujian fisik Redmi 13C belum dilakukan pada lingkungan ini.

## 3.0.0 Release Candidate notes

This source now uses a CameraX `UseCaseGroup` and shared `ViewPort` so the selected 3:4, 4:5, 1:1, or 9:16 ratio is applied to the capture pipeline as well as the viewfinder. Color Studio includes Looks, Exposure, Contrast, Saturation, Highlights, Shadows, Grain, Vignette, and frame choices. The detector outline is white and dashed; the composition target remains yellow.

**Release status:** source package only. Android compilation and Redmi 13C runtime tests have not been performed in this environment. Run the GitHub Actions workflow and test every item in `RELEASE-TEST-CHECKLIST.md` before distributing an APK as final.


## 3.1.1-RC1 reliability pass
- ML Kit completion counting is now thread-safe.
- READY requires an explicit AI scan and three consecutive qualifying analysis frames; it also checks subject size, target alignment, and horizon level.
- Photo preview uses downsampled decoding to reduce memory pressure.
- JPEG export now checks the encoder result before reporting success.
- Capture copy checks that the source JPEG is non-empty.
- Editor decoding is capped at approximately 8 MP for memory safety on mid-range devices.

This remains a release candidate. The source-level checks do not replace an Android Gradle build or physical-device validation.
