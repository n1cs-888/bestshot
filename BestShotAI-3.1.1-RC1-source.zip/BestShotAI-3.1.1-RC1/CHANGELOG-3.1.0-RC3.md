# BestShot AI 3.1.0-RC3

## UI/editor rebuild pass
- Replaced the Color Studio AlertDialog with a full-screen dark editor surface.
- Added the reference tab structure: Looks, Adjust, Effects, Frames.
- Added five named looks: Lean, Harbor, Dusk, Press, Albu.
- Added adjustment sliders for Exposure, Contrast, Highlights, Shadows, Saturation.
- Added Grain and Vignette controls and frame choices.
- Added edit-state history for Undo and Redo.
- Added Delete confirmation and Save as a separate edited JPEG.
- Editor preview loads a downsampled image to reduce memory use on mid-range devices.

## Important limitations
- This is a source candidate, not a verified final APK.
- The preview applies live tone/adjustment color filtering; grain, vignette and frame are rendered during Save, with the frame preview represented as an overlay.
- Gradle compilation and Redmi 13C runtime tests still need to be run in GitHub Actions/on device.
