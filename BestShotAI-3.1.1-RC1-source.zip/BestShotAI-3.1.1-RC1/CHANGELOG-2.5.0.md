# BestShot AI 2.5.0-dev checkpoint

## Source changes
- Expanded Color Studio with Looks presets, Exposure/Brightness, Contrast, Saturation, Vignette, Grain, and Frames controls.
- Added photo sharing through Android Sharesheet.
- Added photo deletion with a confirmation dialog.
- Edited images are saved as new JPEG files; the selected original URI is not overwritten.
- Bumped Android version to 2.5.0-dev / versionCode 7.

## Not yet verified / remaining
- The selected aspect ratio still affects the framing overlay only; captured JPEG is not cropped to the selected ratio.
- No Gradle build was run in this environment because Android SDK/Gradle tooling is unavailable.
- Camera, ML Kit tracking, permissions, editor performance, and sharing/deletion must be tested on a Redmi 13C.
- Grain and full-resolution editing may be memory-intensive on large source images; the editor decodes a downsampled copy (max long edge about 3000 px).

This is a development checkpoint, not a verified final APK.
