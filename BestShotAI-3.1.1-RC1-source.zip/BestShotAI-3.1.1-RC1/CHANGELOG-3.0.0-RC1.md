# BestShot AI 3.0.0-rc1

## Changes in this release candidate
- CameraX `UseCaseGroup` now shares a `ViewPort` across preview, image capture, and analysis.
- Aspect-ratio selection (3:4, 4:5, 1:1, 9:16) is applied to the camera use-case viewport rather than only drawing a guide overlay.
- Changing aspect ratio rebinds the camera use cases and updates the image-capture target rotation.
- AI composition overlay now draws a separate white dashed detector rectangle and a yellow composition target.
- Color Studio adds Highlights and Shadows controls, processes pixel adjustments in small bands to reduce temporary memory use, and keeps the original photo untouched.
- Removed unused burst-scoring and single-tone helper code.

## Verification status
- ZIP structure and source-level checks: performed before delivery.
- Android Gradle compilation: not run in this environment (Android SDK/Gradle unavailable).
- Redmi 13C runtime validation: not performed. This release candidate must be built with GitHub Actions and tested on the device before being called a verified final release.
