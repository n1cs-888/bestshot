# BestShot AI 3.1.1-RC1

## Reliability and camera guidance fixes
- Made ML Kit frame-completion accounting thread-safe with an atomic counter. This prevents concurrent task callbacks from losing a completion and leaving the analyzer busy.
- `READY` now requires the AI scan to have been explicitly started, a detected subject inside the framing bounds, acceptable subject size, alignment with the composition target, a level horizon, and three consecutive qualifying analysis frames.
- Reset the READY stability counter when scanning starts or framing conditions become invalid.
- Added downsampled photo preview decoding to avoid loading full-resolution images into the preview dialog.
- Added a JPEG encoding success check before reporting edited images as saved.
- Added a non-empty source-file check when copying captured JPEGs to MediaStore.
- Reduced editor decode size to a maximum of approximately 8 megapixels to balance export quality and memory use on mid-range devices.
- Improved the live editor preview response for Highlights and Shadows adjustments (the preview is an approximation; the export applies the pixel-level adjustment).

## Validation status
- Source-level delimiter and structure checks passed.
- Android Gradle compilation was not run because this environment does not contain Gradle, an Android SDK, or a Gradle wrapper.
- Physical camera, ML Kit performance, MediaStore save/delete, and Redmi 13C tests remain required.
