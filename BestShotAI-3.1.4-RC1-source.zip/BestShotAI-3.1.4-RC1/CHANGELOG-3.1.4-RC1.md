# BestShot AI 3.1.4-RC1

## Yellow box / Ready behaviour (matches the reference recording)
- Target moved to the screen centre ("+" on the level line); dashed connector ends exactly on the "+".
- Box + dashed line + "+" fade out when READY and fade back in if the subject drifts away.
- READY: 2 stable frames, 10% tolerance (16% to stay Ready), tilt < 4°. Level line is yellow under 4°.
- Fallback subject (saliency) has hysteresis toward the previous subject position.

## Validation status
- Not compiled here (no Gradle / Android SDK). Run the GitHub Actions build and test on a Redmi 13C.
