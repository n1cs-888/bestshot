package com.bestshot.ai

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.*
import android.net.Uri
import android.util.Size
import android.util.Rational
import android.widget.ImageView
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.content.Intent
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.core.ViewPort
import androidx.camera.core.Camera as CameraXCamera
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.label.ImageLabel
import com.google.mlkit.vision.label.ImageLabeler
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.ObjectDetector
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity(), SensorEventListener {
    private lateinit var previewView: PreviewView
    private lateinit var overlay: GuideOverlay
    private lateinit var statusText: TextView
    private lateinit var shutterButton: Button
    private lateinit var galleryThumbnail: ImageView
    private var latestPhotoUri: Uri? = null
    private var selectedPhotoUri: Uri? = null
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var sensorManager: SensorManager
    private var imageCapture: ImageCapture? = null
    private var previewUseCase: Preview? = null
    private var analysisUseCase: ImageAnalysis? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var isCapturing = false
    @Volatile private var analysisBusy = false
    private var readyFrameCount = 0
    private var lastAnalysisAt = 0L
    private var boundCamera: CameraXCamera? = null
    private var manualFraming = false
    private var trackingEnabled = true
    private var lastTrackedBox: RectF? = null
    private var latestLabels: List<String> = emptyList()
    private var latestSubject = "Finding your shot…"
    private lateinit var subjectChip: TextView
    private lateinit var ratioButton: TextView
    private var analysisWidth = 640
    private var analysisHeight = 480

    private var currentTone = Tone.NATURAL
    private var editBrightness = 0f
    private var editContrast = 1f
    private var editSaturation = 1f
    private var editHighlights = 0f
    private var editShadows = 0f
    private var editVignette = 0f
    private var editGrain = 0f
    private var editFrame = 0
    private var exposureSteps = 0
    private var zoomRatio = 1f
    private var selectedFrameRatio = 3f / 4f
    private var selectedFrameRatioLabel = "3:4"
    private var torchEnabled = false
    private var aiGuideEnabled = false
    private var rollDegrees = 0f
    private var horizonAdvice = "Level"
    private var guideDx = 0f
    private var guideDy = 0f
    private var guideMessage = "Point your camera and tap the ✦ button"
    private var aiScanRequested = false
    private var compositionReady = false
    private var scanFinished = false
    @Volatile private var emptyDetectionFrames = 0
    private var autoZoomApplied = false
    private lateinit var aiButton: Button
    private val zoomButtons = mutableListOf<Button>()
    private val zoomPresets = mutableListOf(.5f, 1f, 2f, 5f)
    private var subjectCenterX = .5f
    private var subjectCenterY = .5f
    private var targetCenterX = .5f
    private var targetCenterY = .5f

    private val objectDetector: ObjectDetector by lazy {
        ObjectDetection.getClient(
            ObjectDetectorOptions.Builder()
                .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
                .enableClassification()
                .enableMultipleObjects()
                .build()
        )
    }
    private val faceDetector: FaceDetector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .build()
        )
    }
    // ML Kit's on-device base image-labeling model expands scene labels beyond object detector categories.
    private val imageLabeler: ImageLabeler by lazy {
        ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
    }

    private enum class Tone(val title: String, val tint: Int, val matrix: FloatArray) {
        NATURAL("Natural", Color.TRANSPARENT, floatArrayOf(
            1f,0f,0f,0f,0f, 0f,1f,0f,0f,0f, 0f,0f,1f,0f,0f, 0f,0f,0f,1f,0f
        )),
        WARM("Warm", Color.argb(22,255,155,70), floatArrayOf(
            1.08f,0f,0f,0f,5f, 0f,1.01f,0f,0f,1f, 0f,0f,0.91f,0f,-3f, 0f,0f,0f,1f,0f
        )),
        COOL("Cool", Color.argb(20,70,145,255), floatArrayOf(
            0.94f,0f,0f,0f,-2f, 0f,1.01f,0f,0f,1f, 0f,0f,1.10f,0f,4f, 0f,0f,0f,1f,0f
        )),
        FILM("Film", Color.argb(18,180,145,95), floatArrayOf(
            1.04f,0f,0f,0f,3f, 0f,1.00f,0f,0f,0f, 0f,0f,0.91f,0f,2f, 0f,0f,0f,1f,0f
        )),
        VIVID("Vivid", Color.argb(12,255,220,80), floatArrayOf(
            1.18f,0f,0f,0f,-8f, 0f,1.12f,0f,0f,-5f, 0f,0f,1.16f,0f,-7f, 0f,0f,0f,1f,0f
        )),
        MONO("Mono", Color.TRANSPARENT, floatArrayOf(
            0.30f,0.59f,0.11f,0f,0f, 0.30f,0.59f,0.11f,0f,0f, 0.30f,0.59f,0.11f,0f,0f, 0f,0f,0f,1f,0f
        ))
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera() else {
            statusText.text = "Camera permission is required."
            shutterButton.isEnabled = false
        }
    }

    private val photoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@registerForActivityResult
        selectedPhotoUri = uri
        showPhotoPreview(uri, allowEdit = true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        buildInterface()
        loadLatestPhoto()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildInterface() {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)

        // Top camera toolbar inspired by the supplied reference.
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        ratioButton = cameraLabel("▢   $selectedFrameRatioLabel  ⌄", 17f)
        top.addView(ratioButton, LinearLayout.LayoutParams(0, dp(48), 1f).also {
            ratioButton.setOnClickListener { showAspectRatioOptions() }
        })
        top.addView(cameraButton("ϟ") {
            val camera = boundCamera
            if (camera == null || !camera.cameraInfo.hasFlashUnit()) {
                statusText.text = "Flash is not available on this camera."
            } else {
                torchEnabled = !torchEnabled
                camera.cameraControl.enableTorch(torchEnabled)
                statusText.text = if (torchEnabled) "Flash on" else "Flash off"
            }
        })
        top.addView(cameraButton("◉") { openColorStudio() })
        top.addView(cameraButton("•••") { showCameraOptions() })
        root.addView(top, LinearLayout.LayoutParams(-1, dp(60)))

        val previewFrame = FrameLayout(this)
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        overlay = GuideOverlay().apply { aiGuidesEnabled = aiGuideEnabled }
        previewFrame.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        previewFrame.addView(overlay, FrameLayout.LayoutParams(-1, -1))

        subjectChip = TextView(this).apply {
            text = ""
            visibility = View.INVISIBLE
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.argb(220, 22, 22, 22))
                cornerRadius = dp(28).toFloat()
            }
        }
        val chipParams = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(20)
        }
        previewFrame.addView(subjectChip, chipParams)
        root.addView(previewFrame, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(Color.BLACK)
        }
        statusText = TextView(this).apply {
            text = "Point your camera and tap the ✦ button"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            maxLines = 2
            setPadding(dp(4), dp(3), dp(4), dp(12))
        }
        bottom.addView(statusText, LinearLayout.LayoutParams(-1, dp(42)))

        val zoomRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
        }
        zoomPresets.indices.forEach { index ->
            val b = cameraButton("") { setZoom(zoomPresets[index]) }
            b.textSize = 15f
            zoomButtons.add(b)
            zoomRow.addView(b, LinearLayout.LayoutParams(dp(62), dp(62)).apply {
                marginStart = dp(7); marginEnd = dp(7)
            })
        }
        refreshZoomButtons()
        bottom.addView(zoomRow, LinearLayout.LayoutParams(-1, dp(68)))

        val actionRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(8), dp(12), dp(2))
        }
        galleryThumbnail = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackground(roundBackground(Color.rgb(45, 45, 45)))
            setImageResource(android.R.drawable.ic_menu_gallery)
            contentDescription = "Latest photo. Tap to open"
            setOnClickListener {
                val uri = latestPhotoUri
                if (uri != null) showPhotoPreview(uri, allowEdit = true)
                else photoPicker.launch("image/*")
            }
        }
        actionRow.addView(galleryThumbnail, LinearLayout.LayoutParams(dp(68), dp(68)))
        val shutterWrap = FrameLayout(this)
        shutterButton = Button(this).apply {
            text = "●"
            textSize = 36f
            setTextColor(Color.BLACK)
            isAllCaps = false
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.WHITE)
                setStroke(dp(5), Color.WHITE)
            }
            setOnClickListener { capturePhoto() }
        }
        shutterWrap.addView(shutterButton, FrameLayout.LayoutParams(dp(84), dp(84), Gravity.CENTER))
        actionRow.addView(shutterWrap, LinearLayout.LayoutParams(0, dp(92), 1f))
        aiButton = cameraButton("✦") { onAiButtonClicked() }.apply {
            textSize = 30f
            setTextColor(Color.rgb(255, 220, 0))
            background = roundBackground(Color.rgb(48, 40, 0))
        }
        actionRow.addView(aiButton, LinearLayout.LayoutParams(dp(68), dp(68)))
        bottom.addView(actionRow, LinearLayout.LayoutParams(-1, dp(96)))
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(246)))
        setContentView(root)

        toneButton = cameraButton("Tone") { cycleTone(toneButton) }
        statusText.text = "Point your camera and tap the ✦ button"
    }

    private lateinit var toneButton: Button

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun cameraLabel(textValue: String, size: Float) = TextView(this).apply {
        text = textValue
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun cameraButton(label: String, action: (View) -> Unit) =
        Button(this).apply {
            text = label
            textSize = 18f
            isAllCaps = false
            minWidth = 0
            minHeight = 0
            setPadding(dp(5), 0, dp(5), 0)
            setTextColor(Color.WHITE)
            background = roundBackground(Color.TRANSPARENT)
            setOnClickListener(action)
        }

    private fun roundBackground(color: Int) =
        android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            setColor(color)
            cornerRadius = dp(40).toFloat()
        }

    private fun setZoom(requested: Float) {
        val camera = boundCamera ?: return
        val state = camera.cameraInfo.zoomState.value ?: return
        zoomRatio = requested.coerceIn(state.minZoomRatio, state.maxZoomRatio)
        camera.cameraControl.setZoomRatio(zoomRatio)
        refreshZoomButtons()
    }

    private fun zoomLabel(z: Float): String = when {
        z == .5f -> ".5x"
        z % 1f == 0f -> "${z.toInt()}x"
        else -> "${"%.1f".format(java.util.Locale.US, z)}×"
    }

    private fun refreshZoomButtons() {
        if (zoomButtons.isEmpty()) return
        val state = boundCamera?.cameraInfo?.zoomState?.value
        var active = 0
        var best = Float.MAX_VALUE
        zoomPresets.forEachIndexed { i, z ->
            val effective = if (state != null) z.coerceIn(state.minZoomRatio, state.maxZoomRatio) else z
            val d = abs(effective - zoomRatio)
            if (d <= best) { best = d; active = i }   // ties go to the higher preset
        }
        zoomButtons.forEachIndexed { i, b ->
            val on = i == active
            b.text = zoomLabel(zoomPresets[i])
            b.setTextColor(if (on) Color.rgb(255, 214, 0) else Color.WHITE)
            b.background = roundBackground(if (on) Color.rgb(48, 40, 0) else Color.rgb(25, 25, 25))
        }
    }

    private fun resetZoomPresets() {
        zoomPresets.clear()
        zoomPresets.addAll(listOf(.5f, 1f, 2f, 5f))
    }

    /** AI zoom suggestion: the 2x / 5x slot becomes the recommended value (e.g. "2.5×"). */
    private fun applyAutoZoom(target: Float) {
        val idx = if (abs(zoomPresets[2] - target) <= abs(zoomPresets[3] - target)) 2 else 3
        zoomPresets[idx] = target
        setZoom(target)
    }

    private fun showAspectRatioOptions() {
        val choices = arrayOf("3:4 (Photo)", "4:5 (Portrait)", "1:1 (Square)", "9:16 (Story)")
        android.app.AlertDialog.Builder(this)
            .setTitle("Aspect ratio")
            .setItems(choices) { _, which ->
                // CameraX ViewPort applies this aspect ratio consistently to preview and
                // ImageCapture, so the saved JPEG is cropped to the selected framing.
                val ratio = choices[which].substringBefore(" ")
                selectedFrameRatioLabel = ratio
                selectedFrameRatio = when (ratio) {
                    "4:5" -> 4f / 5f
                    "1:1" -> 1f
                    "9:16" -> 9f / 16f
                    else -> 3f / 4f
                }
                overlay.frameRatio = selectedFrameRatio
                ratioButton.text = "▢   $selectedFrameRatioLabel  ⌄"
                overlay.invalidate()
                statusText.text = "Applying ratio $ratio…"
                rebindCameraForSelectedRatio()
            }.show()
    }

    private fun showCameraOptions() {
        val options = arrayOf("Grid ON/OFF", "Auto / Manual framing", "Subject tracking ON/OFF", "Color tone")
        android.app.AlertDialog.Builder(this)
            .setTitle("BestShot controls")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> { overlay.gridEnabled = !overlay.gridEnabled; overlay.invalidate(); statusText.text = "Grid ${if (overlay.gridEnabled) "ON" else "OFF"}" }
                    1 -> { manualFraming = !manualFraming; updateAdvice() }
                    2 -> { trackingEnabled = !trackingEnabled; if (!trackingEnabled) lastTrackedBox = null; updateAdvice() }
                    3 -> openColorStudio()
                }
            }.show()
    }

    private fun controlButton(label: String, action: (View) -> Unit) =
        Button(this).apply {
            text = label
            textSize = 10f
            isAllCaps = false
            minWidth = 0
            setPadding(2, 0, 2, 0)
            setOnClickListener(action)
        }

    private fun cycleTone(button: Button) {
        currentTone = Tone.values()[(currentTone.ordinal + 1) % Tone.values().size]
        overlay.toneTint = currentTone.tint
        overlay.invalidate()
        button.text = "Tone ${currentTone.title}"
        updateAdvice()
    }

    private fun adjustExposure(direction: Int) {
        val camera = boundCamera ?: return
        val state = camera.cameraInfo.exposureState
        exposureSteps = (state.exposureCompensationIndex + direction).coerceIn(
            state.exposureCompensationRange.lower, state.exposureCompensationRange.upper
        )
        camera.cameraControl.setExposureCompensationIndex(exposureSteps)
        updateAdvice("Exposure index $exposureSteps")
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider
                val preview = Preview.Builder()
                    .setTargetRotation(previewView.display?.rotation ?: windowManager.defaultDisplay.rotation)
                    .build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setJpegQuality(100)
                    .setTargetRotation(previewView.display?.rotation ?: windowManager.defaultDisplay.rotation)
                    .build()
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setTargetResolution(Size(640, 480))
                    .build()
                analysis.setAnalyzer(cameraExecutor, ::analyzeFrame)
                previewUseCase = preview
                imageCapture = capture
                analysisUseCase = analysis
                bindCameraGroup()
                statusText.text = "Point your camera and tap the ✦ button"
            } catch (e: Exception) {
                statusText.text = "Camera failed to open: ${e.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun rebindCameraForSelectedRatio() {
        previewView.post {
            try {
                bindCameraGroup()
                statusText.text = "Ratio $selectedFrameRatioLabel applied to preview and photo."
            } catch (e: Exception) {
                statusText.text = "Could not apply ratio: ${e.localizedMessage}"
            }
        }
    }

    private fun bindCameraGroup() {
        val provider = cameraProvider ?: return
        val preview = previewUseCase ?: return
        val capture = imageCapture ?: return
        val analysis = analysisUseCase ?: return
        val rotation = previewView.display?.rotation ?: windowManager.defaultDisplay.rotation
        val ratioWidth = when (selectedFrameRatioLabel) {
            "4:5" -> 4
            "1:1" -> 1
            "9:16" -> 9
            else -> 3
        }
        val ratioHeight = when (selectedFrameRatioLabel) {
            "4:5" -> 5
            "1:1" -> 1
            "9:16" -> 16
            else -> 4
        }
        val viewport = ViewPort.Builder(Rational(ratioWidth, ratioHeight), rotation)
            .setScaleType(ViewPort.FILL_CENTER)
            .build()
        val group = UseCaseGroup.Builder()
            .setViewPort(viewport)
            .addUseCase(preview)
            .addUseCase(capture)
            .addUseCase(analysis)
            .build()
        preview.targetRotation = rotation
        capture.targetRotation = rotation
        analysis.targetRotation = rotation
        provider.unbindAll()
        boundCamera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, group)
    }

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    private fun analyzeFrame(proxy: ImageProxy) {
        val now = System.currentTimeMillis()
        if (analysisBusy || now - lastAnalysisAt < 450L) {
            proxy.close()
            return
        }
        val media = proxy.image
        if (media == null) {
            proxy.close()
            return
        }
        analysisBusy = true
        lastAnalysisAt = now
        val rotationDegrees = proxy.imageInfo.rotationDegrees
        val rotatedWidth = if (rotationDegrees == 90 || rotationDegrees == 270) proxy.height else proxy.width
        val rotatedHeight = if (rotationDegrees == 90 || rotationDegrees == 270) proxy.width else proxy.height
        // ML Kit often returns no object box (walls, doors, small details). While a scan is
        // active, also find the most visually distinct region so the AI always has a subject.
        val fallbackRect: Rect? = if (aiScanRequested) {
            salientRect(proxy, rotationDegrees, rotatedWidth, rotatedHeight)
        } else null
        val input = InputImage.fromMediaImage(media, rotationDegrees)

        // All three tasks read the same frame. Close ImageProxy only after all complete.
        val objectTask = objectDetector.process(input)
        val faceTask = faceDetector.process(input)
        val labelTask = imageLabeler.process(input)
        val completed = java.util.concurrent.atomic.AtomicInteger(0)
        fun taskFinished() {
            // ML Kit listeners may complete on different threads. Atomic counting prevents
            // a lost increment that would leave ImageAnalysis permanently busy.
            if (completed.incrementAndGet() == 3) {
                proxy.close()
                analysisBusy = false
            }
        }

        var objectRects = emptyList<Rect>()
        var objectNames = emptyList<Pair<String, Float>>()
        var faceRects = emptyList<Rect>()
        var labels = emptyList<ImageLabel>()
        objectTask.addOnSuccessListener { detected ->
            objectRects = detected.map { item -> Rect(item.boundingBox) }
            objectNames = detected.flatMap { item ->
                item.labels.map { label -> label.text to label.confidence }
            }
        }.addOnCompleteListener { taskFinished() }
        faceTask.addOnSuccessListener { faceRects = it.map { item -> Rect(item.boundingBox) } }
            .addOnCompleteListener { taskFinished() }
        labelTask.addOnSuccessListener { labels = it }
            .addOnCompleteListener { taskFinished() }

        // Publish once the three asynchronous results are complete.
        val publish = {
            var boxes = faceRects + objectRects
            if (boxes.isNotEmpty() || !aiScanRequested) {
                emptyDetectionFrames = 0
            } else if (fallbackRect != null) {
                emptyDetectionFrames++
                if (emptyDetectionFrames >= 4) boxes = listOf(fallbackRect)   // ~2 s of "Finding your shot…"
            }
            analysisWidth = rotatedWidth
            analysisHeight = rotatedHeight
            val bestBox = selectTrackedBox(boxes, analysisWidth, analysisHeight)
            val labelNames = (objectNames + labels.map { it.text to it.confidence })
                .filter { it.second >= .35f }
                .sortedByDescending { it.second }
                .map { it.first }
                .distinct()
                .take(5)
            latestLabels = labelNames
            latestSubject = when {
                faceRects.isNotEmpty() -> "Person detected"
                labelNames.isNotEmpty() -> "Scene: ${labelNames.take(2).joinToString(", ")}"
                objectRects.isNotEmpty() -> "Object detected"
                else -> "No dominant subject yet"
            }
            runOnUiThread {
                overlay.setDetections(if (trackingEnabled) listOfNotNull(bestBox) else boxes)
                updateAdvice(fromAnalysis = true)
            }
        }
        // A small completion barrier avoids reading partial detector results.
        objectTask.addOnCompleteListener {
            faceTask.addOnCompleteListener {
                labelTask.addOnCompleteListener { publish() }
            }
        }
    }

    /**
     * Cheap saliency: samples the luminance plane on a 16x16 grid and scores each cell by how much it
     * differs from the frame average plus its local edge energy. Returns a box (in rotated frame
     * coordinates) around the strongest cluster, or a centered box when the scene is nearly uniform.
     */
    private fun salientRect(proxy: ImageProxy, rotation: Int, outW: Int, outH: Int): Rect? {
        return try {
            val plane = proxy.planes[0]
            val buf = plane.buffer
            val rowStride = plane.rowStride
            val pixStride = plane.pixelStride
            val w = proxy.width
            val h = proxy.height
            val gx = 16
            val gy = 16
            val sumC = FloatArray(gx * gy)
            val gradC = FloatArray(gx * gy)
            val cnt = IntArray(gx * gy)
            val step = 4
            var total = 0f
            var n = 0
            var y = 0
            while (y < h - step) {
                var x = 0
                while (x < w - step) {
                    val idx = y * rowStride + x * pixStride
                    val v = (buf.get(idx).toInt() and 0xFF).toFloat()
                    val vr = (buf.get(idx + step * pixStride).toInt() and 0xFF).toFloat()
                    val vd = (buf.get(idx + step * rowStride).toInt() and 0xFF).toFloat()
                    val c = (y * gy / h) * gx + (x * gx / w)
                    sumC[c] += v
                    gradC[c] += abs(v - vr) + abs(v - vd)
                    cnt[c]++
                    total += v
                    n++
                    x += step
                }
                y += step
            }
            if (n == 0) return null
            val mean = total / n
            val score = FloatArray(gx * gy)
            fun toUpright(x: Float, y: Float): Pair<Float, Float> = when (rotation) {
                90 -> (1f - y) to x
                180 -> (1f - x) to (1f - y)
                270 -> y to (1f - x)
                else -> x to y
            }
            val prev = lastTrackedBox
            val prevCx = if (prev != null) prev.centerX() / max(1, outW) else -1f
            val prevCy = if (prev != null) prev.centerY() / max(1, outH) else -1f
            var best = 0
            for (i in score.indices) {
                if (cnt[i] == 0) continue
                score[i] = abs(sumC[i] / cnt[i] - mean) + 1.5f * gradC[i] / cnt[i]
                // Mild centre bias: people frame the subject near the middle.
                val cx = (i % gx + .5f) / gx - .5f
                val cy = (i / gx + .5f) / gy - .5f
                score[i] *= 1f - .6f * (cx * cx + cy * cy)
                if (prevCx >= 0f) {
                    // Hysteresis: prefer cells near the subject chosen on the previous frame.
                    val up = toUpright((i % gx + .5f) / gx, (i / gx + .5f) / gy)
                    val d2 = (up.first - prevCx) * (up.first - prevCx) + (up.second - prevCy) * (up.second - prevCy)
                    score[i] *= 1f + .8f / (1f + 25f * d2)
                }
                if (score[i] > score[best]) best = i
            }
            var l: Float
            var t: Float
            var r: Float
            var b: Float
            if (score[best] < 6f) {
                l = .3f; t = .3f; r = .7f; b = .7f
            } else {
                val bx = best % gx
                val by = best / gx
                var minX = bx; var maxX = bx; var minY = by; var maxY = by
                for (yy in max(0, by - 3)..min(gy - 1, by + 3)) {
                    for (xx in max(0, bx - 3)..min(gx - 1, bx + 3)) {
                        if (score[yy * gx + xx] >= score[best] * .6f) {
                            minX = min(minX, xx); maxX = max(maxX, xx)
                            minY = min(minY, yy); maxY = max(maxY, yy)
                        }
                    }
                }
                // Keep the box between 3 and 8 cells wide so it is neither a dot nor the whole frame.
                fun fit(lo: Int, hi: Int, limit: Int): Pair<Float, Float> {
                    var a = lo; var z = hi + 1
                    while (z - a < 3) { if (a > 0) a--; if (z - a < 3 && z < limit) z++ }
                    while (z - a > 8) { a++; z-- }
                    return a.toFloat() / limit to z.toFloat() / limit
                }
                val fx = fit(minX, maxX, gx)
                val fy = fit(minY, maxY, gy)
                l = fx.first; r = fx.second; t = fy.first; b = fy.second
            }
            // Sensor orientation -> rotated (upright) frame.
            val rl: Float; val rt: Float; val rr: Float; val rb: Float
            when (rotation) {
                90 -> { rl = 1f - b; rr = 1f - t; rt = l; rb = r }
                180 -> { rl = 1f - r; rr = 1f - l; rt = 1f - b; rb = 1f - t }
                270 -> { rl = t; rr = b; rt = 1f - r; rb = 1f - l }
                else -> { rl = l; rr = r; rt = t; rb = b }
            }
            Rect((rl * outW).toInt(), (rt * outH).toInt(), (rr * outW).toInt(), (rb * outH).toInt())
        } catch (_: Exception) {
            null
        }
    }

    private fun selectTrackedBox(boxes: List<Rect>, imageWidth: Int, imageHeight: Int): Rect? {
        if (boxes.isEmpty()) {
            lastTrackedBox = null
            return null
        }
        val candidates = boxes.map { RectF(it) }
        val previous = lastTrackedBox
        val chosen = if (!trackingEnabled || previous == null) {
            candidates.maxByOrNull { it.width() * it.height() }!!
        } else {
            candidates.minByOrNull { centerDistance(previous, it, imageWidth, imageHeight) }!!
        }
        lastTrackedBox = if (previous != null && trackingEnabled) {
            RectF(
                previous.left * .35f + chosen.left * .65f,
                previous.top * .35f + chosen.top * .65f,
                previous.right * .35f + chosen.right * .65f,
                previous.bottom * .35f + chosen.bottom * .65f
            )
        } else chosen
        return Rect(
            lastTrackedBox!!.left.toInt(), lastTrackedBox!!.top.toInt(),
            lastTrackedBox!!.right.toInt(), lastTrackedBox!!.bottom.toInt()
        )
    }

    private fun centerDistance(a: RectF, b: RectF, w: Int, h: Int): Float {
        val dx = (a.centerX() - b.centerX()) / max(1, w).toFloat()
        val dy = (a.centerY() - b.centerY()) / max(1, h).toFloat()
        return dx * dx + dy * dy
    }

    private fun onAiButtonClicked() {
        when {
            !aiScanRequested -> triggerAiRecommendation()                       // ✦ start
            compositionReady -> { resetAiScan(); triggerAiRecommendation() }    // ↻ scan a new scene
            else -> resetAiScan()                                               // ✕ cancel
        }
    }

    private fun triggerAiRecommendation() {
        if (!::subjectChip.isInitialized) return
        aiScanRequested = true
        scanFinished = false
        emptyDetectionFrames = 0
        lastTrackedBox = null
        autoZoomApplied = false
        readyFrameCount = 0
        compositionReady = false
        aiGuideEnabled = true
        overlay.aiGuidesEnabled = true
        updateAdvice()
    }

    private fun resetAiScan() {
        aiScanRequested = false
        scanFinished = true
        emptyDetectionFrames = 0
        autoZoomApplied = false
        readyFrameCount = 0
        compositionReady = false
        aiGuideEnabled = false
        overlay.aiGuidesEnabled = false
        overlay.subjectBounds = null
        resetZoomPresets()
        setZoom(1f)
        refreshZoomButtons()
        updateAdvice()
    }

    private fun updateAiButton() {
        if (!::aiButton.isInitialized) return
        val yellow = Color.rgb(255, 214, 0)
        when {
            !aiScanRequested -> {
                aiButton.text = "✦"; aiButton.textSize = 30f
                aiButton.setTextColor(yellow)
                aiButton.background = roundBackground(Color.rgb(48, 40, 0))
                aiButton.contentDescription = "Scan scene"
            }
            compositionReady -> {
                aiButton.text = "↻"; aiButton.textSize = 28f
                aiButton.setTextColor(yellow)
                aiButton.background = roundBackground(Color.rgb(48, 40, 0))
                aiButton.contentDescription = "Scan a new scene"
            }
            else -> {
                aiButton.text = "✕"; aiButton.textSize = 24f
                aiButton.setTextColor(Color.WHITE)
                aiButton.background = roundBackground(Color.rgb(40, 40, 40))
                aiButton.contentDescription = "Cancel scan"
            }
        }
    }

    private fun updateAdvice(extra: String? = null, fromAnalysis: Boolean = false) {
        val box = lastTrackedBox
        compositionReady = false
        var hint: String
        var chipLabel: String? = null
        var hintColor = Color.WHITE

        if (manualFraming || !aiScanRequested || box == null) {
            readyFrameCount = 0
            guideDx = 0f
            guideDy = 0f
            overlay.subjectBounds = null
            overlay.boxAlpha = 0f
            hint = when {
                manualFraming -> "Manual framing: use the grid to compose"
                aiScanRequested -> "Finding your shot…"
                scanFinished -> "Tap ✦ to scan a new scene"
                else -> "Point your camera and tap the ✦ button"
            }
            hintColor = if (aiScanRequested && !manualFraming) Color.rgb(255, 214, 0) else Color.LTGRAY
        } else {
            val width = max(1f, analysisWidth.toFloat())
            val height = max(1f, analysisHeight.toFloat())
            val bounds = RectF(
                (box.left / width).coerceIn(0f, 1f),
                (box.top / height).coerceIn(0f, 1f),
                (box.right / width).coerceIn(0f, 1f),
                (box.bottom / height).coerceIn(0f, 1f)
            )
            overlay.subjectBounds = bounds
            val cx = bounds.centerX()
            val cy = bounds.centerY()
            subjectCenterX = cx
            subjectCenterY = cy

            val errorX = targetCenterX - cx
            val errorY = targetCenterY - cy
            guideDx = (-errorX).coerceIn(-.8f, .8f)
            guideDy = (-errorY).coerceIn(-.8f, .8f)
            val subjectFraction = (box.width().toFloat() * box.height().toFloat()) /
                max(1f, analysisWidth.toFloat() * analysisHeight.toFloat())
            val levelOk = abs(rollDegrees) < 4f
            val wasReady = readyFrameCount >= 2
            val tol = if (wasReady) .16f else .10f

            // AI zoom suggestion: once per scan, when the subject is small in the frame.
            if (!autoZoomApplied && fromAnalysis && subjectFraction < 0.06f) {
                autoZoomApplied = true
                val maxZ = min(5f, boundCamera?.cameraInfo?.zoomState?.value?.maxZoomRatio ?: 1f)
                val wanted = (zoomRatio * kotlin.math.sqrt(0.10f / max(0.002f, subjectFraction))).coerceIn(1f, maxZ)
                val rounded = kotlin.math.round(wanted * 2f) / 2f
                if (rounded >= zoomRatio + 0.5f) applyAutoZoom(rounded)
            }

            val aligned = abs(errorX) <= tol && abs(errorY) <= tol &&
                subjectFraction in 0.025f..0.62f && levelOk &&
                bounds.left >= 0f && bounds.top >= 0f && bounds.right <= 1f && bounds.bottom <= 1f
            // Several consecutive analysis frames are required so Ready does not flicker.
            if (!aligned) {
                readyFrameCount = 0
            } else if (fromAnalysis) {
                readyFrameCount = (readyFrameCount + 1).coerceAtMost(2)
            }
            compositionReady = readyFrameCount >= 2

            chipLabel = latestLabels.firstOrNull()?.lowercase() ?: "subject"
            hint = when {
                !levelOk -> "Level the horizon."
                subjectFraction > 0.62f -> "Step back a little."
                else -> sceneRecommendation(latestLabels, subjectFraction)
            }
        }
        if (!extra.isNullOrBlank()) hint = extra

        guideMessage = hint
        overlay.guideDx = guideDx
        overlay.guideDy = guideDy
        overlay.subjectCenterX = subjectCenterX
        overlay.subjectCenterY = subjectCenterY
        overlay.sourceAspectRatio = analysisWidth.toFloat() / max(1f, analysisHeight.toFloat())
        overlay.targetCenterX = targetCenterX
        overlay.targetCenterY = targetCenterY
        overlay.aiGuidesEnabled = aiGuideEnabled
        overlay.readyState = compositionReady
        overlay.invalidate()

        if (::subjectChip.isInitialized) {
            if (chipLabel == null) {
                subjectChip.visibility = View.INVISIBLE
            } else {
                subjectChip.visibility = View.VISIBLE
                if (compositionReady) {
                    val text = android.text.SpannableString("$chipLabel  |  Ready")
                    text.setSpan(
                        android.text.style.ForegroundColorSpan(Color.rgb(255, 214, 0)),
                        text.length - "Ready".length, text.length,
                        android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                    subjectChip.text = text
                } else {
                    subjectChip.text = "$chipLabel  ↗"
                }
            }
        }
        statusText.setTextColor(hintColor)
        statusText.text = hint
        updateAiButton()
    }

    private data class EditState(
        val tone: Tone, val brightness: Float, val contrast: Float, val saturation: Float,
        val highlights: Float, val shadows: Float, val vignette: Float, val grain: Float, val frame: Int
    )

    private fun currentEditState() = EditState(
        currentTone, editBrightness, editContrast, editSaturation,
        editHighlights, editShadows, editVignette, editGrain, editFrame
    )

    private fun restoreEditState(state: EditState) {
        currentTone = state.tone
        editBrightness = state.brightness
        editContrast = state.contrast
        editSaturation = state.saturation
        editHighlights = state.highlights
        editShadows = state.shadows
        editVignette = state.vignette
        editGrain = state.grain
        editFrame = state.frame
    }

    private fun openColorStudio(sourceUri: Uri? = null) {
        val uri = sourceUri ?: latestPhotoUri ?: selectedPhotoUri
        if (uri == null) {
            Toast.makeText(this, "Take or pick a photo first to open Color Studio", Toast.LENGTH_LONG).show()
            photoPicker.launch("image/*")
            return
        }
        selectedPhotoUri = uri
        val dialog = android.app.Dialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(8, 8, 10))
            setPadding(dp(16), dp(10), dp(16), dp(12))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "Color Studio"
            textSize = 20f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))
        val close = TextView(this).apply {
            text = "✕"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(8), dp(8), dp(8))
            setOnClickListener { dialog.dismiss() }
        }
        header.addView(close)
        root.addView(header)

        val previewFrame = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }
        val preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }
        try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            var sample = 1
            while (max(opts.outWidth, opts.outHeight) / sample > 1400) sample *= 2
            val bmp = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            }
            if (bmp != null) preview.setImageBitmap(bmp)
        } catch (_: Exception) {
            Toast.makeText(this, "Photo preview could not be loaded", Toast.LENGTH_SHORT).show()
        }
        previewFrame.addView(preview, FrameLayout.LayoutParams(-1, -1))
        root.addView(previewFrame, LinearLayout.LayoutParams(-1, 0, 1.0f).apply {
            topMargin = dp(8); bottomMargin = dp(12)
        })

        val tabs = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        val bodyScroll = android.widget.ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(8)) }
        bodyScroll.addView(body)
        root.addView(tabs, LinearLayout.LayoutParams(-1, dp(42)))
        root.addView(bodyScroll, LinearLayout.LayoutParams(-1, dp(190)))

        val history = mutableListOf(currentEditState())
        var historyIndex = 0
        fun recordChange() {
            while (history.lastIndex > historyIndex) history.removeAt(history.lastIndex)
            history.add(currentEditState())
            if (history.size > 30) history.removeAt(0)
            historyIndex = history.lastIndex
        }
        fun refreshPreview() {
            val matrix = ColorMatrix(currentTone.matrix)
            matrix.postConcat(ColorMatrix().apply { setSaturation(editSaturation) })
            val c = editContrast
            val b = editBrightness + editShadows * 18f + editHighlights * 10f
            matrix.postConcat(ColorMatrix(floatArrayOf(
                c,0f,0f,0f,b, 0f,c,0f,0f,b, 0f,0f,c,0f,b, 0f,0f,0f,1f,0f
            )))
            preview.colorFilter = android.graphics.ColorMatrixColorFilter(matrix)
            previewFrame.foreground = when (editFrame) {
                1 -> android.graphics.drawable.GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(dp(10), Color.WHITE) }
                2 -> android.graphics.drawable.GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(dp(10), Color.BLACK) }
                3 -> android.graphics.drawable.GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(dp(10), Color.rgb(210,160,100)) }
                else -> null
            }
        }
        fun heading(text: String) {
            body.addView(TextView(this).apply {
                this.text = text.uppercase(); textSize = 11f; setTextColor(Color.LTGRAY)
                setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, dp(4), 0, dp(10))
            })
        }
        fun addSlider(label: String, minValue: Int, maxValue: Int, initial: Int, onValue: (Int) -> Unit) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val valueLabel = TextView(this).apply { text = "$label  $initial"; textSize = 12f; setTextColor(Color.WHITE) }
            val seek = SeekBar(this).apply {
                max = maxValue - minValue
                progress = (initial - minValue).coerceIn(0, max)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        val value = progress + minValue
                        valueLabel.text = "$label  $value"
                        onValue(value)
                        refreshPreview()
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                    override fun onStopTrackingTouch(seekBar: SeekBar?) { if (seekBar != null) recordChange() }
                })
            }
            row.addView(valueLabel); row.addView(seek)
            body.addView(row)
        }
        var activeTab = "Looks"
        fun showTab(tab: String) {
            body.removeAllViews()
            when (tab) {
                "Looks" -> {
                    heading("Choose your look")
                    val names = listOf("LEAN", "HARBOR", "DUSK", "PRESS", "ALBU")
                    val tones = listOf(Tone.NATURAL, Tone.COOL, Tone.FILM, Tone.MONO, Tone.WARM)
                    val colors = listOf(Color.rgb(45,76,72), Color.rgb(44,88,91), Color.rgb(91,91,76), Color.DKGRAY, Color.rgb(118,86,61))
                    val strip = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
                    names.forEachIndexed { index, name ->
                        val tile = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(4), dp(4), dp(4)) }
                        val swatch = View(this).apply { background = roundBackground(colors[index]) }
                        tile.addView(swatch, LinearLayout.LayoutParams(dp(48), dp(54)))
                        tile.addView(TextView(this).apply { text = name; textSize = 9f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
                        tile.setOnClickListener { currentTone = tones[index]; recordChange(); refreshPreview(); showTab("Looks") }
                        strip.addView(tile, LinearLayout.LayoutParams(0, dp(88), 1f))
                    }
                    body.addView(strip)
                }
                "Adjust" -> {
                    heading("Fine tune")
                    addSlider("Exposure", -100, 100, editBrightness.toInt()) { editBrightness = it.toFloat() }
                    addSlider("Contrast", 50, 150, (editContrast * 100).toInt()) { editContrast = it / 100f }
                    addSlider("Highlights", -100, 100, (editHighlights * 100).toInt()) { editHighlights = it / 100f }
                    addSlider("Shadows", -100, 100, (editShadows * 100).toInt()) { editShadows = it / 100f }
                    addSlider("Saturation", 0, 200, (editSaturation * 100).toInt()) { editSaturation = it / 100f }
                }
                "Effects" -> {
                    heading("Texture & atmosphere")
                    addSlider("Grain", 0, 100, (editGrain * 100).toInt()) { editGrain = it / 100f }
                    addSlider("Vignette", 0, 100, (editVignette * 100).toInt()) { editVignette = it / 100f }
                }
                "Frames" -> {
                    heading("Frame")
                    listOf("None", "White", "Black", "Warm").forEachIndexed { index, label ->
                        val button = Button(this).apply { text = label; isAllCaps = false; setTextColor(Color.WHITE); background = roundBackground(Color.rgb(35,35,38)) }
                        button.setOnClickListener { editFrame = index; recordChange(); refreshPreview() }
                        body.addView(button, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(4) })
                    }
                }
            }
        }
        listOf("Looks", "Adjust", "Effects", "Frames").forEach { tab ->
            val button = TextView(this).apply {
                text = tab; gravity = Gravity.CENTER; textSize = 12f; setTextColor(Color.WHITE)
                setPadding(dp(9), 0, dp(9), 0)
                setOnClickListener { activeTab = tab; showTab(tab) }
            }
            tabs.addView(button, LinearLayout.LayoutParams(0, -1, 1f))
        }
        val actions = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        fun action(text: String, onClick: () -> Unit) {
            actions.addView(Button(this).apply { this.text = text; isAllCaps = false; setTextColor(Color.WHITE); background = roundBackground(Color.rgb(38,38,42)); setOnClickListener { onClick() } },
                LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) })
        }
        action("Delete") {
            android.app.AlertDialog.Builder(this).setTitle("Delete photo?")
                .setMessage("The original photo will be deleted from your gallery.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete") { _, _ ->
                    val ok = contentResolver.delete(uri, null, null) > 0
                    if (ok && uri == latestPhotoUri) { latestPhotoUri = null; galleryThumbnail.setImageResource(android.R.drawable.ic_menu_gallery) }
                    Toast.makeText(this, if (ok) "Photo deleted" else "Could not delete photo", Toast.LENGTH_SHORT).show()
                    if (ok) dialog.dismiss()
                }.show()
        }
        action("↶") { if (historyIndex > 0) { historyIndex--; restoreEditState(history[historyIndex]); refreshPreview(); showTab(activeTab) } }
        action("↷") { if (historyIndex < history.lastIndex) { historyIndex++; restoreEditState(history[historyIndex]); refreshPreview(); showTab(activeTab) } }
        val save = Button(this).apply {
            text = "✓ Save"; isAllCaps = false; setTextColor(Color.BLACK)
            background = roundBackground(Color.rgb(255, 210, 20))
            setOnClickListener { dialog.dismiss(); applyToneToUri(uri) }
        }
        actions.addView(save, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(actions, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })
        showTab(activeTab)
        refreshPreview()
        dialog.setContentView(root)
        dialog.window?.setBackgroundDrawableResource(android.R.color.black)
        dialog.window?.setLayout(-1, -1)
        dialog.show()
        dialog.window?.setLayout(-1, -1)
    }

    private fun decodePreviewBitmap(uri: Uri, maxDimension: Int = 1600): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth / sample, bounds.outHeight / sample) > maxDimension) sample *= 2
        return contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            })
        }
    }

    private fun showPhotoPreview(uri: Uri, allowEdit: Boolean) {
        val image = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
        }
        try {
            val previewBitmap = decodePreviewBitmap(uri)
            if (previewBitmap == null) throw IllegalStateException("Photo could not be opened")
            image.setImageBitmap(previewBitmap)
        } catch (_: Exception) {
            Toast.makeText(this, "Photo could not be opened", Toast.LENGTH_SHORT).show()
            return
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(4))
            addView(image, LinearLayout.LayoutParams(-1, dp(420)))
        }
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Photo preview")
            .setView(container)
            .setPositiveButton(if (allowEdit) "Edit photo" else "Close", null)
            .setNeutralButton("Share", null)
            .setNegativeButton("Delete", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (!allowEdit) { dialog.dismiss(); return@setOnClickListener }
                dialog.dismiss()
                openColorStudio(uri)
            }
            dialog.getButton(android.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val share = Intent(Intent.ACTION_SEND).apply { type = "image/*"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                startActivity(Intent.createChooser(share, "Share photo"))
            }
            dialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                android.app.AlertDialog.Builder(this)
                    .setTitle("Delete photo?")
                    .setMessage("This photo will be deleted from your gallery.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete") { _, _ ->
                        val deleted = contentResolver.delete(uri, null, null) > 0
                        statusText.text = if (deleted) "Photo deleted" else "Could not delete photo"
                        if (uri == latestPhotoUri) { latestPhotoUri = null; galleryThumbnail.setImageResource(android.R.drawable.ic_menu_gallery) }
                        dialog.dismiss()
                    }.show()
            }
        }
        dialog.show()
    }

    private fun applyToneToUri(uri: Uri) {
        cameraExecutor.execute {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) error("Photo could not be opened")
                // Keep memory use predictable on mid-range phones. The source photo is never modified.
                var sample = 1
                while ((bounds.outWidth.toLong() / sample) * (bounds.outHeight.toLong() / sample) > 6_000_000L) sample *= 2
                val bitmap = contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
                } ?: error("Photo could not be opened")
                val edited = applyFullEdit(bitmap)
                val saved = saveEditedBitmap(edited)
                bitmap.recycle()
                edited.recycle()
                runOnUiThread {
                    statusText.text = if (saved) "Edit saved as a copy. Your original is untouched." else "Could not save the edit."
                    Toast.makeText(this, statusText.text, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread { statusText.text = "Edit failed: ${e.localizedMessage}" }
            }
        }
    }

    private fun applyFullEdit(source: Bitmap): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val toneMatrix = ColorMatrix(currentTone.matrix)
        val saturationMatrix = ColorMatrix().apply { setSaturation(editSaturation) }
        toneMatrix.postConcat(saturationMatrix)
        val contrast = editContrast
        val brightness = editBrightness
        val adjust = ColorMatrix(floatArrayOf(
            contrast,0f,0f,0f,brightness, 0f,contrast,0f,0f,brightness,
            0f,0f,contrast,0f,brightness, 0f,0f,0f,1f,0f
        ))
        toneMatrix.postConcat(adjust)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(toneMatrix)
        }
        canvas.drawBitmap(source, 0f, 0f, paint)
        if (editHighlights != 0f || editShadows != 0f) {
            // Process in small horizontal bands to avoid allocating a full-resolution
            // second pixel array on mid-range devices such as Redmi 13C.
            val bandHeight = 64
            var top = 0
            while (top < output.height) {
                val rows = min(bandHeight, output.height - top)
                val pixels = IntArray(output.width * rows)
                output.getPixels(pixels, 0, output.width, 0, top, output.width, rows)
                for (i in pixels.indices) {
                    val color = pixels[i]
                    val r = Color.red(color).toFloat()
                    val g = Color.green(color).toFloat()
                    val b = Color.blue(color).toFloat()
                    val luminance = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
                    val shadowLift = editShadows * (1f - luminance) * (1f - luminance) * 72f
                    val highlightShift = editHighlights * luminance * luminance * 72f
                    val delta = shadowLift + highlightShift
                    pixels[i] = Color.rgb(
                        (r + delta).toInt().coerceIn(0, 255),
                        (g + delta).toInt().coerceIn(0, 255),
                        (b + delta).toInt().coerceIn(0, 255)
                    )
                }
                output.setPixels(pixels, 0, output.width, 0, top, output.width, rows)
                top += rows
            }
        }
        if (editGrain > 0f) {
            val random = java.util.Random(7L)
            val count = (source.width.toLong() * source.height / 180L * editGrain).toInt().coerceAtMost(120000)
            val grainPaint = Paint().apply { alpha = (editGrain * 55).toInt(); strokeWidth = 1f }
            repeat(count) {
                val x = random.nextInt(source.width).toFloat()
                val y = random.nextInt(source.height).toFloat()
                grainPaint.color = if (random.nextBoolean()) Color.WHITE else Color.BLACK
                canvas.drawPoint(x, y, grainPaint)
            }
        }
        if (editVignette > 0f) {
            val radius = max(source.width, source.height) * .72f
            val shader = RadialGradient(source.width / 2f, source.height / 2f, radius,
                intArrayOf(Color.TRANSPARENT, Color.argb((editVignette * 180).toInt(), 0, 0, 0)),
                floatArrayOf(.45f, 1f), Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, source.width.toFloat(), source.height.toFloat(), Paint().apply { this.shader = shader })
        }
        if (editFrame > 0) {
            val color = when (editFrame) { 1 -> Color.WHITE; 2 -> Color.BLACK; else -> Color.rgb(210, 160, 100) }
            val width = max(8f, min(source.width, source.height) * .025f)
            canvas.drawRect(0f, 0f, source.width.toFloat(), source.height.toFloat(), Paint().apply {
                this.color = color; style = Paint.Style.STROKE; strokeWidth = width
            })
        }
        return output
    }

    private fun sceneRecommendation(labels: List<String>, subjectFraction: Float = 0.3f): String {
        val text = labels.joinToString(" ").lowercase()
        val base = when {
            text.contains("food") || text.contains("dish") -> "Shoot slightly from above."
            text.contains("plant") || text.contains("flower") -> "Separate the subject from the background."
            text.contains("building") || text.contains("architecture") -> "Keep the vertical lines straight."
            text.contains("landscape") || text.contains("sky") || text.contains("mountain") -> "Place the horizon on a thirds line."
            text.contains("animal") || text.contains("dog") || text.contains("cat") || text.contains("bird") -> "Get level with your subject."
            text.contains("person") || text.contains("people") -> "Leave some room above the head."
            labels.isNotEmpty() -> "Isolate the ${labels.first().lowercase()}."
            else -> "Place the subject on a thirds point."
        }
        return if (subjectFraction < 0.06f) "$base Go tighter." else base
    }

    private fun saveEditedBitmap(bitmap: Bitmap): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "BestShot_Edit_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BestShotAI/Edits")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            val stream = contentResolver.openOutputStream(uri) ?: throw IllegalStateException("Storage is unavailable")
            val encoded = stream.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 96, it) }
            if (!encoded) throw IllegalStateException("JPEG encoding failed")
            true
        } catch (_: Exception) {
            contentResolver.delete(uri, null, null)
            false
        }
    }

    override fun onResume() {
        super.onResume()
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.also {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        sensorManager.unregisterListener(this)
        super.onPause()
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0]
        val y = event.values[1]
        rollDegrees = Math.toDegrees(kotlin.math.atan2(x.toDouble(), y.toDouble())).toFloat()
        overlay.rollDegrees = rollDegrees
        horizonAdvice = if (abs(rollDegrees) < 2.5f) "Level" else "Tilted ${"%.1f".format(java.util.Locale.US, abs(rollDegrees))}°"
        overlay.invalidate()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    /** Capture exactly one frame per shutter press. No hidden burst or automatic selection. */
    private fun capturePhoto() {
        val capture = imageCapture
        if (capture == null) {
            statusText.text = "Camera not ready. Try again in a moment."
            return
        }
        if (isCapturing) return
        isCapturing = true
        shutterButton.isEnabled = false
        statusText.text = "Capturing at full quality…"
        val file = File(cacheDir, "bestshot_${System.nanoTime()}.jpg")
        val options = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                cameraExecutor.execute {
                    val savedUri = try { saveOriginalJpeg(file) } finally { file.delete() }
                    runOnUiThread {
                        if (savedUri != null) {
                            updateGalleryThumbnail(savedUri)
                            finishCapture("Photo saved • original camera JPEG kept ✓")
                        } else {
                            finishCapture("Could not save photo to gallery.")
                        }
                    }
                }
            }
            override fun onError(exception: ImageCaptureException) {
                file.delete()
                finishCapture("Capture failed: ${exception.message ?: "camera error"}")
            }
        })
    }

    private fun saveOriginalJpeg(file: File): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "BestShot_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BestShotAI")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            val output = contentResolver.openOutputStream(uri) ?: error("Could not open the gallery")
            output.use { out -> file.inputStream().use { input -> input.copyTo(out) } }
            if (file.length() <= 0L) throw IllegalStateException("Photo file is empty")
            uri
        } catch (_: Exception) {
            contentResolver.delete(uri, null, null)
            null
        }
    }

    private fun updateGalleryThumbnail(uri: Uri) {
        latestPhotoUri = uri
        try {
            val bitmap = if (android.os.Build.VERSION.SDK_INT >= 29) {
                contentResolver.loadThumbnail(uri, Size(240, 240), null)
            } else {
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }
            if (bitmap != null) galleryThumbnail.setImageBitmap(bitmap)
        } catch (_: Exception) { galleryThumbnail.setImageResource(android.R.drawable.ic_menu_gallery) }
    }

    private fun loadLatestPhoto() {
        try {
            val projection = arrayOf(MediaStore.Images.Media._ID)
            val selection = if (android.os.Build.VERSION.SDK_INT >= 29) "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?" else null
            val args = if (selection != null) arrayOf("Pictures/BestShotAI%") else null
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                args,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
                    val uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                    updateGalleryThumbnail(uri)
                }
            }
        } catch (_: Exception) { /* Gallery picker remains available through the thumbnail. */ }
    }

    private fun finishCapture(message: String) {
        isCapturing = false
        shutterButton.isEnabled = true
        statusText.text = message
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        if (::cameraExecutor.isInitialized) cameraExecutor.shutdown()
        objectDetector.close()
        faceDetector.close()
        imageLabeler.close()
        super.onDestroy()
    }

    private inner class GuideOverlay : View(this@MainActivity) {
        var gridEnabled = true
        var rollDegrees = 0f
        var toneTint = Color.TRANSPARENT
        var aiGuidesEnabled = false
        var guideDx = 0f
        var guideDy = 0f
        var subjectCenterX = .5f
        var subjectCenterY = .5f
        var targetCenterX = .5f
        var targetCenterY = .5f
        var sourceAspectRatio = 3f / 4f
        var frameRatio = 3f / 4f
        var subjectBounds: RectF? = null
        var readyState = false
        var boxAlpha = 0f
        var showMoveArrow = false
        private var detections: List<Rect> = emptyList()
        private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(155, 255, 255, 255); strokeWidth = 1.5f; style = Paint.Style.STROKE
        }
        private val targetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 214, 0); strokeWidth = dp(3).toFloat(); style = Paint.Style.STROKE
        }
        private val detectorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; alpha = 210; strokeWidth = dp(2).toFloat(); style = Paint.Style.STROKE
            pathEffect = android.graphics.DashPathEffect(floatArrayOf(dp(4).toFloat(), dp(4).toFloat()), 0f)
        }
        private val connectorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 214, 0); strokeWidth = dp(2).toFloat(); style = Paint.Style.STROKE
            pathEffect = android.graphics.DashPathEffect(floatArrayOf(dp(7).toFloat(), dp(6).toFloat()), 0f)
        }
        private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 214, 0); strokeWidth = dp(3).toFloat(); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
        }
        private val tintPaint = Paint()
        private val subjectPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 214, 0); strokeWidth = dp(3).toFloat(); style = Paint.Style.STROKE
        }
        private val levelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            strokeWidth = dp(2).toFloat(); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
        }
        fun setDetections(value: List<Rect>) {
            detections = value.map { Rect(it) }
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            if (gridEnabled) {
                canvas.drawLine(w / 3f, 0f, w / 3f, h, gridPaint)
                canvas.drawLine(2f * w / 3f, 0f, 2f * w / 3f, h, gridPaint)
                canvas.drawLine(0f, h / 3f, w, h / 3f, gridPaint)
                canvas.drawLine(0f, 2f * h / 3f, w, 2f * h / 3f, gridPaint)
            }
            levelPaint.color = if (abs(rollDegrees) < 4f) Color.rgb(255, 214, 0) else Color.WHITE
            canvas.save()
            canvas.rotate(rollDegrees, w / 2f, h / 2f)
            canvas.drawLine(w * .34f, h / 2f, w * .66f, h / 2f, levelPaint)
            canvas.restore()
            if (aiGuidesEnabled && subjectBounds != null) {
                // Fixed reference ticks either side of the (tilting) level line.
                val tick = dp(18).toFloat()
                canvas.drawLine(w * .24f, h / 2f, w * .24f + tick, h / 2f, levelPaint)
                canvas.drawLine(w * .76f - tick, h / 2f, w * .76f, h / 2f, levelPaint)
            }

            if (aiGuidesEnabled) {
                val bounds = subjectBounds
                if (bounds != null) {
                    // Yellow framing box follows the detected subject and updates per analysis frame.
                    // Match PreviewView FILL_CENTER cropping so ML Kit boxes line up with
                    // what the user actually sees in the portrait viewfinder.
                    val viewAspect = w / max(1f, h)
                    var left = bounds.left
                    var right = bounds.right
                    var top = bounds.top
                    var bottom = bounds.bottom
                    if (sourceAspectRatio > viewAspect) {
                        val visible = (viewAspect / sourceAspectRatio).coerceIn(0f, 1f)
                        val crop = (1f - visible) / 2f
                        left = (left - crop) / max(.001f, visible)
                        right = (right - crop) / max(.001f, visible)
                    } else {
                        val visible = (sourceAspectRatio / viewAspect).coerceIn(0f, 1f)
                        val crop = (1f - visible) / 2f
                        top = (top - crop) / max(.001f, visible)
                        bottom = (bottom - crop) / max(.001f, visible)
                    }
                    val subject = RectF(
                        left * w, top * h, right * w, bottom * h
                    )
                    subject.intersect(0f, 0f, w, h)
                    // White dashed rectangle is the detector result. The yellow rectangle
                    // below is a separate composition target, never a green/ready indicator.
                    // The yellow box marks the subject while you line it up with the "+".
                    // Once Ready, the box and dashed line fade away.
                    val targetAlpha = if (readyState) 0f else 1f
                    boxAlpha += (targetAlpha - boxAlpha) * .35f
                    if (abs(targetAlpha - boxAlpha) > .02f) postInvalidateOnAnimation() else boxAlpha = targetAlpha
                    val guideAlpha = (255 * boxAlpha).toInt()
                    subjectPaint.alpha = guideAlpha
                    connectorPaint.alpha = guideAlpha
                    arrowPaint.alpha = guideAlpha
                    if (guideAlpha > 4) canvas.drawRoundRect(subject, dp(10).toFloat(), dp(10).toFloat(), subjectPaint)
                    val targetWidth = (subject.width() * 1.12f).coerceIn(dp(58).toFloat(), w * .72f)
                    val targetHeight = (subject.height() * 1.12f).coerceIn(dp(72).toFloat(), h * .62f)
                    val tx = targetCenterX * w
                    val ty = targetCenterY * h
                    val target = RectF(
                        tx - targetWidth / 2f, ty - targetHeight / 2f,
                        tx + targetWidth / 2f, ty + targetHeight / 2f
                    )
                    target.offset(
                        (if (target.left < dp(8)) dp(8) - target.left else 0f) +
                            (if (target.right > w - dp(8)) (w - dp(8)) - target.right else 0f),
                        (if (target.top < dp(8)) dp(8) - target.top else 0f) +
                            (if (target.bottom > h - dp(8)) (h - dp(8)) - target.bottom else 0f)
                    )

                    // Dashed connector leads from the detected subject to the target frame.
                    if (guideAlpha > 4) canvas.drawLine(subject.centerX(), subject.centerY(), tx, ty, connectorPaint)
                    val marker = dp(7).toFloat()
                    if (guideAlpha > 4) {
                        canvas.drawLine(tx - marker, ty, tx + marker, ty, arrowPaint)
                        canvas.drawLine(tx, ty - marker, tx, ty + marker, arrowPaint)
                    }

                    // Arrow indicates the physical movement of the phone.
                    val cx = w * .5f
                    val cy = h * .72f
                    val dx = guideDx * w * .22f
                    val dy = guideDy * h * .18f
                    if (showMoveArrow && (abs(dx) > dp(5) || abs(dy) > dp(5))) {
                        val ex = cx + dx
                        val ey = cy + dy
                        canvas.drawLine(cx, cy, ex, ey, arrowPaint)
                        val angle = kotlin.math.atan2(dy, dx)
                        val head = dp(13).toFloat()
                        val a1 = angle + Math.PI * .78
                        val a2 = angle - Math.PI * .78
                        canvas.drawLine(ex, ey, ex + kotlin.math.cos(a1).toFloat() * head, ey + kotlin.math.sin(a1).toFloat() * head, arrowPaint)
                        canvas.drawLine(ex, ey, ex + kotlin.math.cos(a2).toFloat() * head, ey + kotlin.math.sin(a2).toFloat() * head, arrowPaint)
                    }
                }
            }
            // Optional aspect-ratio guide. It is an overlay only; captured JPEG stays native.
            if (frameRatio > 0f) {
                val viewRatio = w / max(1f, h)
                val frameW: Float
                val frameH: Float
                if (viewRatio > frameRatio) {
                    frameH = h
                    frameW = h * frameRatio
                } else {
                    frameW = w
                    frameH = w / frameRatio
                }
                val frame = RectF((w - frameW) / 2f, (h - frameH) / 2f,
                    (w + frameW) / 2f, (h + frameH) / 2f)
                val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.argb(150, 255, 255, 255)
                    style = Paint.Style.STROKE
                    strokeWidth = dp(1).toFloat()
                }
                canvas.drawRect(frame, framePaint)
            }
            if (toneTint != Color.TRANSPARENT) {
                tintPaint.color = toneTint
                canvas.drawRect(0f, 0f, w, h, tintPaint)
            }
        }
    }
}
