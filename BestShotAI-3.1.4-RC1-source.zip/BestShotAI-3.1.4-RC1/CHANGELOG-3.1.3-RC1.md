# BestShot AI 3.1.3-RC1

## Fix: scan stuck on "Finding your shot…"
- Added a saliency fallback subject (`salientRect`) used when ML Kit gives no face/object box for ~4 analysis frames (~2 s) during an active scan.
- Detector boxes keep priority; the fallback is only used while the detector is empty.
- A new scan now clears the previous tracked subject.

## Validation status
- Not compiled here (no Gradle / Android SDK). Run the GitHub Actions build and test on a Redmi 13C.
