# BestShot AI 3.1.2-RC1

## Camera screen (matches the reference recordings)
- Subject chip: hidden until a subject is found, then `label ↗`; when Ready: `label | Ready` (yellow "Ready", dark pill).
- Single short guidance sentence; "Finding your shot…" in yellow while scanning; "Tap ✦ to scan a new scene" after a scan ends.
- AI zoom suggestion (once per scan, when the subject is small); recommended value replaces the 2x/5x preset and is highlighted.
- Right button states: ✦ (idle) → ✕ (scanning / not ready) → ↻ (Ready, scans a new scene).
- Overlay: yellow rounded subject box + dashed connector to target (hidden when Ready); yellow level line with fixed ticks; movement arrow disabled by default.
- All user-facing strings translated to English.

## Not changed
- Capture pipeline, ratio handling, Color Studio logic.

## Validation status
- Not compiled here (no Gradle / Android SDK). Run the GitHub Actions build and the checklist on a Redmi 13C.
