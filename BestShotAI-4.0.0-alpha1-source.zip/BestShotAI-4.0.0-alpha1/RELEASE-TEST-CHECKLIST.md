# BestShot AI release test checklist

Do not mark this build as final until every device test below passes on the Redmi 13C.

## Build
- [ ] GitHub Actions `Build BestShot AI APK` completes successfully.
- [ ] APK installs and launches on Redmi 13C.
- [ ] Camera permission denial and later permission grant behave correctly.

## Camera
- [ ] Live rear-camera preview starts and recovers after returning from background.
- [ ] Shutter saves one JPEG per press to Pictures/BestShotAI.
- [ ] JPEG opens in the system gallery and has expected full camera resolution.
- [ ] Flash toggles torch only when hardware supports it.
- [ ] Each zoom step is clamped to the device's actual supported range.
- [ ] Each of 3:4, 4:5, 1:1, and 9:16 changes the captured image crop, not just the overlay.
- [ ] Rebinding after changing ratio does not freeze preview or stop analysis.

## AI composition
- [ ] Face and object detection appear in the correct position in the viewfinder.
- [ ] White dashed detector rectangle and yellow composition target are visibly distinct.
- [ ] Yellow target never turns green and does not trigger automatic capture.
- [ ] Guidance direction changes appropriately as the phone moves.
- [ ] Horizon guide responds correctly in portrait orientation.

## Gallery and editor
- [ ] Latest-photo thumbnail opens the correct image.
- [ ] Gallery picker opens an existing image.
- [ ] Looks and every Adjust/Effects/Frames control changes the exported image.
- [ ] Edited image saves as a new file; original remains unchanged.
- [ ] Share opens Android Sharesheet with the selected image.
- [ ] Delete asks for confirmation and removes only the selected image.
- [ ] Editing large photos does not cause an out-of-memory crash.

## Performance
- [ ] Camera analysis remains responsive for at least 5 minutes.
- [ ] No crash occurs while rapidly switching ratios, opening editor, and returning to camera.
- [ ] Device temperature and memory use remain acceptable during normal use.


## 3.1.1-RC1 additional regression checks
- [ ] READY never appears before the AI sparkle button is tapped.
- [ ] READY appears only after at least three consecutive stable analysis frames.
- [ ] Moving the subject out of the target resets READY.
- [ ] Tilting the phone beyond the level threshold resets READY.
- [ ] Switching to manual framing prevents READY.
- [ ] Rapid scene changes do not freeze object detection.
- [ ] Large photos open in preview without loading their full-resolution bitmap.
- [ ] Failed JPEG encoding reports an error and does not leave a broken gallery item.
- [ ] Captured JPEG copy is non-empty and opens in the gallery.
- [ ] Edit Save creates a separate JPEG and leaves the original unchanged.

## 4.0.0-alpha1 advanced controls
- [ ] Professional Camera panel opens and reports unsupported manual-sensor hardware clearly.
- [ ] On manual-sensor devices, ISO changes exposure without crashing or freezing preview.
- [ ] Shutter time changes exposure and stays within the advertised sensor range.
- [ ] Auto exposure reset restores normal AE behavior.
- [ ] Each enabled white-balance preset visibly changes the image consistently in preview and capture.
- [ ] Manual exposure and white-balance settings survive aspect-ratio use-case rebinding.
- [ ] Temperature and Tint update the editor preview and exported JPEG.
- [ ] Undo/redo restores Temperature and Tint values correctly.
