# BestShot AI 4.0.0-alpha2

This alpha focuses on strengthening the AI camera coach rather than expanding manual camera controls.

### New AI capabilities
- Human pose detection and landmark skeleton overlay during an active scan.
- Portrait guidance for eye-line placement and headroom.
- A composition score based on alignment, subject size, and horizon level.
- More stable subject-box tracking using overlap, distance, size consistency, smoothing, and brief missed-frame retention.
- Adaptive inference cadence to reduce work on entry-level devices.

### Existing AI retained
- ML Kit face detection, object detection/tracking, and image labeling.
- Saliency fallback, rule-of-thirds guidance, horizon level, and zoom suggestions.

### Important limitations
- Pose Detection uses ML Kit beta `18.0.0-beta5`.
- The score is a transparent heuristic, not a learned aesthetic-quality model.
- Current object selection is still a best-subject association heuristic; it is not persistent semantic identity tracking across arbitrary occlusion.
- Build and test on physical hardware before release.
