# BestShot AI 4.0.0-alpha2 — AI Composition Upgrade

## AI improvements
- Added on-device ML Kit Pose Detection in STREAM_MODE for human body landmark detection.
- Added a lightweight pose skeleton overlay to help users understand detected body posture and framing.
- Added pose-aware portrait guidance: eye-line placement and headroom.
- Added a weighted composition score combining subject alignment, subject occupancy, and horizon level.
- Improved subject-box association with IoU, normalized center distance, size-change penalty, adaptive smoothing, and short missed-frame retention.
- Added adaptive analysis cadence and throttled pose inference to reduce pressure on lower-end devices.
- Improved scene-label confidence filtering.

## Validation
- Source-level update only. A successful Gradle build and physical-device performance test have not yet been confirmed.
- Pose Detection is currently published as a beta ML Kit dependency.
- Pose inference is only enabled during an active AI scan and is throttled to approximately one call per 1.25 seconds.
- Real-time speed, heat, memory, and accuracy must be tested on the target phone.
