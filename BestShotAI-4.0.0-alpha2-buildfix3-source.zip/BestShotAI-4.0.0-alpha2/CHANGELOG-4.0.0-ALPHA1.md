# BestShot AI 4.0.0-alpha1

## Advanced camera foundation
- Added a Professional Camera panel with device-capability-aware manual ISO and shutter controls through Camera2 interop.
- Added selectable Camera2 auto-white-balance presets (Auto, Daylight, Cloudy, Shade, Tungsten, Fluorescent), gated by the active camera's advertised modes.
- Added an Auto Exposure reset action.
- Reapplies selected manual exposure and white-balance options after camera use-case rebinding.

## Film Lab improvements
- Added Temperature and Tint adjustments to the editor and included them in the edit undo/redo state.
- Applied Temperature and Tint in both editor preview and exported bitmap processing.

## Important validation notes
- This is an alpha source update, not a verified release APK.
- Device support for manual sensor controls varies; unsupported capabilities are disabled or reported.
- ISO/shutter interaction, white balance, image capture consistency, editor rendering, and memory use must be tested on physical devices (especially Redmi 13C).
- Full 3D LUT, RGB curves, HSL channels, RAW/DNG capture, robust multi-object tracking, and persistent non-destructive edit recipes are not implemented by this alpha.
