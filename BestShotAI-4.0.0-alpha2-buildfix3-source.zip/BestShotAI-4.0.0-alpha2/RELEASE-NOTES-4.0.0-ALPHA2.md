# BestShot AI 4.0.0-alpha2

AI-first update: pose-aware composition coach, skeleton landmark overlay, composition score, more stable subject tracking, and adaptive inference scheduling. This is source code, not a verified APK.
