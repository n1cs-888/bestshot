# BestShot AI 4.0.0-alpha1

This alpha extends the supplied 3.1.4-RC1 source without replacing its existing camera and AI composition workflow.

### New in this alpha
- Professional Camera panel: Camera2 capability-aware manual ISO/shutter controls and white-balance presets.
- Auto exposure reset.
- Temperature and Tint editor adjustments, included in undo/redo state and final export rendering.

### Existing foundation retained
- CameraX preview, JPEG capture, aspect-ratio viewports, exposure compensation, zoom and torch.
- ML Kit face/object detection and image labeling.
- Heuristic composition guide, horizon level and approximate subject tracking.
- Looks, Adjust, Effects, Frames and separate-copy editing workflow.

### Known limitations
- This alpha is not yet compiled or tested on a physical Android device in this environment.
- Manual ISO/shutter and white balance depend on camera hardware/driver support.
- The current editor still uses Android ColorMatrix and CPU bitmap effects; this is not a full GPU-grade RAW workflow.
- 3D LUT import, RGB curves, per-channel HSL, RAW/DNG capture, robust multi-object identity tracking, persistent non-destructive recipes, and complete EXIF-preserving export remain future work.

Build and test using Android Studio or the repository GitHub Actions workflow before installing.
