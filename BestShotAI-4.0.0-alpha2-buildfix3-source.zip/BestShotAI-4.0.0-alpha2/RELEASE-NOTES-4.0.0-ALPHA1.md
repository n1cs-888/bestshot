# BestShot AI 4.0.0-alpha1

This is an advanced-foundation alpha built on the supplied 3.1.4-RC1 project. It adds Camera2 manual exposure controls and white-balance presets where hardware supports them, plus Temperature and Tint in the editor.

It is not a feature-complete Framed replacement yet. Full 3D LUT workflows, RGB curves, per-channel HSL, RAW/DNG capture, advanced focus controls, robust multi-object tracking, and persistent non-destructive edit recipes remain unfinished. No APK build or physical-device validation has been completed for this archive.
