# BestShot AI release test checklist

Do not mark this build as final until every device test below passes on the Redmi 13C.

## Build
- [ ] GitHub Actions `Build BestShot AI APK` completes successfully.
- [ ] APK installs and launches on Redmi 13C.
- [ ] Camera permission denial and later permission grant behave correctly.

## Camera
- [ ] Live rear-camera preview starts and recovers after returning from background.
- [ ] Shutter saves one JPEG per press to Pictures/BestShotAI.
- [ ] JPEG opens in the system gallery and has expected full camera resolution.
- [ ] Flash toggles torch only when hardware supports it.
- [ ] Each zoom step is clamped to the device's actual supported range.
- [ ] Each of 3:4, 4:5, 1:1, and 9:16 changes the captured image crop, not just the overlay.
- [ ] Rebinding after changing ratio does not freeze preview or stop analysis.

## AI composition
- [ ] Face and object detection appear in the correct position in the viewfinder.
- [ ] White dashed detector rectangle and yellow composition target are visibly distinct.
- [ ] Yellow target never turns green and does not trigger automatic capture.
- [ ] Guidance direction changes appropriately as the phone moves.
- [ ] Horizon guide responds correctly in portrait orientation.

## Gallery and editor
- [ ] Latest-photo thumbnail opens the correct image.
- [ ] Gallery picker opens an existing image.
- [ ] Looks and every Adjust/Effects/Frames control changes the exported image.
- [ ] Edited image saves as a new file; original remains unchanged.
- [ ] Share opens Android Sharesheet with the selected image.
- [ ] Delete asks for confirmation and removes only the selected image.
- [ ] Editing large photos does not cause an out-of-memory crash.

## Performance
- [ ] Camera analysis remains responsive for at least 5 minutes.
- [ ] No crash occurs while rapidly switching ratios, opening editor, and returning to camera.
- [ ] Device temperature and memory use remain acceptable during normal use.
