# BestShot AI 4.0.0-alpha4 workflow compatibility fix

This package contains the alpha4 merged source (including the Fixed Composition Lock work) and the explicit ML Kit Pose import:
`com.google.mlkit.vision.pose.Pose`.

The outer directory is intentionally named `BestShotAI-4.0.0-alpha2` because the current GitHub Actions build command shown in the user's screenshot is hard-coded to `extracted/BestShotAI-4.0.0-alpha2`. The Android app version remains `4.0.0-alpha4` in `app/build.gradle.kts`.

This packaging adjustment ensures the workflow's existing `-p` path points at the merged alpha4 source rather than an older alpha2 folder. It does not claim that a remote GitHub Actions build has succeeded; run the workflow to verify compilation.
